# Bug files for Chapter 22 (Debugging)

Each `.patch` file creates ONE error in the practice project `jaffle_dbt`.
They were made against the state of tag `ch21` (they also apply to `ch22` .. `ch25`).

## How to use one

```bash
cd ~/dbt-course/jaffle_dbt
git status                       # start from a clean working tree
git apply ~/dbt-course/kit/bugs/01-jinja-missing-endif.patch
dbt parse                        # or the command given below: read the error message
git apply -R ~/dbt-course/kit/bugs/01-jinja-missing-endif.patch
git status                       # clean again
```

If `git apply` refuses ("patch does not apply"), your files differ from the reference
project: compare with `git diff ch21` and fix that first, or make the change by hand
(each patch is only 1 to 3 lines).

## The bugs

| File | What it breaks | Command that shows the error | Error (dbt-core 1.11.16 + dbt-duckdb 1.11.0) |
|---|---|---|---|
| `01-jinja-missing-endif.patch` | removes `{% endif %}` in `fct_orders.sql` | `dbt parse` | `Compilation Error ... Unexpected end of template. Jinja was looking for the following tags: 'elif' or 'else' or 'endif'.` |
| `02-yaml-bad-indentation.patch` | one key in `_stripe__models.yml` is indented by 7 spaces instead of 8 | `dbt parse` | `Parsing Error ... Syntax error near line 15 ... did not find expected '-' indicator` |
| `03-database-error-bad-column.patch` | `lower(emial)` in `stg_jaffle_shop__customers.sql` | `dbt run -s stg_jaffle_shop__customers` (dbt parse does NOT see it) | `Runtime Error ... Binder Error: Referenced column "emial" not found in FROM clause!` |
| `04-dependency-cycle.patch` | adds `-- depends_on: {{ ref('fct_orders') }}` (a ref in a SQL comment still counts) to `stg_stripe__payments.sql` | `dbt ls -s stg_stripe__payments` (dbt parse does NOT see it) | `Found a cycle: model.jaffle_dbt.int_orders__enriched --> model.jaffle_dbt.fct_orders --> model.jaffle_dbt.stg_stripe__payments --> model.jaffle_dbt.int_payments__successful` |
| `05-ref-missing-model.patch` | `ref('stg_orders')` in `fct_order_items.sql` | `dbt parse` | `Compilation Error ... depends on a node named 'stg_orders' which was not found` |
| `06-duplicate-model-name.patch` | adds a second `fct_orders.sql` in `models/marts/finance/` | `dbt parse` | `Compilation Error ... dbt found two models with the name "fct_orders".` |
| `07-undefined-source.patch` | `source('jaffle_shop', 'customer')` (no s) | `dbt parse` | `Compilation Error ... depends on a source named 'jaffle_shop.customer' which was not found` |
| `08-semicolon-at-end.patch` | a `;` at the end of `stg_jaffle_shop__products.sql` | `dbt run -s stg_jaffle_shop__products` (dbt parse does NOT see it) | `Runtime Error ... Parser Error: syntax error at or near ";"` |
| `09-yaml-key-typo.patch` | `desciption:` instead of `description:` | `dbt parse --no-partial-parse` | NOTHING on DuckDB. dbt-core 1.11 only validates YAML keys for bigquery / databricks / redshift / snowflake; there you get `[WARNING][CustomKeyInObjectDeprecation] ... Custom key desciption found at models[1]`. The description is silently lost. |

The full outputs (and where to look: `target/compiled/...`, `logs/dbt.log`, `dbt show`)
are in the reference build log of Chapter 22.

## On Windows (PowerShell)

```powershell
cd $HOME\dbt-course\jaffle_dbt
git status
git apply $HOME\dbt-course\kit\bugs\01-jinja-missing-endif.patch
dbt parse
git apply -R $HOME\dbt-course\kit\bugs\01-jinja-missing-endif.patch
```

If `git apply` says "patch does not apply" although your file is the same as the reference, the cause is
usually Windows line endings (CRLF): add `--ignore-whitespace` to both commands. With
`git config --global core.autocrlf true` (recommended on Windows) the plain command works.
