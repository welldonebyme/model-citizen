"""Run SQL against the practice database and print an ASCII table.

Used to verify (and copy) every query result printed in the bible.

    python run_sql.py "select count(*) from jaffle_shop.orders"
    python run_sql.py -f query.sql            # several statements: prints the last result
    python run_sql.py --db other.duckdb "..."  # another database
    python run_sql.py --max 15 "..."           # show at most 15 rows (default 20)
"""
import argparse
import sys
from pathlib import Path

import duckdb

DEFAULT_DB = Path.home() / "dbt-course" / "practice" / "practice.duckdb"  # kit: ~/dbt-course


def fmt(v):
    if v is None:
        return "NULL"
    return str(v)


def ascii_table(cols, rows, total, max_rows):
    shown = rows[:max_rows]
    cells = [[fmt(v) for v in r] for r in shown]
    widths = [max([len(c)] + [len(r[i]) for r in cells]) for i, c in enumerate(cols)]
    line = "+" + "+".join("-" * (w + 2) for w in widths) + "+"
    out = [line, "| " + " | ".join(c.ljust(w) for c, w in zip(cols, widths)) + " |", line]
    for r in cells:
        out.append("| " + " | ".join(v.rjust(w) if v.replace('.', '', 1).replace('-', '', 1).isdigit()
                                      else v.ljust(w) for v, w in zip(r, widths)) + " |")
    out.append(line)
    if total > max_rows:
        out.append(f"({total} rows, {max_rows} shown)")
    else:
        out.append(f"({total} row{'s' if total != 1 else ''})")
    return "\n".join(out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("sql", nargs="?")
    ap.add_argument("-f", "--file")
    ap.add_argument("--db", default=str(DEFAULT_DB))
    ap.add_argument("--max", type=int, default=20)
    a = ap.parse_args()
    sql = Path(a.file).read_text() if a.file else a.sql
    if not sql:
        sys.exit("give SQL text or -f file")
    # read-only so several readers can query the practice database at the same time
    con = duckdb.connect(a.db, read_only=(a.db == str(DEFAULT_DB)))
    stmts = [s for s in duckdb.extract_statements(sql)]
    res = None
    for s in stmts:
        res = con.execute(s)
    if res is None or res.description is None:
        print("OK (no result set)")
        return
    cols = [d[0] for d in res.description]
    rows = res.fetchall()
    print(ascii_table(cols, rows, len(rows), a.max))


if __name__ == "__main__":
    main()
