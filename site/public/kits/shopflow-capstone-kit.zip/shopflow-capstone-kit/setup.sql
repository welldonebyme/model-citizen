-- =====================================================================
--  setup.sql -- builds the raw database of the capstone project ShopFlow
--
--  From the folder that contains this file (and the data/ folder), run:
--      duckdb shopflow.duckdb < setup.sql
--  Run it again at any time to RESET the raw data to day 1.
--  (It replaces the raw tables only. Your dbt schemas are not touched.)
-- =====================================================================

create schema if not exists shopflow_app;        -- the shop's application database
create schema if not exists payments_provider;   -- export from the payment provider
create schema if not exists web_analytics;       -- the website tracker
create schema if not exists shipping;            -- the carriers' shipment feed

-- ---------------------------------------------------------- shopflow_app
create or replace table shopflow_app.customers as
select * from read_csv('data/customers.csv', header = true,
    columns = {'customer_id': 'INTEGER', 'email': 'VARCHAR', 'first_name': 'VARCHAR',
               'last_name': 'VARCHAR', 'country_code': 'VARCHAR', 'created_at': 'TIMESTAMP',
               'updated_at': 'TIMESTAMP', '_loaded_at': 'TIMESTAMP'});

create or replace table shopflow_app.addresses as
select * from read_csv('data/addresses.csv', header = true,
    columns = {'address_id': 'INTEGER', 'customer_id': 'INTEGER', 'address_type': 'VARCHAR',
               'city': 'VARCHAR', 'postal_code': 'VARCHAR', 'country_code': 'VARCHAR',
               'is_default': 'BOOLEAN'});

create or replace table shopflow_app.products as
select * from read_csv('data/products.csv', header = true,
    columns = {'product_id': 'INTEGER', 'sku': 'VARCHAR', 'product_name': 'VARCHAR',
               'category': 'VARCHAR', 'price': 'DECIMAL(10,2)', 'currency': 'VARCHAR',
               'is_active': 'BOOLEAN', 'created_at': 'TIMESTAMP', 'updated_at': 'TIMESTAMP'});

create or replace table shopflow_app.orders as
select * from read_csv('data/orders.csv', header = true,
    columns = {'order_id': 'INTEGER', 'customer_id': 'INTEGER', 'order_at': 'TIMESTAMP',
               'status': 'VARCHAR', 'currency': 'VARCHAR', 'shipping_address_id': 'INTEGER',
               'updated_at': 'TIMESTAMP', '_loaded_at': 'TIMESTAMP'});

create or replace table shopflow_app.order_items as
select * from read_csv('data/order_items.csv', header = true,
    columns = {'order_item_id': 'INTEGER', 'order_id': 'INTEGER', 'product_id': 'INTEGER',
               'quantity': 'INTEGER', 'unit_price': 'DECIMAL(10,2)'});

-- ---------------------------------------------------------- payments_provider
create or replace table payments_provider.payments as
select * from read_csv('data/payments.csv', header = true,
    columns = {'payment_id': 'INTEGER', 'order_id': 'INTEGER', 'payment_method': 'VARCHAR',
               'status': 'VARCHAR', 'amount_cents': 'INTEGER', 'currency': 'VARCHAR',
               'created_at': 'TIMESTAMP', '_loaded_at': 'TIMESTAMP'});

-- refunded_at is TEXT in the provider export (format DD/MM/YYYY HH:MI) -- on purpose
create or replace table payments_provider.refunds as
select * from read_csv('data/refunds.csv', header = true,
    columns = {'refund_id': 'INTEGER', 'payment_id': 'INTEGER', 'amount_cents': 'INTEGER',
               'reason': 'VARCHAR', 'refunded_at': 'VARCHAR'});

-- ---------------------------------------------------------- web_analytics
create or replace table web_analytics.events as
select * from read_csv('data/events.csv', header = true,
    columns = {'event_id': 'VARCHAR', 'session_id': 'VARCHAR', 'customer_id': 'INTEGER',
               'event_type': 'VARCHAR', 'event_timestamp': 'TIMESTAMP', 'page': 'VARCHAR',
               '_loaded_at': 'TIMESTAMP'});

-- ---------------------------------------------------------- shipping
create or replace table shipping.shipments as
select * from read_csv('data/shipments.csv', header = true,
    columns = {'shipment_id': 'INTEGER', 'order_id': 'INTEGER', 'carrier': 'VARCHAR',
               'tracking_number': 'VARCHAR', 'status': 'VARCHAR', 'shipped_at': 'TIMESTAMP',
               'delivered_at': 'TIMESTAMP', 'updated_at': 'TIMESTAMP', '_loaded_at': 'TIMESTAMP'});

-- quick check: one row per table with its row count
select 'shopflow_app.customers' as table_name, count(*) as n_rows from shopflow_app.customers
union all select 'shopflow_app.addresses', count(*) from shopflow_app.addresses
union all select 'shopflow_app.products', count(*) from shopflow_app.products
union all select 'shopflow_app.orders', count(*) from shopflow_app.orders
union all select 'shopflow_app.order_items', count(*) from shopflow_app.order_items
union all select 'payments_provider.payments', count(*) from payments_provider.payments
union all select 'payments_provider.refunds', count(*) from payments_provider.refunds
union all select 'web_analytics.events', count(*) from web_analytics.events
union all select 'shipping.shipments', count(*) from shipping.shipments;
