-- =====================================================================
--  day2.sql -- ShopFlow, loading day 2026-01-01
--  From the shopflow-data folder:   duckdb shopflow.duckdb < updates/day2.sql
--  Apply it ONCE, after setup.sql (Chapter 26, milestone m08).
--  Reset everything: duckdb shopflow.duckdb < setup.sql
-- =====================================================================

-- products: 5 price changes, 1 product retired, 2 new products
update shopflow_app.products set price = 55.96, updated_at = '2026-01-01 08:58:00' where product_id = 2;
update shopflow_app.products set price = 28.27, updated_at = '2026-01-01 08:35:00' where product_id = 6;
update shopflow_app.products set price = 1081.00, updated_at = '2026-01-01 08:32:00' where product_id = 8;
update shopflow_app.products set price = 18.14, updated_at = '2026-01-01 08:27:00' where product_id = 19;
update shopflow_app.products set price = 17.34, updated_at = '2026-01-01 08:11:00' where product_id = 29;
update shopflow_app.products set is_active = false, updated_at = '2026-01-01 09:15:00' where product_id = 9;
insert into shopflow_app.products (product_id, sku, product_name, category, price, currency, is_active, created_at, updated_at) values
  (34, 'SF-HOM-0034', 'Mint Tea Glasses', 'home', '149.00', 'MAD', true, '2026-01-01 10:52:00', '2026-01-01 10:52:00'),
  (35, 'SF-ELE-0035', 'Travel Adapter', 'electronics', '24.90', 'EUR', true, '2026-01-01 10:00:00', '2026-01-01 10:00:00');

-- customers: 3 customers fix their email, 6 new customers
update shopflow_app.customers set email = 'karim.muller17@example.com', updated_at = '2026-01-01 11:17:00', _loaded_at = '2026-01-01 13:17:00' where customer_id = 17;
update shopflow_app.customers set email = 'adam.wilson23@mail.example.org', updated_at = '2026-01-01 11:23:00', _loaded_at = '2026-01-01 13:23:00' where customer_id = 23;
update shopflow_app.customers set email = 'liam.martin51@example.com', updated_at = '2026-01-01 11:51:00', _loaded_at = '2026-01-01 13:51:00' where customer_id = 51;
insert into shopflow_app.customers (customer_id, email, first_name, last_name, country_code, created_at, updated_at, _loaded_at) values
  (501, 'sara.dubois501@example.com', 'Sara', 'Dubois', 'ES', '2026-01-01 16:36:00', '2026-01-01 16:36:00', '2026-01-01 18:36:00'),
  (502, 'lucia.johnson502@example.com', 'Lucia', 'Johnson', 'MA', '2026-01-01 17:25:00', '2026-01-01 17:25:00', '2026-01-01 19:25:00'),
  (503, 'nora.moreau503@example.com', 'Nora', 'Moreau', 'FR', '2026-01-01 13:16:00', '2026-01-01 13:16:00', '2026-01-01 15:16:00'),
  (504, 'noah.muller504@example.com', 'Noah', 'Muller', 'MA', '2026-01-01 08:12:00', '2026-01-01 08:12:00', '2026-01-01 10:12:00'),
  (505, 'lucas.alaoui505@example.com', 'Lucas', 'Alaoui', 'FR', '2026-01-01 09:41:00', '2026-01-01 09:41:00', '2026-01-01 11:41:00'),
  (506, 'salma.evans506@example.com', 'Salma', 'Evans', 'ES', '2026-01-01 15:13:00', '2026-01-01 15:13:00', '2026-01-01 17:13:00');

-- orders: 65 paid->shipped, 90 shipped->delivered, 3 pending->cancelled
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 19:42:05', _loaded_at = '2026-01-01 20:42:05' where order_id = 2641;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 14:13:22', _loaded_at = '2026-01-01 15:13:22' where order_id = 2669;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 08:44:33', _loaded_at = '2026-01-01 11:44:33' where order_id = 2690;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 19:10:49', _loaded_at = '2026-01-01 21:10:49' where order_id = 2730;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 15:08:54', _loaded_at = '2026-01-01 18:08:54' where order_id = 2759;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 11:23:31', _loaded_at = '2026-01-01 12:23:31' where order_id = 2776;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 16:01:42', _loaded_at = '2026-01-01 18:01:42' where order_id = 2811;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 15:44:09', _loaded_at = '2026-01-01 17:44:09' where order_id = 2829;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 13:30:00', _loaded_at = '2026-01-01 14:30:00' where order_id = 2866;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 17:15:15', _loaded_at = '2026-01-01 20:15:15' where order_id = 2884;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 16:29:46', _loaded_at = '2026-01-01 17:29:46' where order_id = 2886;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 08:28:11', _loaded_at = '2026-01-01 10:28:11' where order_id = 2887;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 17:04:56', _loaded_at = '2026-01-01 18:04:56' where order_id = 2895;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 16:16:21', _loaded_at = '2026-01-01 17:16:21' where order_id = 2899;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 10:06:22', _loaded_at = '2026-01-01 12:06:22' where order_id = 2900;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 10:49:39', _loaded_at = '2026-01-01 12:49:39' where order_id = 2901;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 08:47:15', _loaded_at = '2026-01-01 09:47:15' where order_id = 2909;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 11:36:26', _loaded_at = '2026-01-01 14:36:26' where order_id = 2910;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 13:56:58', _loaded_at = '2026-01-01 15:56:58' where order_id = 2916;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 17:46:02', _loaded_at = '2026-01-01 19:46:02' where order_id = 2917;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 14:04:25', _loaded_at = '2026-01-01 15:04:25' where order_id = 2921;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 16:54:58', _loaded_at = '2026-01-01 17:54:58' where order_id = 2923;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 16:41:29', _loaded_at = '2026-01-01 18:41:29' where order_id = 2925;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 14:52:48', _loaded_at = '2026-01-01 15:52:48' where order_id = 2929;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 10:16:39', _loaded_at = '2026-01-01 11:16:39' where order_id = 2931;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 15:12:30', _loaded_at = '2026-01-01 18:12:30' where order_id = 2933;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 17:40:06', _loaded_at = '2026-01-01 19:40:06' where order_id = 2934;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 13:13:12', _loaded_at = '2026-01-01 16:13:12' where order_id = 2935;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 14:04:07', _loaded_at = '2026-01-01 17:04:07' where order_id = 2937;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 14:23:12', _loaded_at = '2026-01-01 16:23:12' where order_id = 2938;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 17:28:31', _loaded_at = '2026-01-01 19:28:31' where order_id = 2939;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 12:32:05', _loaded_at = '2026-01-01 13:32:05' where order_id = 2940;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 08:01:04', _loaded_at = '2026-01-01 10:01:04' where order_id = 2942;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 11:59:38', _loaded_at = '2026-01-01 14:59:38' where order_id = 2943;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 13:06:55', _loaded_at = '2026-01-01 15:06:55' where order_id = 2945;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 11:34:05', _loaded_at = '2026-01-01 13:34:05' where order_id = 2949;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 12:21:01', _loaded_at = '2026-01-01 13:21:01' where order_id = 2951;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 13:09:33', _loaded_at = '2026-01-01 15:09:33' where order_id = 2954;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 15:39:38', _loaded_at = '2026-01-01 16:39:38' where order_id = 2957;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 11:24:35', _loaded_at = '2026-01-01 14:24:35' where order_id = 2959;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 13:28:58', _loaded_at = '2026-01-01 14:28:58' where order_id = 2961;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 17:08:26', _loaded_at = '2026-01-01 18:08:26' where order_id = 2964;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 08:51:15', _loaded_at = '2026-01-01 09:51:15' where order_id = 2965;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 09:09:13', _loaded_at = '2026-01-01 11:09:13' where order_id = 2968;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 09:52:00', _loaded_at = '2026-01-01 12:52:00' where order_id = 2969;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 15:32:55', _loaded_at = '2026-01-01 17:32:55' where order_id = 2970;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 16:58:20', _loaded_at = '2026-01-01 19:58:20' where order_id = 2971;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 13:44:06', _loaded_at = '2026-01-01 16:44:06' where order_id = 2972;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 08:56:11', _loaded_at = '2026-01-01 10:56:11' where order_id = 2973;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 16:25:00', _loaded_at = '2026-01-01 18:25:00' where order_id = 2974;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 13:58:30', _loaded_at = '2026-01-01 14:58:30' where order_id = 2975;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 09:05:50', _loaded_at = '2026-01-01 10:05:50' where order_id = 2976;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 17:43:11', _loaded_at = '2026-01-01 18:43:11' where order_id = 2977;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 13:02:48', _loaded_at = '2026-01-01 16:02:48' where order_id = 2979;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 11:48:33', _loaded_at = '2026-01-01 13:48:33' where order_id = 2980;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 14:36:48', _loaded_at = '2026-01-01 16:36:48' where order_id = 2981;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 10:42:15', _loaded_at = '2026-01-01 12:42:15' where order_id = 2982;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 08:02:19', _loaded_at = '2026-01-01 11:02:19' where order_id = 2984;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 11:11:10', _loaded_at = '2026-01-01 13:11:10' where order_id = 2986;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 15:43:45', _loaded_at = '2026-01-01 16:43:45' where order_id = 2987;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 14:23:55', _loaded_at = '2026-01-01 16:23:55' where order_id = 2989;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 15:55:35', _loaded_at = '2026-01-01 16:55:35' where order_id = 2992;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 10:15:02', _loaded_at = '2026-01-01 12:15:02' where order_id = 2993;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 17:37:42', _loaded_at = '2026-01-01 19:37:42' where order_id = 2996;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-01 08:07:06', _loaded_at = '2026-01-01 11:07:06' where order_id = 2999;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 11:46:52', _loaded_at = '2026-01-01 13:46:52' where order_id = 203;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 11:08:21', _loaded_at = '2026-01-01 13:08:21' where order_id = 215;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 10:22:02', _loaded_at = '2026-01-01 11:22:02' where order_id = 301;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 17:21:31', _loaded_at = '2026-01-01 18:21:31' where order_id = 362;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 14:25:45', _loaded_at = '2026-01-01 15:25:45' where order_id = 477;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 11:59:47', _loaded_at = '2026-01-01 14:59:47' where order_id = 535;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 17:08:19', _loaded_at = '2026-01-01 19:08:19' where order_id = 544;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 14:22:27', _loaded_at = '2026-01-01 15:22:27' where order_id = 603;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 14:53:29', _loaded_at = '2026-01-01 16:53:29' where order_id = 687;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 09:22:11', _loaded_at = '2026-01-01 10:22:11' where order_id = 818;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 17:08:22', _loaded_at = '2026-01-01 20:08:22' where order_id = 841;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 15:30:54', _loaded_at = '2026-01-01 18:30:54' where order_id = 1058;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 17:02:14', _loaded_at = '2026-01-01 19:02:14' where order_id = 1060;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 15:37:10', _loaded_at = '2026-01-01 16:37:10' where order_id = 1088;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 15:06:39', _loaded_at = '2026-01-01 18:06:39' where order_id = 1152;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 08:39:30', _loaded_at = '2026-01-01 11:39:30' where order_id = 1380;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 13:42:28', _loaded_at = '2026-01-01 16:42:28' where order_id = 1491;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 13:37:57', _loaded_at = '2026-01-01 15:37:57' where order_id = 1506;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 13:31:33', _loaded_at = '2026-01-01 15:31:33' where order_id = 1540;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 17:48:29', _loaded_at = '2026-01-01 19:48:29' where order_id = 1647;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 12:10:02', _loaded_at = '2026-01-01 15:10:02' where order_id = 2140;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 16:24:38', _loaded_at = '2026-01-01 18:24:38' where order_id = 2152;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 16:22:30', _loaded_at = '2026-01-01 19:22:30' where order_id = 2295;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 11:50:14', _loaded_at = '2026-01-01 12:50:14' where order_id = 2369;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 10:45:40', _loaded_at = '2026-01-01 13:45:40' where order_id = 2407;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 12:26:41', _loaded_at = '2026-01-01 13:26:41' where order_id = 2452;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 14:14:25', _loaded_at = '2026-01-01 17:14:25' where order_id = 2602;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 10:25:32', _loaded_at = '2026-01-01 11:25:32' where order_id = 2638;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 19:42:05', _loaded_at = '2026-01-01 20:42:05' where order_id = 2641;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 12:45:35', _loaded_at = '2026-01-01 15:45:35' where order_id = 2651;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 08:35:56', _loaded_at = '2026-01-01 09:35:56' where order_id = 2665;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 11:05:49', _loaded_at = '2026-01-01 13:05:49' where order_id = 2680;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 10:13:32', _loaded_at = '2026-01-01 13:13:32' where order_id = 2684;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 16:07:17', _loaded_at = '2026-01-01 19:07:17' where order_id = 2685;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 14:03:35', _loaded_at = '2026-01-01 17:03:35' where order_id = 2688;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 16:45:31', _loaded_at = '2026-01-01 17:45:31' where order_id = 2694;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 13:02:32', _loaded_at = '2026-01-01 14:02:32' where order_id = 2695;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 09:45:37', _loaded_at = '2026-01-01 10:45:37' where order_id = 2701;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 13:46:50', _loaded_at = '2026-01-01 15:46:50' where order_id = 2704;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 15:56:06', _loaded_at = '2026-01-01 16:56:06' where order_id = 2705;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 09:05:42', _loaded_at = '2026-01-01 12:05:42' where order_id = 2707;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 08:48:42', _loaded_at = '2026-01-01 09:48:42' where order_id = 2708;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 09:13:15', _loaded_at = '2026-01-01 12:13:15' where order_id = 2713;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 13:29:12', _loaded_at = '2026-01-01 16:29:12' where order_id = 2714;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 09:09:19', _loaded_at = '2026-01-01 10:09:19' where order_id = 2715;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 13:24:32', _loaded_at = '2026-01-01 16:24:32' where order_id = 2717;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 10:01:41', _loaded_at = '2026-01-01 12:01:41' where order_id = 2722;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 11:25:04', _loaded_at = '2026-01-01 12:25:04' where order_id = 2727;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 19:10:49', _loaded_at = '2026-01-01 21:10:49' where order_id = 2730;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 10:34:06', _loaded_at = '2026-01-01 12:34:06' where order_id = 2735;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 13:03:04', _loaded_at = '2026-01-01 16:03:04' where order_id = 2745;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 15:46:09', _loaded_at = '2026-01-01 18:46:09' where order_id = 2746;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 10:54:56', _loaded_at = '2026-01-01 13:54:56' where order_id = 2747;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 10:28:53', _loaded_at = '2026-01-01 12:28:53' where order_id = 2751;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 09:02:53', _loaded_at = '2026-01-01 12:02:53' where order_id = 2753;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 12:12:05', _loaded_at = '2026-01-01 14:12:05' where order_id = 2760;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 13:09:46', _loaded_at = '2026-01-01 15:09:46' where order_id = 2768;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 17:05:08', _loaded_at = '2026-01-01 20:05:08' where order_id = 2771;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 15:25:35', _loaded_at = '2026-01-01 18:25:35' where order_id = 2773;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 16:22:04', _loaded_at = '2026-01-01 18:22:04' where order_id = 2774;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 11:23:31', _loaded_at = '2026-01-01 12:23:31' where order_id = 2776;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 15:07:46', _loaded_at = '2026-01-01 16:07:46' where order_id = 2784;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 12:18:26', _loaded_at = '2026-01-01 15:18:26' where order_id = 2785;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 15:45:56', _loaded_at = '2026-01-01 17:45:56' where order_id = 2791;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 10:00:20', _loaded_at = '2026-01-01 13:00:20' where order_id = 2797;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 10:42:48', _loaded_at = '2026-01-01 13:42:48' where order_id = 2798;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 14:45:43', _loaded_at = '2026-01-01 15:45:43' where order_id = 2802;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 13:53:01', _loaded_at = '2026-01-01 14:53:01' where order_id = 2810;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 16:01:42', _loaded_at = '2026-01-01 18:01:42' where order_id = 2811;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 15:07:48', _loaded_at = '2026-01-01 16:07:48' where order_id = 2812;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 11:46:05', _loaded_at = '2026-01-01 12:46:05' where order_id = 2814;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 08:24:52', _loaded_at = '2026-01-01 11:24:52' where order_id = 2820;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 16:26:52', _loaded_at = '2026-01-01 19:26:52' where order_id = 2823;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 13:37:52', _loaded_at = '2026-01-01 16:37:52' where order_id = 2824;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 09:53:58', _loaded_at = '2026-01-01 10:53:58' where order_id = 2826;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 14:50:22', _loaded_at = '2026-01-01 17:50:22' where order_id = 2837;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 10:16:35', _loaded_at = '2026-01-01 11:16:35' where order_id = 2838;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 17:19:32', _loaded_at = '2026-01-01 19:19:32' where order_id = 2839;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 11:51:42', _loaded_at = '2026-01-01 14:51:42' where order_id = 2840;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 16:21:41', _loaded_at = '2026-01-01 17:21:41' where order_id = 2841;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 17:49:35', _loaded_at = '2026-01-01 18:49:35' where order_id = 2844;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 11:10:16', _loaded_at = '2026-01-01 13:10:16' where order_id = 2849;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 14:44:25', _loaded_at = '2026-01-01 16:44:25' where order_id = 2856;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 15:32:48', _loaded_at = '2026-01-01 18:32:48' where order_id = 2861;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 14:49:30', _loaded_at = '2026-01-01 16:49:30' where order_id = 2862;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 12:03:51', _loaded_at = '2026-01-01 13:03:51' where order_id = 2863;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 13:30:00', _loaded_at = '2026-01-01 14:30:00' where order_id = 2866;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 16:06:25', _loaded_at = '2026-01-01 19:06:25' where order_id = 2868;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 17:25:27', _loaded_at = '2026-01-01 20:25:27' where order_id = 2870;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-01 16:19:51', _loaded_at = '2026-01-01 19:19:51' where order_id = 2880;
update shopflow_app.orders set status = 'cancelled', updated_at = '2026-01-01 08:34:40', _loaded_at = '2026-01-01 09:34:40' where order_id = 2902;
update shopflow_app.orders set status = 'cancelled', updated_at = '2026-01-01 09:48:47', _loaded_at = '2026-01-01 11:48:47' where order_id = 2906;
update shopflow_app.orders set status = 'cancelled', updated_at = '2026-01-01 13:46:52', _loaded_at = '2026-01-01 16:46:52' where order_id = 2914;

-- 40 new orders placed on 2026-01-01 (+ items and payments)
insert into shopflow_app.orders (order_id, customer_id, order_at, status, currency, shipping_address_id, updated_at, _loaded_at) values
  (3001, 500, '2026-01-01 11:04:47', 'paid', 'MAD', 636, '2026-01-01 11:24:47', '2026-01-01 14:15:47'),
  (3002, 475, '2026-01-01 12:36:08', 'paid', 'EUR', 603, '2026-01-01 12:53:08', '2026-01-01 16:20:08'),
  (3003, 448, '2026-01-01 20:59:43', 'paid', 'MAD', 567, '2026-01-01 21:24:43', '2026-01-01 23:41:43'),
  (3004, 218, '2026-01-01 10:32:50', 'paid', 'EUR', 276, '2026-01-01 10:46:50', '2026-01-01 15:00:50'),
  (3005, 126, '2026-01-01 14:53:06', 'paid', 'MAD', 163, '2026-01-01 15:09:06', '2026-01-01 17:11:06'),
  (3006, 81, '2026-01-01 07:51:53', 'paid', 'EUR', 100, '2026-01-01 07:58:53', '2026-01-01 11:04:53'),
  (3007, 275, '2026-01-01 09:03:48', 'paid', 'EUR', 346, '2026-01-01 09:18:48', '2026-01-01 12:53:48'),
  (3008, 417, '2026-01-01 14:25:09', 'pending', 'MAD', 526, '2026-01-01 15:11:09', '2026-01-01 16:11:09'),
  (3009, 201, '2026-01-01 08:46:53', 'paid', 'EUR', 254, '2026-01-01 08:59:53', '2026-01-01 10:00:53'),
  (3010, 129, '2026-01-01 18:08:10', 'paid', 'EUR', 167, '2026-01-01 18:30:10', '2026-01-01 21:55:10'),
  (3011, 391, '2026-01-01 20:32:17', 'paid', 'EUR', 493, '2026-01-01 20:55:17', '2026-01-02 00:39:17'),
  (3012, 220, '2026-01-01 10:12:21', 'pending', 'USD', 278, '2026-01-01 10:49:21', '2026-01-01 14:42:21'),
  (3013, 321, '2026-01-01 10:24:17', 'paid', 'EUR', 405, '2026-01-01 10:29:17', '2026-01-01 12:40:17'),
  (3014, 208, '2026-01-01 19:44:54', 'pending', 'EUR', 263, '2026-01-01 20:24:54', '2026-01-01 22:53:54'),
  (3015, 487, '2026-01-01 19:16:29', 'pending', 'EUR', 618, '2026-01-01 20:05:29', '2026-01-01 21:07:29'),
  (3016, 205, '2026-01-01 07:07:48', 'paid', 'MAD', 259, '2026-01-01 07:17:48', '2026-01-01 09:50:48'),
  (3017, 53, '2026-01-01 14:00:52', 'paid', 'EUR', 67, '2026-01-01 14:13:52', '2026-01-01 18:09:52'),
  (3018, 401, '2026-01-01 13:56:53', 'paid', 'EUR', 505, '2026-01-01 14:10:53', '2026-01-01 16:05:53'),
  (3019, 33, '2026-01-01 08:12:16', 'paid', 'USD', 41, '2026-01-01 08:23:16', '2026-01-01 10:51:16'),
  (3020, 309, '2026-01-01 16:42:28', 'paid', 'MAD', 389, '2026-01-01 16:54:28', '2026-01-01 20:51:28'),
  (3021, 315, '2026-01-01 13:38:24', 'paid', 'EUR', 398, '2026-01-01 13:54:24', '2026-01-01 16:00:24'),
  (3022, 394, '2026-01-01 16:00:51', 'paid', 'USD', 496, '2026-01-01 16:11:51', '2026-01-01 17:17:51'),
  (3023, 274, '2026-01-01 08:39:14', 'paid', 'EUR', 345, '2026-01-01 09:02:14', '2026-01-01 13:20:14'),
  (3024, 476, '2026-01-01 15:46:18', 'paid', 'EUR', 604, '2026-01-01 16:01:18', '2026-01-01 20:18:18'),
  (3025, 377, '2026-01-01 16:14:08', 'paid', 'MAD', 476, '2026-01-01 16:31:08', '2026-01-01 19:01:08'),
  (3026, 473, '2026-01-01 10:25:27', 'paid', 'MAD', 599, '2026-01-01 10:29:27', '2026-01-01 11:45:27'),
  (3027, 114, '2026-01-01 08:31:37', 'paid', 'EUR', 147, '2026-01-01 08:53:37', '2026-01-01 11:22:37'),
  (3028, 83, '2026-01-01 20:13:54', 'paid', 'MAD', 103, '2026-01-01 20:18:54', '2026-01-02 00:52:54'),
  (3029, 480, '2026-01-01 12:59:27', 'paid', 'EUR', 609, '2026-01-01 13:12:27', '2026-01-01 15:55:27'),
  (3030, 396, '2026-01-01 16:33:42', 'paid', 'MAD', 498, '2026-01-01 16:41:42', '2026-01-01 18:26:42'),
  (3031, 3, '2026-01-01 11:55:52', 'paid', 'EUR', 3, '2026-01-01 12:15:52', '2026-01-01 14:48:52'),
  (3032, 351, '2026-01-01 20:45:28', 'paid', 'EUR', 445, '2026-01-01 21:00:28', '2026-01-01 22:29:28'),
  (3033, 398, '2026-01-01 20:40:27', 'pending', 'EUR', 501, '2026-01-01 20:51:27', '2026-01-01 22:39:27'),
  (3034, 32, '2026-01-01 19:31:36', 'paid', 'MAD', 40, '2026-01-01 19:40:36', '2026-01-01 23:07:36'),
  (3035, 461, '2026-01-01 10:36:43', 'pending', 'EUR', 584, '2026-01-01 11:21:43', '2026-01-01 16:20:43'),
  (3036, 435, '2026-01-01 16:36:49', 'paid', 'EUR', 548, '2026-01-01 16:40:49', '2026-01-01 19:03:49'),
  (3037, 429, '2026-01-01 08:32:43', 'paid', 'MAD', 542, '2026-01-01 08:38:43', '2026-01-01 09:56:43'),
  (3038, 109, '2026-01-01 08:58:13', 'paid', 'EUR', 141, '2026-01-01 09:15:13', '2026-01-01 12:25:13'),
  (3039, 79, '2026-01-01 09:30:32', 'paid', 'MAD', 98, '2026-01-01 09:51:32', '2026-01-01 12:37:32'),
  (3040, 405, '2026-01-01 09:08:05', 'paid', 'MAD', 511, '2026-01-01 09:20:05', '2026-01-01 13:35:05');
insert into shopflow_app.order_items (order_item_id, order_id, product_id, quantity, unit_price) values
  (5884, 3001, 32, 1, '124.46'),
  (5885, 3001, 25, 2, '120.61'),
  (5886, 3002, 24, 1, '11.24'),
  (5887, 3003, 31, 2, '182.90'),
  (5888, 3003, 10, 2, '281.17'),
  (5889, 3004, 6, 1, '30.54'),
  (5890, 3004, 12, 1, '87.98'),
  (5891, 3004, 16, 1, '105.89'),
  (5892, 3005, 9, 3, '276.10'),
  (5893, 3005, 27, 2, '212.88'),
  (5894, 3006, 29, 1, '15.08'),
  (5895, 3007, 16, 1, '105.89'),
  (5896, 3007, 9, 2, '25.51'),
  (5897, 3007, 27, 1, '19.67'),
  (5898, 3008, 18, 1, '174.46'),
  (5899, 3009, 23, 2, '24.29'),
  (5900, 3009, 19, 2, '15.12'),
  (5901, 3010, 30, 1, '8.83'),
  (5902, 3011, 9, 1, '25.51'),
  (5903, 3012, 7, 1, '131.90'),
  (5904, 3013, 22, 2, '7.37'),
  (5905, 3014, 17, 1, '79.17'),
  (5906, 3014, 9, 1, '25.51'),
  (5907, 3015, 7, 2, '119.95'),
  (5908, 3015, 3, 1, '50.82'),
  (5909, 3016, 14, 1, '657.25'),
  (5910, 3016, 20, 3, '398.70'),
  (5911, 3016, 22, 2, '79.74'),
  (5912, 3017, 11, 3, '85.70'),
  (5913, 3018, 24, 1, '11.24'),
  (5914, 3019, 3, 1, '55.88'),
  (5915, 3019, 23, 1, '26.71'),
  (5916, 3020, 32, 1, '124.46'),
  (5917, 3020, 27, 3, '212.88'),
  (5918, 3020, 9, 3, '276.10'),
  (5919, 3021, 26, 1, '5.04'),
  (5920, 3021, 14, 1, '60.73'),
  (5921, 3022, 22, 2, '8.10'),
  (5922, 3022, 4, 2, '152.85'),
  (5923, 3022, 32, 1, '12.65'),
  (5924, 3023, 7, 2, '119.95'),
  (5925, 3023, 24, 1, '11.24'),
  (5926, 3024, 21, 1, '50.07'),
  (5927, 3024, 22, 1, '7.37'),
  (5928, 3025, 25, 1, '120.61'),
  (5929, 3025, 5, 2, '1574.24'),
  (5930, 3025, 26, 1, '54.55'),
  (5931, 3026, 20, 2, '398.70'),
  (5932, 3026, 8, 1, '936.95'),
  (5933, 3026, 16, 1, '1146.00'),
  (5934, 3026, 24, 1, '121.60'),
  (5935, 3027, 29, 1, '15.08'),
  (5936, 3027, 21, 1, '50.07'),
  (5937, 3027, 25, 1, '11.14'),
  (5938, 3028, 21, 1, '541.88'),
  (5939, 3029, 31, 1, '16.90'),
  (5940, 3030, 20, 1, '398.70'),
  (5941, 3030, 25, 1, '120.61'),
  (5942, 3030, 9, 3, '276.10'),
  (5943, 3031, 6, 1, '30.54'),
  (5944, 3031, 10, 1, '25.98'),
  (5945, 3031, 24, 1, '11.24'),
  (5946, 3032, 9, 1, '25.51'),
  (5947, 3033, 10, 1, '25.98'),
  (5948, 3034, 8, 1, '936.95'),
  (5949, 3035, 18, 1, '16.12'),
  (5950, 3035, 15, 2, '23.76'),
  (5951, 3036, 15, 1, '23.76'),
  (5952, 3036, 8, 1, '86.57'),
  (5953, 3037, 14, 1, '657.25'),
  (5954, 3037, 15, 1, '257.16'),
  (5955, 3038, 30, 2, '8.83'),
  (5956, 3038, 1, 2, '68.17'),
  (5957, 3039, 23, 1, '262.88'),
  (5958, 3039, 19, 1, '163.64'),
  (5959, 3039, 7, 2, '1298.16'),
  (5960, 3040, 24, 1, '121.60'),
  (5961, 3040, 27, 2, '212.88'),
  (5962, 3040, 21, 1, '541.88');
insert into payments_provider.payments (payment_id, order_id, payment_method, status, amount_cents, currency, created_at, _loaded_at) values
  (3171, 3001, 'paypal', 'succeeded', 36568, 'MAD', '2026-01-01 11:21:47', '2026-01-01 11:49:47'),
  (3172, 3002, 'paypal', 'succeeded', 1124, 'EUR', '2026-01-01 12:48:08', '2026-01-01 13:17:08'),
  (3173, 3003, 'cash_on_delivery', 'failed', 92814, 'MAD', '2026-01-01 21:02:43', '2026-01-01 22:19:43'),
  (3174, 3003, 'card', 'succeeded', 92814, 'MAD', '2026-01-01 21:23:43', '2026-01-01 22:35:43'),
  (3175, 3004, 'paypal', 'succeeded', 22441, 'EUR', '2026-01-01 10:42:50', '2026-01-01 11:42:50'),
  (3176, 3005, 'gift_card', 'succeeded', 2000, 'MAD', '2026-01-01 15:05:06', '2026-01-01 15:48:06'),
  (3177, 3005, 'card', 'succeeded', 123406, 'MAD', '2026-01-01 15:06:06', '2026-01-01 15:56:06'),
  (3178, 3006, 'paypal', 'succeeded', 1508, 'EUR', '2026-01-01 07:53:53', '2026-01-01 09:20:53'),
  (3179, 3007, 'card', 'succeeded', 17658, 'EUR', '2026-01-01 09:13:48', '2026-01-01 09:24:48'),
  (3180, 3008, 'card', 'pending', 17446, 'MAD', '2026-01-01 14:32:09', '2026-01-01 15:14:09'),
  (3181, 3009, 'paypal', 'succeeded', 7882, 'EUR', '2026-01-01 08:55:53', '2026-01-01 09:13:53'),
  (3182, 3010, 'card', 'succeeded', 883, 'EUR', '2026-01-01 18:28:10', '2026-01-01 19:24:10'),
  (3183, 3011, 'card', 'succeeded', 2551, 'EUR', '2026-01-01 20:50:17', '2026-01-01 21:00:17'),
  (3184, 3013, 'paypal', 'succeeded', 1474, 'EUR', '2026-01-01 10:25:17', '2026-01-01 10:56:17'),
  (3185, 3014, 'bank_transfer', 'pending', 10468, 'EUR', '2026-01-01 19:56:54', '2026-01-01 20:24:54'),
  (3186, 3016, 'bank_transfer', 'succeeded', 201283, 'MAD', '2026-01-01 07:16:48', '2026-01-01 08:05:48'),
  (3187, 3017, 'card', 'succeeded', 25710, 'EUR', '2026-01-01 14:09:52', '2026-01-01 14:36:52'),
  (3188, 3018, 'paypal', 'succeeded', 1124, 'EUR', '2026-01-01 14:05:53', '2026-01-01 15:00:53'),
  (3189, 3019, 'paypal', 'succeeded', 8259, 'USD', '2026-01-01 08:21:16', '2026-01-01 09:03:16'),
  (3190, 3020, 'card', 'succeeded', 159140, 'MAD', '2026-01-01 16:50:28', '2026-01-01 17:50:28'),
  (3191, 3021, 'card', 'succeeded', 6577, 'EUR', '2026-01-01 13:49:24', '2026-01-01 14:50:24'),
  (3192, 3022, 'bank_transfer', 'succeeded', 33455, 'USD', '2026-01-01 16:10:51', '2026-01-01 17:07:51'),
  (3193, 3023, 'card', 'succeeded', 25114, 'EUR', '2026-01-01 08:59:14', '2026-01-01 09:11:14'),
  (3194, 3024, 'card', 'succeeded', 5744, 'EUR', '2026-01-01 16:00:18', '2026-01-01 16:39:18'),
  (3195, 3025, 'cash_on_delivery', 'succeeded', 332364, 'MAD', '2026-01-01 16:30:08', '2026-01-01 17:41:08'),
  (3196, 3026, 'bank_transfer', 'succeeded', 300195, 'MAD', '2026-01-01 10:27:27', '2026-01-01 11:53:27'),
  (3197, 3027, 'card', 'succeeded', 7629, 'EUR', '2026-01-01 08:49:37', '2026-01-01 09:28:37'),
  (3198, 3028, 'paypal', 'succeeded', 54188, 'MAD', '2026-01-01 20:15:54', '2026-01-01 21:21:54'),
  (3199, 3029, 'paypal', 'succeeded', 1690, 'EUR', '2026-01-01 13:11:27', '2026-01-01 14:04:27'),
  (3200, 3030, 'paypal', 'succeeded', 134761, 'MAD', '2026-01-01 16:36:42', '2026-01-01 17:02:42'),
  (3201, 3031, 'paypal', 'succeeded', 6776, 'EUR', '2026-01-01 12:12:52', '2026-01-01 13:26:52'),
  (3202, 3032, 'card', 'succeeded', 2551, 'EUR', '2026-01-01 20:59:28', '2026-01-01 22:24:28'),
  (3203, 3034, 'card', 'succeeded', 93695, 'MAD', '2026-01-01 19:38:36', '2026-01-01 19:56:36'),
  (3204, 3035, 'paypal', 'pending', 6364, 'EUR', '2026-01-01 10:49:43', '2026-01-01 11:06:43'),
  (3205, 3036, 'paypal', 'succeeded', 11033, 'EUR', '2026-01-01 16:37:49', '2026-01-01 17:36:49'),
  (3206, 3037, 'bank_transfer', 'succeeded', 91441, 'MAD', '2026-01-01 08:33:43', '2026-01-01 08:57:43'),
  (3207, 3038, 'card', 'succeeded', 15400, 'EUR', '2026-01-01 09:14:13', '2026-01-01 09:55:13'),
  (3208, 3039, 'card', 'succeeded', 302284, 'MAD', '2026-01-01 09:50:32', '2026-01-01 11:12:32'),
  (3209, 3040, 'cash_on_delivery', 'succeeded', 108924, 'MAD', '2026-01-01 09:15:05', '2026-01-01 09:43:05');

-- shipments: 65 new (in_transit), 90 delivered
insert into shipping.shipments (shipment_id, order_id, carrier, tracking_number, status, shipped_at, delivered_at, updated_at, _loaded_at) values
  (2647, 2641, 'Amana', 'TRK00264180', 'delivered', '2026-01-01 17:42:05', '2026-01-01 19:42:05', '2026-01-01 19:42:05', '2026-01-01 20:42:05'),
  (2648, 2669, 'CTM Messagerie', 'TRK00266979', 'in_transit', '2026-01-01 14:13:22', null, '2026-01-01 14:13:22', '2026-01-01 15:13:22'),
  (2649, 2690, 'FedEx', 'TRK00269055', 'in_transit', '2026-01-01 08:44:33', null, '2026-01-01 08:44:33', '2026-01-01 11:44:33'),
  (2650, 2730, 'DHL', 'TRK00273052', 'delivered', '2026-01-01 17:10:49', '2026-01-01 19:10:49', '2026-01-01 19:10:49', '2026-01-01 21:10:49'),
  (2651, 2759, 'DHL', 'TRK00275919', 'in_transit', '2026-01-01 15:08:54', null, '2026-01-01 15:08:54', '2026-01-01 18:08:54'),
  (2652, 2776, 'UPS', 'TRK00277633', 'delivered', '2026-01-01 09:23:31', '2026-01-01 11:23:31', '2026-01-01 11:23:31', '2026-01-01 12:23:31'),
  (2653, 2811, 'CTM Messagerie', 'TRK00281164', 'delivered', '2026-01-01 13:03:06', '2026-01-01 16:01:42', '2026-01-01 16:01:42', '2026-01-01 18:01:42'),
  (2654, 2829, 'bpost', 'TRK00282998', 'in_transit', '2026-01-01 15:44:09', null, '2026-01-01 15:44:09', '2026-01-01 17:44:09'),
  (2655, 2866, 'bpost', 'TRK00286659', 'delivered', '2026-01-01 11:30:00', '2026-01-01 13:30:00', '2026-01-01 13:30:00', '2026-01-01 14:30:00'),
  (2656, 2884, 'DHL', 'TRK00288489', 'in_transit', '2026-01-01 17:15:15', null, '2026-01-01 17:15:15', '2026-01-01 20:15:15'),
  (2657, 2886, 'FedEx', 'TRK00288649', 'in_transit', '2026-01-01 16:29:46', null, '2026-01-01 16:29:46', '2026-01-01 17:29:46'),
  (2658, 2887, 'UPS', 'TRK00288756', 'in_transit', '2026-01-01 08:28:11', null, '2026-01-01 08:28:11', '2026-01-01 10:28:11'),
  (2659, 2895, 'UPS', 'TRK00289532', 'in_transit', '2026-01-01 17:04:56', null, '2026-01-01 17:04:56', '2026-01-01 18:04:56'),
  (2660, 2899, 'CTM Messagerie', 'TRK00289976', 'in_transit', '2026-01-01 16:16:21', null, '2026-01-01 16:16:21', '2026-01-01 17:16:21'),
  (2661, 2900, 'UPS', 'TRK00290069', 'in_transit', '2026-01-01 10:06:22', null, '2026-01-01 10:06:22', '2026-01-01 12:06:22'),
  (2662, 2901, 'DHL', 'TRK00290160', 'in_transit', '2026-01-01 10:49:39', null, '2026-01-01 10:49:39', '2026-01-01 12:49:39'),
  (2663, 2909, 'Amana', 'TRK00290912', 'in_transit', '2026-01-01 08:47:15', null, '2026-01-01 08:47:15', '2026-01-01 09:47:15'),
  (2664, 2910, 'CTM Messagerie', 'TRK00291044', 'in_transit', '2026-01-01 11:36:26', null, '2026-01-01 11:36:26', '2026-01-01 14:36:26'),
  (2665, 2916, 'DHL', 'TRK00291663', 'in_transit', '2026-01-01 13:56:58', null, '2026-01-01 13:56:58', '2026-01-01 15:56:58'),
  (2666, 2917, 'DHL', 'TRK00291731', 'in_transit', '2026-01-01 17:46:02', null, '2026-01-01 17:46:02', '2026-01-01 19:46:02'),
  (2667, 2921, 'CTM Messagerie', 'TRK00292181', 'in_transit', '2026-01-01 14:04:25', null, '2026-01-01 14:04:25', '2026-01-01 15:04:25'),
  (2668, 2923, 'Amana', 'TRK00292328', 'in_transit', '2026-01-01 16:54:58', null, '2026-01-01 16:54:58', '2026-01-01 17:54:58'),
  (2669, 2925, 'Amana', 'TRK00292539', 'in_transit', '2026-01-01 16:41:29', null, '2026-01-01 16:41:29', '2026-01-01 18:41:29'),
  (2670, 2929, 'DHL', 'TRK00292992', 'in_transit', '2026-01-01 14:52:48', null, '2026-01-01 14:52:48', '2026-01-01 15:52:48'),
  (2671, 2931, 'Colissimo', 'TRK00293115', 'in_transit', '2026-01-01 10:16:39', null, '2026-01-01 10:16:39', '2026-01-01 11:16:39'),
  (2672, 2933, 'FedEx', 'TRK00293385', 'in_transit', '2026-01-01 15:12:30', null, '2026-01-01 15:12:30', '2026-01-01 18:12:30'),
  (2673, 2934, 'DHL', 'TRK00293491', 'in_transit', '2026-01-01 17:40:06', null, '2026-01-01 17:40:06', '2026-01-01 19:40:06'),
  (2674, 2935, 'Colissimo', 'TRK00293540', 'in_transit', '2026-01-01 13:13:12', null, '2026-01-01 13:13:12', '2026-01-01 16:13:12'),
  (2675, 2937, 'Colissimo', 'TRK00293747', 'in_transit', '2026-01-01 14:04:07', null, '2026-01-01 14:04:07', '2026-01-01 17:04:07'),
  (2676, 2938, 'CTM Messagerie', 'TRK00293886', 'in_transit', '2026-01-01 14:23:12', null, '2026-01-01 14:23:12', '2026-01-01 16:23:12'),
  (2677, 2939, 'Colissimo', 'TRK00293946', 'in_transit', '2026-01-01 17:28:31', null, '2026-01-01 17:28:31', '2026-01-01 19:28:31'),
  (2678, 2940, 'DHL', 'TRK00294066', 'in_transit', '2026-01-01 12:32:05', null, '2026-01-01 12:32:05', '2026-01-01 13:32:05'),
  (2679, 2942, 'FedEx', 'TRK00294214', 'in_transit', '2026-01-01 08:01:04', null, '2026-01-01 08:01:04', '2026-01-01 10:01:04'),
  (2680, 2943, 'DHL', 'TRK00294397', 'in_transit', '2026-01-01 11:59:38', null, '2026-01-01 11:59:38', '2026-01-01 14:59:38'),
  (2681, 2945, 'Amana', 'TRK00294576', 'in_transit', '2026-01-01 13:06:55', null, '2026-01-01 13:06:55', '2026-01-01 15:06:55'),
  (2682, 2949, 'Amana', 'TRK00294920', 'in_transit', '2026-01-01 11:34:05', null, '2026-01-01 11:34:05', '2026-01-01 13:34:05'),
  (2683, 2951, 'Amana', 'TRK00295116', 'in_transit', '2026-01-01 12:21:01', null, '2026-01-01 12:21:01', '2026-01-01 13:21:01'),
  (2684, 2954, 'FedEx', 'TRK00295451', 'in_transit', '2026-01-01 13:09:33', null, '2026-01-01 13:09:33', '2026-01-01 15:09:33'),
  (2685, 2957, 'DHL', 'TRK00295796', 'in_transit', '2026-01-01 15:39:38', null, '2026-01-01 15:39:38', '2026-01-01 16:39:38'),
  (2686, 2959, 'Amana', 'TRK00295995', 'in_transit', '2026-01-01 11:24:35', null, '2026-01-01 11:24:35', '2026-01-01 14:24:35'),
  (2687, 2961, 'CTM Messagerie', 'TRK00296181', 'in_transit', '2026-01-01 13:28:58', null, '2026-01-01 13:28:58', '2026-01-01 14:28:58'),
  (2688, 2964, 'CTM Messagerie', 'TRK00296445', 'in_transit', '2026-01-01 17:08:26', null, '2026-01-01 17:08:26', '2026-01-01 18:08:26'),
  (2689, 2965, 'Colissimo', 'TRK00296513', 'in_transit', '2026-01-01 08:51:15', null, '2026-01-01 08:51:15', '2026-01-01 09:51:15'),
  (2690, 2968, 'DHL', 'TRK00296885', 'in_transit', '2026-01-01 09:09:13', null, '2026-01-01 09:09:13', '2026-01-01 11:09:13'),
  (2691, 2969, 'Amana', 'TRK00296978', 'in_transit', '2026-01-01 09:52:00', null, '2026-01-01 09:52:00', '2026-01-01 12:52:00'),
  (2692, 2970, 'Colissimo', 'TRK00297037', 'in_transit', '2026-01-01 15:32:55', null, '2026-01-01 15:32:55', '2026-01-01 17:32:55'),
  (2693, 2971, 'bpost', 'TRK00297192', 'in_transit', '2026-01-01 16:58:20', null, '2026-01-01 16:58:20', '2026-01-01 19:58:20'),
  (2694, 2972, 'Amana', 'TRK00297230', 'in_transit', '2026-01-01 13:44:06', null, '2026-01-01 13:44:06', '2026-01-01 16:44:06'),
  (2695, 2973, 'DHL', 'TRK00297370', 'in_transit', '2026-01-01 08:56:11', null, '2026-01-01 08:56:11', '2026-01-01 10:56:11'),
  (2696, 2974, 'DHL', 'TRK00297486', 'in_transit', '2026-01-01 16:25:00', null, '2026-01-01 16:25:00', '2026-01-01 18:25:00'),
  (2697, 2975, 'Colissimo', 'TRK00297546', 'in_transit', '2026-01-01 13:58:30', null, '2026-01-01 13:58:30', '2026-01-01 14:58:30'),
  (2698, 2976, 'CTM Messagerie', 'TRK00297620', 'in_transit', '2026-01-01 09:05:50', null, '2026-01-01 09:05:50', '2026-01-01 10:05:50'),
  (2699, 2977, 'Colissimo', 'TRK00297783', 'in_transit', '2026-01-01 17:43:11', null, '2026-01-01 17:43:11', '2026-01-01 18:43:11'),
  (2700, 2979, 'CTM Messagerie', 'TRK00297948', 'in_transit', '2026-01-01 13:02:48', null, '2026-01-01 13:02:48', '2026-01-01 16:02:48'),
  (2701, 2980, 'Amana', 'TRK00298028', 'in_transit', '2026-01-01 11:48:33', null, '2026-01-01 11:48:33', '2026-01-01 13:48:33'),
  (2702, 2981, 'Amana', 'TRK00298155', 'in_transit', '2026-01-01 14:36:48', null, '2026-01-01 14:36:48', '2026-01-01 16:36:48'),
  (2703, 2982, 'Amana', 'TRK00298241', 'in_transit', '2026-01-01 10:42:15', null, '2026-01-01 10:42:15', '2026-01-01 12:42:15'),
  (2704, 2984, 'bpost', 'TRK00298417', 'in_transit', '2026-01-01 08:02:19', null, '2026-01-01 08:02:19', '2026-01-01 11:02:19'),
  (2705, 2986, 'FedEx', 'TRK00298673', 'in_transit', '2026-01-01 11:11:10', null, '2026-01-01 11:11:10', '2026-01-01 13:11:10'),
  (2706, 2987, 'Amana', 'TRK00298791', 'in_transit', '2026-01-01 15:43:45', null, '2026-01-01 15:43:45', '2026-01-01 16:43:45'),
  (2707, 2989, 'FedEx', 'TRK00298933', 'in_transit', '2026-01-01 14:23:55', null, '2026-01-01 14:23:55', '2026-01-01 16:23:55'),
  (2708, 2992, 'DHL', 'TRK00299235', 'in_transit', '2026-01-01 15:55:35', null, '2026-01-01 15:55:35', '2026-01-01 16:55:35'),
  (2709, 2993, 'CTM Messagerie', 'TRK00299352', 'in_transit', '2026-01-01 10:15:02', null, '2026-01-01 10:15:02', '2026-01-01 12:15:02'),
  (2710, 2996, 'Correos', 'TRK00299684', 'in_transit', '2026-01-01 17:37:42', null, '2026-01-01 17:37:42', '2026-01-01 19:37:42'),
  (2711, 2999, 'DHL', 'TRK00299948', 'in_transit', '2026-01-01 08:07:06', null, '2026-01-01 08:07:06', '2026-01-01 11:07:06');
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 11:46:52', updated_at = '2026-01-01 11:46:52', _loaded_at = '2026-01-01 13:46:52' where shipment_id = 185;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 11:08:21', updated_at = '2026-01-01 11:08:21', _loaded_at = '2026-01-01 13:08:21' where shipment_id = 197;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 10:22:02', updated_at = '2026-01-01 10:22:02', _loaded_at = '2026-01-01 11:22:02' where shipment_id = 278;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 17:21:31', updated_at = '2026-01-01 17:21:31', _loaded_at = '2026-01-01 18:21:31' where shipment_id = 335;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 14:25:45', updated_at = '2026-01-01 14:25:45', _loaded_at = '2026-01-01 15:25:45' where shipment_id = 443;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 11:59:47', updated_at = '2026-01-01 11:59:47', _loaded_at = '2026-01-01 14:59:47' where shipment_id = 497;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 17:08:19', updated_at = '2026-01-01 17:08:19', _loaded_at = '2026-01-01 19:08:19' where shipment_id = 505;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 14:22:27', updated_at = '2026-01-01 14:22:27', _loaded_at = '2026-01-01 15:22:27' where shipment_id = 560;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 14:53:29', updated_at = '2026-01-01 14:53:29', _loaded_at = '2026-01-01 16:53:29' where shipment_id = 639;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 09:22:11', updated_at = '2026-01-01 09:22:11', _loaded_at = '2026-01-01 10:22:11' where shipment_id = 756;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 17:08:22', updated_at = '2026-01-01 17:08:22', _loaded_at = '2026-01-01 20:08:22' where shipment_id = 779;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 15:30:54', updated_at = '2026-01-01 15:30:54', _loaded_at = '2026-01-01 18:30:54' where shipment_id = 978;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 17:02:14', updated_at = '2026-01-01 17:02:14', _loaded_at = '2026-01-01 19:02:14' where shipment_id = 980;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 15:37:10', updated_at = '2026-01-01 15:37:10', _loaded_at = '2026-01-01 16:37:10' where shipment_id = 1005;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 15:06:39', updated_at = '2026-01-01 15:06:39', _loaded_at = '2026-01-01 18:06:39' where shipment_id = 1062;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 08:39:30', updated_at = '2026-01-01 08:39:30', _loaded_at = '2026-01-01 11:39:30' where shipment_id = 1264;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 13:42:28', updated_at = '2026-01-01 13:42:28', _loaded_at = '2026-01-01 16:42:28' where shipment_id = 1369;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 13:37:57', updated_at = '2026-01-01 13:37:57', _loaded_at = '2026-01-01 15:37:57' where shipment_id = 1382;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 13:31:33', updated_at = '2026-01-01 13:31:33', _loaded_at = '2026-01-01 15:31:33' where shipment_id = 1411;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 17:48:29', updated_at = '2026-01-01 17:48:29', _loaded_at = '2026-01-01 19:48:29' where shipment_id = 1508;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 12:10:02', updated_at = '2026-01-01 12:10:02', _loaded_at = '2026-01-01 15:10:02' where shipment_id = 1957;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 16:24:38', updated_at = '2026-01-01 16:24:38', _loaded_at = '2026-01-01 18:24:38' where shipment_id = 1967;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 16:22:30', updated_at = '2026-01-01 16:22:30', _loaded_at = '2026-01-01 19:22:30' where shipment_id = 2093;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 11:50:14', updated_at = '2026-01-01 11:50:14', _loaded_at = '2026-01-01 12:50:14' where shipment_id = 2160;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 10:45:40', updated_at = '2026-01-01 10:45:40', _loaded_at = '2026-01-01 13:45:40' where shipment_id = 2192;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 12:26:41', updated_at = '2026-01-01 12:26:41', _loaded_at = '2026-01-01 13:26:41' where shipment_id = 2231;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 14:14:25', updated_at = '2026-01-01 14:14:25', _loaded_at = '2026-01-01 17:14:25' where shipment_id = 2370;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 10:25:32', updated_at = '2026-01-01 10:25:32', _loaded_at = '2026-01-01 11:25:32' where shipment_id = 2405;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 19:42:05', updated_at = '2026-01-01 19:42:05', _loaded_at = '2026-01-01 20:42:05' where shipment_id = 2647;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 12:45:35', updated_at = '2026-01-01 12:45:35', _loaded_at = '2026-01-01 15:45:35' where shipment_id = 2417;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 08:35:56', updated_at = '2026-01-01 08:35:56', _loaded_at = '2026-01-01 09:35:56' where shipment_id = 2430;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 11:05:49', updated_at = '2026-01-01 11:05:49', _loaded_at = '2026-01-01 13:05:49' where shipment_id = 2443;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 10:13:32', updated_at = '2026-01-01 10:13:32', _loaded_at = '2026-01-01 13:13:32' where shipment_id = 2446;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 16:07:17', updated_at = '2026-01-01 16:07:17', _loaded_at = '2026-01-01 19:07:17' where shipment_id = 2447;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 14:03:35', updated_at = '2026-01-01 14:03:35', _loaded_at = '2026-01-01 17:03:35' where shipment_id = 2450;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 16:45:31', updated_at = '2026-01-01 16:45:31', _loaded_at = '2026-01-01 17:45:31' where shipment_id = 2455;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 13:02:32', updated_at = '2026-01-01 13:02:32', _loaded_at = '2026-01-01 14:02:32' where shipment_id = 2456;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 09:45:37', updated_at = '2026-01-01 09:45:37', _loaded_at = '2026-01-01 10:45:37' where shipment_id = 2461;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 13:46:50', updated_at = '2026-01-01 13:46:50', _loaded_at = '2026-01-01 15:46:50' where shipment_id = 2464;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 15:56:06', updated_at = '2026-01-01 15:56:06', _loaded_at = '2026-01-01 16:56:06' where shipment_id = 2465;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 09:05:42', updated_at = '2026-01-01 09:05:42', _loaded_at = '2026-01-01 12:05:42' where shipment_id = 2467;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 08:48:42', updated_at = '2026-01-01 08:48:42', _loaded_at = '2026-01-01 09:48:42' where shipment_id = 2468;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 09:13:15', updated_at = '2026-01-01 09:13:15', _loaded_at = '2026-01-01 12:13:15' where shipment_id = 2473;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 13:29:12', updated_at = '2026-01-01 13:29:12', _loaded_at = '2026-01-01 16:29:12' where shipment_id = 2474;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 09:09:19', updated_at = '2026-01-01 09:09:19', _loaded_at = '2026-01-01 10:09:19' where shipment_id = 2475;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 13:24:32', updated_at = '2026-01-01 13:24:32', _loaded_at = '2026-01-01 16:24:32' where shipment_id = 2477;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 10:01:41', updated_at = '2026-01-01 10:01:41', _loaded_at = '2026-01-01 12:01:41' where shipment_id = 2482;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 11:25:04', updated_at = '2026-01-01 11:25:04', _loaded_at = '2026-01-01 12:25:04' where shipment_id = 2486;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 19:10:49', updated_at = '2026-01-01 19:10:49', _loaded_at = '2026-01-01 21:10:49' where shipment_id = 2650;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 10:34:06', updated_at = '2026-01-01 10:34:06', _loaded_at = '2026-01-01 12:34:06' where shipment_id = 2492;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 13:03:04', updated_at = '2026-01-01 13:03:04', _loaded_at = '2026-01-01 16:03:04' where shipment_id = 2502;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 15:46:09', updated_at = '2026-01-01 15:46:09', _loaded_at = '2026-01-01 18:46:09' where shipment_id = 2503;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 10:54:56', updated_at = '2026-01-01 10:54:56', _loaded_at = '2026-01-01 13:54:56' where shipment_id = 2504;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 10:28:53', updated_at = '2026-01-01 10:28:53', _loaded_at = '2026-01-01 12:28:53' where shipment_id = 2508;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 09:02:53', updated_at = '2026-01-01 09:02:53', _loaded_at = '2026-01-01 12:02:53' where shipment_id = 2510;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 12:12:05', updated_at = '2026-01-01 12:12:05', _loaded_at = '2026-01-01 14:12:05' where shipment_id = 2515;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 13:09:46', updated_at = '2026-01-01 13:09:46', _loaded_at = '2026-01-01 15:09:46' where shipment_id = 2523;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 17:05:08', updated_at = '2026-01-01 17:05:08', _loaded_at = '2026-01-01 20:05:08' where shipment_id = 2526;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 15:25:35', updated_at = '2026-01-01 15:25:35', _loaded_at = '2026-01-01 18:25:35' where shipment_id = 2528;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 16:22:04', updated_at = '2026-01-01 16:22:04', _loaded_at = '2026-01-01 18:22:04' where shipment_id = 2529;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 11:23:31', updated_at = '2026-01-01 11:23:31', _loaded_at = '2026-01-01 12:23:31' where shipment_id = 2652;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 15:07:46', updated_at = '2026-01-01 15:07:46', _loaded_at = '2026-01-01 16:07:46' where shipment_id = 2538;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 12:18:26', updated_at = '2026-01-01 12:18:26', _loaded_at = '2026-01-01 15:18:26' where shipment_id = 2539;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 15:45:56', updated_at = '2026-01-01 15:45:56', _loaded_at = '2026-01-01 17:45:56' where shipment_id = 2545;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 10:00:20', updated_at = '2026-01-01 10:00:20', _loaded_at = '2026-01-01 13:00:20' where shipment_id = 2550;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 10:42:48', updated_at = '2026-01-01 10:42:48', _loaded_at = '2026-01-01 13:42:48' where shipment_id = 2551;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 14:45:43', updated_at = '2026-01-01 14:45:43', _loaded_at = '2026-01-01 15:45:43' where shipment_id = 2554;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 13:53:01', updated_at = '2026-01-01 13:53:01', _loaded_at = '2026-01-01 14:53:01' where shipment_id = 2560;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 16:01:42', updated_at = '2026-01-01 16:01:42', _loaded_at = '2026-01-01 18:01:42' where shipment_id = 2653;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 15:07:48', updated_at = '2026-01-01 15:07:48', _loaded_at = '2026-01-01 16:07:48' where shipment_id = 2561;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 11:46:05', updated_at = '2026-01-01 11:46:05', _loaded_at = '2026-01-01 12:46:05' where shipment_id = 2563;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 08:24:52', updated_at = '2026-01-01 08:24:52', _loaded_at = '2026-01-01 11:24:52' where shipment_id = 2568;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 16:26:52', updated_at = '2026-01-01 16:26:52', _loaded_at = '2026-01-01 19:26:52' where shipment_id = 2570;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 13:37:52', updated_at = '2026-01-01 13:37:52', _loaded_at = '2026-01-01 16:37:52' where shipment_id = 2571;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 09:53:58', updated_at = '2026-01-01 09:53:58', _loaded_at = '2026-01-01 10:53:58' where shipment_id = 2573;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 14:50:22', updated_at = '2026-01-01 14:50:22', _loaded_at = '2026-01-01 17:50:22' where shipment_id = 2582;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 10:16:35', updated_at = '2026-01-01 10:16:35', _loaded_at = '2026-01-01 11:16:35' where shipment_id = 2583;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 17:19:32', updated_at = '2026-01-01 17:19:32', _loaded_at = '2026-01-01 19:19:32' where shipment_id = 2584;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 11:51:42', updated_at = '2026-01-01 11:51:42', _loaded_at = '2026-01-01 14:51:42' where shipment_id = 2585;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 16:21:41', updated_at = '2026-01-01 16:21:41', _loaded_at = '2026-01-01 17:21:41' where shipment_id = 2586;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 17:49:35', updated_at = '2026-01-01 17:49:35', _loaded_at = '2026-01-01 18:49:35' where shipment_id = 2589;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 11:10:16', updated_at = '2026-01-01 11:10:16', _loaded_at = '2026-01-01 13:10:16' where shipment_id = 2593;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 14:44:25', updated_at = '2026-01-01 14:44:25', _loaded_at = '2026-01-01 16:44:25' where shipment_id = 2600;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 15:32:48', updated_at = '2026-01-01 15:32:48', _loaded_at = '2026-01-01 18:32:48' where shipment_id = 2604;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 14:49:30', updated_at = '2026-01-01 14:49:30', _loaded_at = '2026-01-01 16:49:30' where shipment_id = 2605;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 12:03:51', updated_at = '2026-01-01 12:03:51', _loaded_at = '2026-01-01 13:03:51' where shipment_id = 2606;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 13:30:00', updated_at = '2026-01-01 13:30:00', _loaded_at = '2026-01-01 14:30:00' where shipment_id = 2655;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 16:06:25', updated_at = '2026-01-01 16:06:25', _loaded_at = '2026-01-01 19:06:25' where shipment_id = 2610;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 17:25:27', updated_at = '2026-01-01 17:25:27', _loaded_at = '2026-01-01 20:25:27' where shipment_id = 2612;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-01 16:19:51', updated_at = '2026-01-01 16:19:51', _loaded_at = '2026-01-01 19:19:51' where shipment_id = 2622;

-- web events of 2026-01-01 (277 rows)
insert into web_analytics.events (event_id, session_id, customer_id, event_type, event_timestamp, page, _loaded_at) values
  ('cf7a8081dd7b4', 's007703', null, 'page_view', '2026-01-01 07:06:05', '/', '2026-01-01 07:48:05'),
  ('1dc150a1efd9b', 's007703', null, 'page_view', '2026-01-01 07:08:41', '/category/electronics', '2026-01-01 07:40:41'),
  ('b3d55bf8c6dab', 's007703', null, 'page_view', '2026-01-01 07:09:03', '/category/electronics', '2026-01-01 07:36:03'),
  ('f237db58ff553', 's007670', 461, 'page_view', '2026-01-01 07:09:52', '/', '2026-01-01 07:58:52'),
  ('499c89e5f01a7', 's007728', null, 'page_view', '2026-01-01 07:10:29', '/product/sf-hom-0008', '2026-01-01 07:24:29'),
  ('7f02c396a42bf', 's007728', null, 'page_view', '2026-01-01 07:10:56', '/category/electronics', '2026-01-01 07:59:56'),
  ('5ae68fd7d4edc', 's007703', null, 'add_to_cart', '2026-01-01 07:11:38', '/cart', '2026-01-01 07:20:38'),
  ('8824edb1daa2f', 's007670', 461, 'page_view', '2026-01-01 07:13:33', '/product/sf-hom-0034', '2026-01-01 07:56:33'),
  ('9d5beacc615c9', 's007728', null, 'page_view', '2026-01-01 07:14:48', '/product/sf-ele-0035', '2026-01-01 07:35:48'),
  ('86462001cfe6a', 's007728', null, 'add_to_cart', '2026-01-01 07:15:18', '/cart', '2026-01-01 07:23:18'),
  ('d7763ad1b0da1', 's007728', null, 'checkout_start', '2026-01-01 07:17:54', '/checkout', '2026-01-01 08:09:54'),
  ('1db02651ef521', 's007728', null, 'purchase', '2026-01-01 07:21:18', '/checkout/confirmation', '2026-01-01 08:10:18'),
  ('af79436a9a4c4', 's007655', 260, 'page_view', '2026-01-01 07:30:00', '/product/sf-hom-0008', '2026-01-01 08:00:00'),
  ('41b1f0ce105ae', 's007655', 260, 'add_to_cart', '2026-01-01 07:32:26', '/cart', '2026-01-01 08:23:26'),
  ('5080c1c872a77', 's007732', 221, 'page_view', '2026-01-01 07:34:06', '/product/sf-hom-0013', '2026-01-01 07:39:06'),
  ('3381efaeb6b98', 's007655', 260, 'checkout_start', '2026-01-01 07:35:37', '/checkout', '2026-01-01 08:01:37'),
  ('80f9ce06ee752', 's007655', 260, 'purchase', '2026-01-01 07:36:12', '/checkout/confirmation', '2026-01-01 08:30:12'),
  ('ddda1973912e6', 's007732', 221, 'page_view', '2026-01-01 07:36:42', '/category/electronics', '2026-01-01 08:06:42'),
  ('6ba6932c757da', 's007732', 221, 'add_to_cart', '2026-01-01 07:38:21', '/cart', '2026-01-01 08:17:21'),
  ('423ffaf4ac1a8', 's007730', null, 'page_view', '2026-01-01 07:45:44', '/category/beauty', '2026-01-01 08:30:44'),
  ('1f62bb9b76142', 's007730', null, 'page_view', '2026-01-01 07:47:02', '/category/home', '2026-01-01 08:08:02'),
  ('1e72399a0d2c3', 's007727', null, 'page_view', '2026-01-01 08:02:19', '/product/sf-bea-0022', '2026-01-01 08:30:19'),
  ('db62620f8229a', 's007727', null, 'page_view', '2026-01-01 08:05:39', '/category/books', '2026-01-01 08:24:39'),
  ('16a6c9a50c56a', 's007727', null, 'page_view', '2026-01-01 08:08:40', '/category/beauty', '2026-01-01 08:46:40'),
  ('41493dd737cc8', 's007709', 465, 'page_view', '2026-01-01 08:13:18', '/category/beauty', '2026-01-01 08:40:18'),
  ('5ffec8805c98e', 's007709', 465, 'add_to_cart', '2026-01-01 08:16:42', '/cart', '2026-01-01 08:43:42'),
  ('2277da7a14bce', 's007709', 465, 'checkout_start', '2026-01-01 08:18:37', '/checkout', '2026-01-01 08:59:37'),
  ('6c1fef841edbe', 's007709', 465, 'purchase', '2026-01-01 08:22:06', '/checkout/confirmation', '2026-01-01 08:34:06'),
  ('b0195a8b22d5f', 's007661', null, 'page_view', '2026-01-01 08:24:43', '/', '2026-01-01 08:29:43'),
  ('0383abe3019f6', 's007661', null, 'page_view', '2026-01-01 08:26:41', '/category/home', '2026-01-01 08:47:41'),
  ('2bda1b47a4c83', 's007669', 426, 'page_view', '2026-01-01 08:41:51', '/product/sf-ele-0005', '2026-01-01 09:24:51'),
  ('f79535c4e5501', 's007704', null, 'page_view', '2026-01-01 08:46:53', '/', '2026-01-01 09:02:53'),
  ('547c1322b87e4', 's007723', 193, 'page_view', '2026-01-01 09:10:12', '/', '2026-01-01 09:36:12'),
  ('83bd1490e5e86', 's007723', 193, 'page_view', '2026-01-01 09:12:57', '/product/sf-hom-0014', '2026-01-01 09:35:57'),
  ('9511d27c2ad33', 's007723', 193, 'page_view', '2026-01-01 09:15:56', '/product/sf-bea-0022', '2026-01-01 10:03:56'),
  ('a2ec2fb69d8f4', 's007723', 193, 'add_to_cart', '2026-01-01 09:18:17', '/cart', '2026-01-01 09:42:17'),
  ('5483b717f39a8', 's007726', null, 'page_view', '2026-01-01 09:45:08', '/', '2026-01-01 10:20:08'),
  ('929bdf540ab89', 's007726', null, 'page_view', '2026-01-01 09:48:01', '/category/fashion', '2026-01-01 10:39:01'),
  ('0ff6523506bab', 's007726', null, 'page_view', '2026-01-01 09:48:38', '/category/fashion', '2026-01-01 10:29:38'),
  ('9b3c7c71d3997', 's007726', null, 'page_view', '2026-01-01 09:50:20', '/category/beauty', '2026-01-01 10:38:20'),
  ('d0441b3bb1450', 's007692', null, 'page_view', '2026-01-01 09:53:52', '/product/sf-boo-0031', '2026-01-01 10:32:52'),
  ('a83695bf10a91', 's007719', 143, 'page_view', '2026-01-01 09:56:52', '/product/sf-ele-0035', '2026-01-01 10:07:52'),
  ('e65136eda4363', 's007719', 143, 'page_view', '2026-01-01 10:00:46', '/category/beauty', '2026-01-01 10:10:46'),
  ('c2d359b747df8', 's007684', 337, 'page_view', '2026-01-01 10:20:06', '/category/fashion', '2026-01-01 10:55:06'),
  ('d112b0762cb4f', 's007684', 337, 'page_view', '2026-01-01 10:20:28', '/product/sf-boo-0028', '2026-01-01 10:46:28'),
  ('7198eb7bad550', 's007684', 337, 'page_view', '2026-01-01 10:21:52', '/category/beauty', '2026-01-01 11:03:52'),
  ('d8d7f5e6b84bb', 's007684', 337, 'page_view', '2026-01-01 10:22:07', '/category/beauty', '2026-01-01 10:50:07'),
  ('807865e3fa5ef', 's007657', null, 'page_view', '2026-01-01 10:29:03', '/', '2026-01-01 11:14:03'),
  ('786760ceec6fb', 's007657', null, 'page_view', '2026-01-01 10:30:06', '/category/beauty', '2026-01-01 10:59:06'),
  ('82f68c53096c6', 's007694', 198, 'page_view', '2026-01-01 10:30:40', '/category/electronics', '2026-01-01 11:11:40'),
  ('1f164c956a0fe', 's007657', null, 'page_view', '2026-01-01 10:32:31', '/category/home', '2026-01-01 11:16:31'),
  ('6824951a136ee', 's007694', 198, 'page_view', '2026-01-01 10:33:56', '/category/electronics', '2026-01-01 10:45:56'),
  ('d614fe1d569a8', 's007717', null, 'page_view', '2026-01-01 10:34:21', '/product/sf-fas-0019', '2026-01-01 10:45:21'),
  ('3c5e9f0a445b4', 's007657', null, 'page_view', '2026-01-01 10:35:44', '/category/beauty', '2026-01-01 11:00:44'),
  ('31ff482dd52e7', 's007694', 198, 'page_view', '2026-01-01 10:37:53', '/category/fashion', '2026-01-01 11:10:53'),
  ('66b57219e0410', 's007657', null, 'add_to_cart', '2026-01-01 10:38:04', '/cart', '2026-01-01 11:13:04'),
  ('d4eccc335f018', 's007717', null, 'page_view', '2026-01-01 10:38:20', '/category/electronics', '2026-01-01 11:05:20'),
  ('55953ef56177c', 's007653', 438, 'page_view', '2026-01-01 10:39:03', '/product/sf-bea-0025', '2026-01-01 10:50:03'),
  ('148f6945612ec', 's007653', 438, 'page_view', '2026-01-01 10:39:18', '/category/electronics', '2026-01-01 10:55:18'),
  ('205b67fd6916c', 's007694', 198, 'page_view', '2026-01-01 10:39:39', '/category/books', '2026-01-01 11:32:39'),
  ('69ffd1dc660fb', 's007717', null, 'add_to_cart', '2026-01-01 10:39:58', '/cart', '2026-01-01 11:05:58'),
  ('0970ea11f7f84', 's007694', 198, 'add_to_cart', '2026-01-01 10:40:36', '/cart', '2026-01-01 11:06:36'),
  ('26a3f90cb42e1', 's007653', 438, 'page_view', '2026-01-01 10:43:10', '/category/books', '2026-01-01 10:51:10'),
  ('f8e4991a629ac', 's007653', 438, 'page_view', '2026-01-01 10:44:15', '/category/beauty', '2026-01-01 10:58:15'),
  ('30011ed74ce0f', 's007653', 438, 'page_view', '2026-01-01 10:44:59', '/category/electronics', '2026-01-01 11:06:59'),
  ('4075a1f97b9d8', 's007658', 207, 'page_view', '2026-01-01 10:47:02', '/category/books', '2026-01-01 11:19:02'),
  ('17586ad5ed93c', 's007658', 207, 'page_view', '2026-01-01 10:47:32', '/category/home', '2026-01-01 11:37:32'),
  ('d378d2ae3b247', 's007653', 438, 'add_to_cart', '2026-01-01 10:48:06', '/cart', '2026-01-01 10:54:06'),
  ('565d0389b4e88', 's007658', 207, 'page_view', '2026-01-01 10:50:46', '/category/fashion', '2026-01-01 11:18:46'),
  ('179f89cd1582d', 's007653', 438, 'checkout_start', '2026-01-01 10:52:05', '/checkout', '2026-01-01 11:47:05'),
  ('b65c74ea1fe8c', 's007658', 207, 'page_view', '2026-01-01 10:52:58', '/category/books', '2026-01-01 11:43:58'),
  ('833be261a5d0c', 's007658', 207, 'page_view', '2026-01-01 10:56:35', '/category/books', '2026-01-01 11:45:35'),
  ('8755efc91e10a', 's007688', null, 'page_view', '2026-01-01 10:56:37', '/', '2026-01-01 11:07:37'),
  ('bc059093adcab', 's007697', null, 'page_view', '2026-01-01 10:57:42', '/product/sf-hom-0011', '2026-01-01 11:18:42'),
  ('95b5d244c64be', 's007659', 437, 'page_view', '2026-01-01 10:57:43', '/product/sf-fas-0016', '2026-01-01 11:16:43'),
  ('323adedd86899', 's007671', null, 'page_view', '2026-01-01 10:57:46', '/product/sf-hom-0011', '2026-01-01 11:26:46'),
  ('a300388a1eaf0', 's007688', null, 'page_view', '2026-01-01 10:58:02', '/category/beauty', '2026-01-01 11:28:02'),
  ('06c48814f2368', 's007671', null, 'page_view', '2026-01-01 10:58:12', '/product/sf-hom-0013', '2026-01-01 11:08:12'),
  ('446a943e68789', 's007688', null, 'page_view', '2026-01-01 10:59:24', '/product/sf-fas-0021', '2026-01-01 11:24:24'),
  ('a29bfb54ce896', 's007658', 207, 'add_to_cart', '2026-01-01 10:59:39', '/cart', '2026-01-01 11:44:39'),
  ('70c6a717b6dce', 's007659', 437, 'page_view', '2026-01-01 11:00:53', '/product/sf-bea-0026', '2026-01-01 11:34:53'),
  ('f15ba3bb982a4', 's007697', null, 'page_view', '2026-01-01 11:00:55', '/category/beauty', '2026-01-01 11:49:55'),
  ('11884f1072120', 's007656', 178, 'page_view', '2026-01-01 11:01:14', '/', '2026-01-01 11:30:14'),
  ('1dbb1b2c1192d', 's007671', null, 'page_view', '2026-01-01 11:01:15', '/category/beauty', '2026-01-01 11:09:15'),
  ('fb7dd4154d4a3', 's007656', 178, 'add_to_cart', '2026-01-01 11:02:03', '/cart', '2026-01-01 11:29:03'),
  ('fe9850ef25594', 's007659', 437, 'page_view', '2026-01-01 11:02:12', '/category/beauty', '2026-01-01 11:26:12'),
  ('96de58bc14f5b', 's007658', 207, 'checkout_start', '2026-01-01 11:02:19', '/checkout', '2026-01-01 11:40:19'),
  ('56922bde06516', 's007697', null, 'page_view', '2026-01-01 11:02:24', '/category/fashion', '2026-01-01 11:22:24'),
  ('a9749c255760a', 's007688', null, 'page_view', '2026-01-01 11:02:38', '/category/fashion', '2026-01-01 11:10:38'),
  ('38cf3eef52650', 's007656', 178, 'checkout_start', '2026-01-01 11:02:52', '/checkout', '2026-01-01 11:56:52'),
  ('7005c9555f493', 's007697', null, 'page_view', '2026-01-01 11:03:21', '/category/electronics', '2026-01-01 11:20:21'),
  ('326406aa92730', 's007658', 207, 'purchase', '2026-01-01 11:03:55', '/checkout/confirmation', '2026-01-01 11:57:55'),
  ('daa2756fca296', 's007697', null, 'add_to_cart', '2026-01-01 11:04:17', '/cart', '2026-01-01 11:48:17'),
  ('cebf5f3309615', 's007659', 437, 'page_view', '2026-01-01 11:05:05', '/category/home', '2026-01-01 11:32:05'),
  ('11e4851086af2', 's007659', 437, 'page_view', '2026-01-01 11:08:47', '/product/sf-fas-0020', '2026-01-01 12:00:47'),
  ('b513eae57f212', 's007663', null, 'page_view', '2026-01-01 11:14:18', '/product/sf-boo-0032', '2026-01-01 11:35:18'),
  ('e391ef1025cfd', 's007711', null, 'page_view', '2026-01-01 11:15:17', '/product/sf-ele-0007', '2026-01-01 11:41:17'),
  ('59c6ad65a5d0b', 's007711', null, 'page_view', '2026-01-01 11:15:52', '/product/sf-fas-0019', '2026-01-01 11:40:52'),
  ('84f6a1a729a1d', 's007663', null, 'page_view', '2026-01-01 11:15:52', '/product/sf-hom-0034', '2026-01-01 11:26:52'),
  ('f2529d798705d', 's007711', null, 'page_view', '2026-01-01 11:18:09', '/category/electronics', '2026-01-01 11:26:09'),
  ('a4fdb0b69a015', 's007663', null, 'page_view', '2026-01-01 11:18:13', '/product/sf-fas-0019', '2026-01-01 12:02:13'),
  ('56654cf653077', 's007711', null, 'page_view', '2026-01-01 11:19:30', '/product/sf-boo-0029', '2026-01-01 12:13:30'),
  ('05d1c73ae6c41', 's007663', null, 'add_to_cart', '2026-01-01 11:20:32', '/cart', '2026-01-01 11:55:32'),
  ('58d93cc8ccdf4', 's007711', null, 'page_view', '2026-01-01 11:21:15', '/product/sf-ele-0001', '2026-01-01 12:10:15'),
  ('dfd53d1e14923', 's007662', null, 'page_view', '2026-01-01 11:22:00', '/', '2026-01-01 11:44:00'),
  ('a7795446fe74c', 's007662', null, 'page_view', '2026-01-01 11:23:20', '/category/home', '2026-01-01 12:06:20'),
  ('d29a35e57babe', 's007663', null, 'checkout_start', '2026-01-01 11:23:44', '/checkout', '2026-01-01 11:33:44'),
  ('3e34c4cf01a5c', 's007662', null, 'page_view', '2026-01-01 11:25:11', '/category/electronics', '2026-01-01 11:33:11'),
  ('7e8f2cf9044ca', 's007663', null, 'purchase', '2026-01-01 11:26:35', '/checkout/confirmation', '2026-01-01 11:31:35'),
  ('b16a9e418a3de', 's007662', null, 'page_view', '2026-01-01 11:27:19', '/category/books', '2026-01-01 11:47:19'),
  ('f213b83e16214', 's007715', null, 'page_view', '2026-01-01 11:32:16', '/product/sf-ele-0004', '2026-01-01 11:54:16'),
  ('b52a9c3e52118', 's007715', null, 'add_to_cart', '2026-01-01 11:34:35', '/cart', '2026-01-01 11:50:35'),
  ('81b3a12f1fc8c', 's007715', null, 'checkout_start', '2026-01-01 11:37:19', '/checkout', '2026-01-01 12:11:19'),
  ('9e87cdc2c8617', 's007715', null, 'purchase', '2026-01-01 11:40:06', '/checkout/confirmation', '2026-01-01 11:51:06'),
  ('e38f035cbe532', 's007685', 192, 'page_view', '2026-01-01 11:52:10', '/category/electronics', '2026-01-01 12:32:10'),
  ('e0616b6d54ebd', 's007685', 192, 'page_view', '2026-01-01 11:56:08', '/category/fashion', '2026-01-01 12:45:08'),
  ('4010f5c5efa1b', 's007685', 192, 'page_view', '2026-01-01 11:57:00', '/category/fashion', '2026-01-01 12:33:00'),
  ('0f74f5c1e70da', 's007691', 334, 'page_view', '2026-01-01 12:08:37', '/', '2026-01-01 13:02:37'),
  ('5b6e7767068ff', 's007691', 334, 'page_view', '2026-01-01 12:10:29', '/category/fashion', '2026-01-01 12:16:29'),
  ('a34e15fe867a2', 's007721', null, 'page_view', '2026-01-01 12:16:34', '/', '2026-01-01 12:45:34'),
  ('b294e7a89eeed', 's007689', null, 'page_view', '2026-01-01 12:20:02', '/product/sf-boo-0033', '2026-01-01 13:15:02'),
  ('456aa0a16d564', 's007721', null, 'page_view', '2026-01-01 12:20:21', '/category/books', '2026-01-01 12:51:21'),
  ('306a811e1b35c', 's007721', null, 'page_view', '2026-01-01 12:22:55', '/category/beauty', '2026-01-01 12:58:55'),
  ('42ee6b5129d34', 's007721', null, 'page_view', '2026-01-01 12:23:50', '/category/home', '2026-01-01 12:45:50'),
  ('771b524553dfc', 's007686', 73, 'page_view', '2026-01-01 12:25:18', '/category/books', '2026-01-01 13:06:18'),
  ('e1fff6001d245', 's007680', 402, 'page_view', '2026-01-01 12:39:35', '/product/sf-fas-0017', '2026-01-01 12:57:35'),
  ('19936e1feff59', 's007680', 402, 'add_to_cart', '2026-01-01 12:42:44', '/cart', '2026-01-01 13:37:44'),
  ('386921959f0a8', 's007714', 283, 'page_view', '2026-01-01 13:14:42', '/', '2026-01-01 13:54:42'),
  ('df496aceaa8c0', 's007714', 283, 'page_view', '2026-01-01 13:17:50', '/category/home', '2026-01-01 13:49:50'),
  ('3276ab5c9c379', 's007714', 283, 'page_view', '2026-01-01 13:19:35', '/category/beauty', '2026-01-01 13:25:35'),
  ('72645ff3b8066', 's007678', null, 'page_view', '2026-01-01 13:21:28', '/product/sf-bea-0027', '2026-01-01 14:16:28'),
  ('037b5acd4b1c7', 's007714', 283, 'add_to_cart', '2026-01-01 13:21:33', '/cart', '2026-01-01 14:09:33'),
  ('33abf774a8b9d', 's007678', null, 'page_view', '2026-01-01 13:22:48', '/category/fashion', '2026-01-01 13:57:48'),
  ('932ed97fe2ee3', 's007679', null, 'page_view', '2026-01-01 13:22:53', '/category/beauty', '2026-01-01 14:16:53'),
  ('8a08284695c2d', 's007679', null, 'page_view', '2026-01-01 13:23:13', '/product/sf-fas-0018', '2026-01-01 13:50:13'),
  ('6922b1e8761c1', 's007714', 283, 'checkout_start', '2026-01-01 13:23:56', '/checkout', '2026-01-01 13:48:56'),
  ('89e41a971378b', 's007695', 429, 'page_view', '2026-01-01 13:26:33', '/', '2026-01-01 14:05:33'),
  ('f4068e33cfd26', 's007679', null, 'page_view', '2026-01-01 13:26:58', '/category/beauty', '2026-01-01 14:18:58'),
  ('7c32907b25fb5', 's007679', null, 'page_view', '2026-01-01 13:28:36', '/product/sf-bea-0026', '2026-01-01 14:19:36'),
  ('fc8d257cafbc2', 's007679', null, 'add_to_cart', '2026-01-01 13:29:18', '/cart', '2026-01-01 14:18:18'),
  ('17e3dcc62d367', 's007695', 429, 'page_view', '2026-01-01 13:29:42', '/product/sf-hom-0014', '2026-01-01 14:17:42'),
  ('aed73dfcf13cc', 's007695', 429, 'page_view', '2026-01-01 13:32:44', '/product/sf-bea-0024', '2026-01-01 14:18:44'),
  ('992899f9d313b', 's007695', 429, 'page_view', '2026-01-01 13:35:28', '/product/sf-ele-0004', '2026-01-01 13:54:28'),
  ('b0e0dbd83359e', 's007667', 95, 'page_view', '2026-01-01 13:38:39', '/', '2026-01-01 13:55:39'),
  ('83628c32c3c23', 's007667', 95, 'page_view', '2026-01-01 13:41:30', '/category/fashion', '2026-01-01 14:28:30'),
  ('aa1802f7113fe', 's007667', 95, 'page_view', '2026-01-01 13:43:19', '/category/books', '2026-01-01 14:10:19'),
  ('9352be4c8933a', 's007667', 95, 'page_view', '2026-01-01 13:43:40', '/category/home', '2026-01-01 14:14:40'),
  ('b9d3db3069ed4', 's007667', 95, 'page_view', '2026-01-01 13:43:54', '/category/fashion', '2026-01-01 13:52:54'),
  ('1fa092b340fde', 's007731', 373, 'page_view', '2026-01-01 13:47:56', '/category/home', '2026-01-01 14:17:56'),
  ('3dde8dc1d338c', 's007672', 151, 'page_view', '2026-01-01 13:53:09', '/category/electronics', '2026-01-01 14:45:09'),
  ('4db7bb12f5164', 's007672', 151, 'page_view', '2026-01-01 13:54:57', '/product/sf-bea-0022', '2026-01-01 14:46:57'),
  ('ccea3bfe0008e', 's007672', 151, 'page_view', '2026-01-01 13:55:41', '/product/sf-ele-0003', '2026-01-01 14:45:41'),
  ('d8743f0573014', 's007672', 151, 'add_to_cart', '2026-01-01 13:58:42', '/cart', '2026-01-01 14:25:42'),
  ('9b6e3f54f1ee8', 's007672', 151, 'checkout_start', '2026-01-01 13:59:59', '/checkout', '2026-01-01 14:44:59'),
  ('023edb41678fd', 's007720', 164, 'page_view', '2026-01-01 14:00:11', '/', '2026-01-01 14:05:11'),
  ('6b4f6dc2233e1', 's007672', 151, 'purchase', '2026-01-01 14:01:07', '/checkout/confirmation', '2026-01-01 14:29:07'),
  ('e915633078322', 's007720', 164, 'page_view', '2026-01-01 14:03:36', '/category/home', '2026-01-01 14:47:36'),
  ('bc7367c418579', 's007690', 139, 'page_view', '2026-01-01 14:05:35', '/product/sf-bea-0023', '2026-01-01 14:11:35'),
  ('975e1ec3b1df4', 's007690', 139, 'page_view', '2026-01-01 14:08:34', '/category/beauty', '2026-01-01 14:45:34'),
  ('5bf0082977018', 's007713', null, 'page_view', '2026-01-01 14:10:48', '/category/home', '2026-01-01 14:36:48'),
  ('43ac0622f0edb', 's007700', 130, 'page_view', '2026-01-01 14:13:46', '/product/sf-ele-0002', '2026-01-01 14:47:46'),
  ('9362d7f1db010', 's007700', 130, 'page_view', '2026-01-01 14:17:43', '/category/beauty', '2026-01-01 14:38:43'),
  ('492806e5f082e', 's007700', 130, 'page_view', '2026-01-01 14:20:04', '/category/beauty', '2026-01-01 15:14:04'),
  ('e5b4da602843b', 's007700', 130, 'page_view', '2026-01-01 14:23:33', '/category/books', '2026-01-01 15:14:33'),
  ('6ebf8dc1d3a4f', 's007700', 130, 'page_view', '2026-01-01 14:26:45', '/category/electronics', '2026-01-01 14:56:45'),
  ('3449c25a7687f', 's007700', 130, 'add_to_cart', '2026-01-01 14:27:17', '/cart', '2026-01-01 14:54:17'),
  ('7e2788d33b8da', 's007660', null, 'page_view', '2026-01-01 15:07:28', '/product/sf-fas-0017', '2026-01-01 15:20:28'),
  ('4d2f634745ae5', 's007660', null, 'page_view', '2026-01-01 15:09:56', '/product/sf-fas-0019', '2026-01-01 16:03:56'),
  ('ec7a6c324ef85', 's007660', null, 'add_to_cart', '2026-01-01 15:11:11', '/cart', '2026-01-01 15:46:11'),
  ('f35d0c51c7733', 's007675', null, 'page_view', '2026-01-01 15:46:39', '/', '2026-01-01 16:21:39'),
  ('ade1816770259', 's007701', 276, 'page_view', '2026-01-01 16:07:11', '/category/fashion', '2026-01-01 16:46:11'),
  ('abf8e24a0c676', 's007701', 276, 'page_view', '2026-01-01 16:10:39', '/category/electronics', '2026-01-01 16:42:39'),
  ('002f9fa58c5b0', 's007701', 276, 'page_view', '2026-01-01 16:14:37', '/product/sf-fas-0018', '2026-01-01 16:35:37'),
  ('9f99094d594bf', 's007701', 276, 'page_view', '2026-01-01 16:18:36', '/category/beauty', '2026-01-01 16:23:36'),
  ('4eb0388a67711', 's007666', 6, 'page_view', '2026-01-01 16:20:53', '/category/home', '2026-01-01 16:45:53'),
  ('6d3277f1ee9f1', 's007666', 6, 'page_view', '2026-01-01 16:21:05', '/product/sf-fas-0016', '2026-01-01 17:15:05'),
  ('f7f4b5c9f49c6', 's007701', 276, 'page_view', '2026-01-01 16:21:09', '/category/beauty', '2026-01-01 16:48:09'),
  ('29af02aa22111', 's007682', null, 'page_view', '2026-01-01 16:24:00', '/product/sf-fas-0015', '2026-01-01 17:04:00'),
  ('bd01938b6dd35', 's007682', null, 'page_view', '2026-01-01 16:25:29', '/product/sf-ele-0002', '2026-01-01 16:43:29'),
  ('1807bf46d3602', 's007682', null, 'page_view', '2026-01-01 16:26:14', '/category/fashion', '2026-01-01 16:41:14'),
  ('9d98b1a39cd7f', 's007712', 213, 'page_view', '2026-01-01 16:29:43', '/category/electronics', '2026-01-01 16:48:43'),
  ('821f667a85903', 's007712', 213, 'page_view', '2026-01-01 16:30:02', '/category/fashion', '2026-01-01 16:50:02'),
  ('ac602aeac674d', 's007687', null, 'page_view', '2026-01-01 16:32:10', '/', '2026-01-01 16:49:10'),
  ('cc03c94d68c07', 's007687', null, 'page_view', '2026-01-01 16:34:58', '/product/sf-hom-0013', '2026-01-01 16:55:58'),
  ('8fe33b80dd42c', 's007654', 484, 'page_view', '2026-01-01 16:48:42', '/category/home', '2026-01-01 17:26:42'),
  ('0621c04591114', 's007654', 484, 'page_view', '2026-01-01 16:50:02', '/product/sf-hom-0013', '2026-01-01 17:19:02'),
  ('1590b35131fd1', 's007654', 484, 'page_view', '2026-01-01 16:51:55', '/category/electronics', '2026-01-01 17:29:55'),
  ('25940e09bf020', 's007654', 484, 'page_view', '2026-01-01 16:54:39', '/category/books', '2026-01-01 17:02:39'),
  ('82ace70526728', 's007654', 484, 'page_view', '2026-01-01 16:56:32', '/product/sf-bea-0025', '2026-01-01 17:51:32'),
  ('8349fed0a4e45', 's007664', null, 'page_view', '2026-01-01 17:04:56', '/', '2026-01-01 17:11:56'),
  ('2728b71228bba', 's007664', null, 'page_view', '2026-01-01 17:05:26', '/category/books', '2026-01-01 17:19:26'),
  ('ab149b87452a6', 's007724', null, 'page_view', '2026-01-01 17:27:18', '/product/sf-boo-0031', '2026-01-01 17:53:18'),
  ('6be6b8284ca01', 's007710', 70, 'page_view', '2026-01-01 17:28:02', '/product/sf-hom-0013', '2026-01-01 17:45:02'),
  ('4cc0ea7c57406', 's007710', 70, 'page_view', '2026-01-01 17:29:19', '/product/sf-fas-0021', '2026-01-01 18:20:19'),
  ('5beb8f3d26d4f', 's007683', 115, 'page_view', '2026-01-01 17:41:07', '/', '2026-01-01 18:01:07'),
  ('406068c49adcc', 's007683', 115, 'add_to_cart', '2026-01-01 17:43:12', '/cart', '2026-01-01 18:21:12'),
  ('8539849cc99dc', 's007683', 115, 'checkout_start', '2026-01-01 17:44:16', '/checkout', '2026-01-01 18:34:16'),
  ('d2ffe08055d66', 's007683', 115, 'purchase', '2026-01-01 17:45:32', '/checkout/confirmation', '2026-01-01 17:53:32'),
  ('24b0d941519ea', 's007722', 243, 'page_view', '2026-01-01 17:46:07', '/product/sf-fas-0017', '2026-01-01 18:36:07'),
  ('2a1652fd91f07', 's007722', 243, 'page_view', '2026-01-01 17:47:32', '/product/sf-boo-0033', '2026-01-01 18:04:32');
insert into web_analytics.events (event_id, session_id, customer_id, event_type, event_timestamp, page, _loaded_at) values
  ('8b48205c61a00', 's007722', 243, 'page_view', '2026-01-01 17:48:10', '/product/sf-hom-0008', '2026-01-01 18:24:10'),
  ('bcd393018ae10', 's007722', 243, 'page_view', '2026-01-01 17:51:58', '/category/books', '2026-01-01 18:26:58'),
  ('1d9038824494c', 's007722', 243, 'page_view', '2026-01-01 17:53:29', '/category/electronics', '2026-01-01 18:03:29'),
  ('2b0c1385ab643', 's007702', null, 'page_view', '2026-01-01 18:06:49', '/', '2026-01-01 18:12:49'),
  ('3eb98066f975b', 's007702', null, 'page_view', '2026-01-01 18:08:55', '/product/sf-bea-0024', '2026-01-01 18:23:55'),
  ('edc19653ad455', 's007702', null, 'page_view', '2026-01-01 18:11:37', '/category/home', '2026-01-01 18:23:37'),
  ('bd79cc1081aa9', 's007677', 222, 'page_view', '2026-01-01 18:13:41', '/', '2026-01-01 18:23:41'),
  ('184b4ae230ae3', 's007677', 222, 'page_view', '2026-01-01 18:15:55', '/category/fashion', '2026-01-01 19:05:55'),
  ('f43d073a6d96f', 's007677', 222, 'page_view', '2026-01-01 18:18:53', '/product/sf-hom-0009', '2026-01-01 18:23:53'),
  ('4791d47b09dcb', 's007729', 343, 'page_view', '2026-01-01 18:20:27', '/product/sf-boo-0033', '2026-01-01 19:00:27'),
  ('f1520ba342377', 's007696', 31, 'page_view', '2026-01-01 18:22:17', '/', '2026-01-01 19:05:17'),
  ('f08d9bd894e7d', 's007677', 222, 'page_view', '2026-01-01 18:22:27', '/category/books', '2026-01-01 18:46:27'),
  ('07209bb7d186a', 's007696', 31, 'add_to_cart', '2026-01-01 18:22:50', '/cart', '2026-01-01 18:37:50'),
  ('587547700e518', 's007729', 343, 'page_view', '2026-01-01 18:24:26', '/product/sf-ele-0003', '2026-01-01 19:19:26'),
  ('7ea73f59d89b6', 's007716', 232, 'page_view', '2026-01-01 18:25:22', '/', '2026-01-01 19:10:22'),
  ('62cea28258cba', 's007696', 31, 'checkout_start', '2026-01-01 18:25:35', '/checkout', '2026-01-01 19:01:35'),
  ('a55a808efc5aa', 's007729', 343, 'add_to_cart', '2026-01-01 18:25:52', '/cart', '2026-01-01 18:51:52'),
  ('ca393820d74ef', 's007729', 343, 'checkout_start', '2026-01-01 18:26:24', '/checkout', '2026-01-01 19:00:24'),
  ('e2947c2a1cac3', 's007677', 222, 'page_view', '2026-01-01 18:26:25', '/product/sf-boo-0029', '2026-01-01 18:57:25'),
  ('2068f904fc314', 's007716', 232, 'page_view', '2026-01-01 18:28:06', '/category/electronics', '2026-01-01 18:42:06'),
  ('3b90704868d98', 's007716', 232, 'page_view', '2026-01-01 18:29:07', '/category/electronics', '2026-01-01 19:14:07'),
  ('dbbdc463732b0', 's007729', 343, 'purchase', '2026-01-01 18:29:07', '/checkout/confirmation', '2026-01-01 19:23:07'),
  ('98c37426723df', 's007716', 232, 'page_view', '2026-01-01 18:31:02', '/category/electronics', '2026-01-01 19:16:02'),
  ('a02933557814e', 's007706', 402, 'page_view', '2026-01-01 18:43:21', '/', '2026-01-01 19:06:21'),
  ('479e29a6b5321', 's007676', 10, 'page_view', '2026-01-01 18:43:29', '/category/beauty', '2026-01-01 18:48:29'),
  ('35d458b4de59f', 's007676', 10, 'page_view', '2026-01-01 18:44:16', '/category/fashion', '2026-01-01 19:38:16'),
  ('f2d8a5751f8ba', 's007706', 402, 'page_view', '2026-01-01 18:47:01', '/category/books', '2026-01-01 19:05:01'),
  ('b34ae1dbb6107', 's007676', 10, 'page_view', '2026-01-01 18:48:03', '/category/books', '2026-01-01 18:56:03'),
  ('328a471effc0f', 's007676', 10, 'page_view', '2026-01-01 18:49:38', '/category/books', '2026-01-01 19:13:38'),
  ('90d116a3372c4', 's007706', 402, 'page_view', '2026-01-01 18:50:14', '/category/electronics', '2026-01-01 19:40:14'),
  ('f66255be63bbf', 's007706', 402, 'page_view', '2026-01-01 18:53:55', '/product/sf-fas-0018', '2026-01-01 19:05:55'),
  ('2fb9264207ef8', 's007706', 402, 'page_view', '2026-01-01 18:57:27', '/category/home', '2026-01-01 19:36:27'),
  ('d82f93dc68b88', 's007674', 131, 'page_view', '2026-01-01 19:02:12', '/', '2026-01-01 19:12:12'),
  ('4c382f97a293a', 's007674', 131, 'add_to_cart', '2026-01-01 19:03:04', '/cart', '2026-01-01 19:37:04'),
  ('e06526d5366c5', 's007674', 131, 'checkout_start', '2026-01-01 19:03:32', '/checkout', '2026-01-01 19:10:32'),
  ('f086dae1728e1', 's007725', null, 'page_view', '2026-01-01 19:12:35', '/product/sf-hom-0014', '2026-01-01 19:43:35'),
  ('7c6a524d0a33f', 's007725', null, 'page_view', '2026-01-01 19:15:07', '/product/sf-fas-0020', '2026-01-01 20:09:07'),
  ('ae11ce0a334c9', 's007725', null, 'page_view', '2026-01-01 19:16:19', '/category/beauty', '2026-01-01 19:30:19'),
  ('35aedb7d066de', 's007725', null, 'page_view', '2026-01-01 19:18:58', '/category/fashion', '2026-01-01 19:39:58'),
  ('5c5ebf380c9a8', 's007681', 352, 'page_view', '2026-01-01 19:29:25', '/product/sf-hom-0009', '2026-01-01 20:17:25'),
  ('d1df4b78e4498', 's007681', 352, 'page_view', '2026-01-01 19:32:01', '/category/home', '2026-01-01 20:15:01'),
  ('f0574e9982fd0', 's007668', null, 'page_view', '2026-01-01 19:33:26', '/product/sf-hom-0010', '2026-01-01 20:11:26'),
  ('70da3c6c1babb', 's007698', 193, 'page_view', '2026-01-01 19:54:41', '/product/sf-hom-0034', '2026-01-01 20:34:41'),
  ('b2009419f2e80', 's007698', 193, 'page_view', '2026-01-01 19:56:32', '/category/books', '2026-01-01 20:29:32'),
  ('dd2a88f8412cb', 's007698', 193, 'page_view', '2026-01-01 19:57:09', '/category/home', '2026-01-01 20:10:09'),
  ('4268fc75b73d5', 's007698', 193, 'add_to_cart', '2026-01-01 19:58:36', '/cart', '2026-01-01 20:31:36'),
  ('c3a1357371107', 's007698', 193, 'checkout_start', '2026-01-01 19:58:58', '/checkout', '2026-01-01 20:04:58'),
  ('64088c2c7543f', 's007673', null, 'page_view', '2026-01-01 20:55:33', '/category/fashion', '2026-01-01 21:29:33'),
  ('33154df464c24', 's007673', null, 'page_view', '2026-01-01 20:56:54', '/category/fashion', '2026-01-01 21:22:54'),
  ('8ec906f789a97', 's007673', null, 'add_to_cart', '2026-01-01 20:57:28', '/cart', '2026-01-01 21:49:28'),
  ('853c11243353b', 's007718', null, 'page_view', '2026-01-01 21:02:34', '/category/home', '2026-01-01 21:54:34'),
  ('e27c30447c2ce', 's007718', null, 'page_view', '2026-01-01 21:03:48', '/category/home', '2026-01-01 21:26:48'),
  ('53fae28f964e6', 's007718', null, 'page_view', '2026-01-01 21:04:18', '/category/books', '2026-01-01 21:54:18'),
  ('5bd046135f610', 's007693', null, 'page_view', '2026-01-01 21:35:03', '/', '2026-01-01 21:44:03'),
  ('48ff2c7e8b9ad', 's007693', null, 'page_view', '2026-01-01 21:38:15', '/product/sf-ele-0004', '2026-01-01 22:10:15'),
  ('02159f180682a', 's007693', null, 'page_view', '2026-01-01 21:39:13', '/category/beauty', '2026-01-01 22:34:13'),
  ('d9225cfad0d0c', 's007693', null, 'page_view', '2026-01-01 21:42:26', '/product/sf-hom-0013', '2026-01-01 22:16:26'),
  ('412090a2993e4', 's007705', null, 'page_view', '2026-01-01 21:43:10', '/category/beauty', '2026-01-01 21:56:10'),
  ('5c09c339eb19f', 's007693', null, 'add_to_cart', '2026-01-01 21:43:29', '/cart', '2026-01-01 22:36:29'),
  ('724882384a71a', 's007705', null, 'page_view', '2026-01-01 21:43:57', '/product/sf-bea-0024', '2026-01-01 22:32:57'),
  ('1ce249399d87a', 's007699', null, 'page_view', '2026-01-01 21:55:59', '/', '2026-01-01 22:38:59'),
  ('1409529ce1319', 's007699', null, 'page_view', '2026-01-01 21:58:28', '/category/beauty', '2026-01-01 22:04:28'),
  ('595ca80f344b9', 's007699', null, 'page_view', '2026-01-01 22:01:49', '/product/sf-boo-0030', '2026-01-01 22:16:49'),
  ('3c65121341c26', 's007708', 218, 'page_view', '2026-01-01 22:13:55', '/', '2026-01-01 22:56:55'),
  ('a886ed23b5d6b', 's007708', 218, 'page_view', '2026-01-01 22:14:44', '/category/electronics', '2026-01-01 22:39:44'),
  ('12f28c2bd876c', 's007708', 218, 'page_view', '2026-01-01 22:17:13', '/category/fashion', '2026-01-01 22:59:13'),
  ('e4b08a7e87101', 's007708', 218, 'page_view', '2026-01-01 22:20:13', '/category/beauty', '2026-01-01 22:46:13'),
  ('f0a820b53d42f', 's007708', 218, 'page_view', '2026-01-01 22:22:28', '/category/electronics', '2026-01-01 23:12:28'),
  ('622561e447270', 's007707', 409, 'page_view', '2026-01-01 22:29:16', '/product/sf-boo-0031', '2026-01-01 22:45:16'),
  ('da553c17cea5a', 's007707', 409, 'page_view', '2026-01-01 22:30:05', '/product/sf-fas-0020', '2026-01-01 23:03:05'),
  ('e84d5760d7958', 's007707', 409, 'page_view', '2026-01-01 22:33:24', '/product/sf-ele-0003', '2026-01-01 23:23:24'),
  ('ae6e9e4e52694', 's007707', 409, 'page_view', '2026-01-01 22:33:48', '/category/home', '2026-01-01 23:20:48'),
  ('6e3348f0bf168', 's007665', null, 'page_view', '2026-01-01 22:38:04', '/category/home', '2026-01-01 22:48:04'),
  ('b2578bfbbcaad', 's007665', null, 'page_view', '2026-01-01 22:40:58', '/category/beauty', '2026-01-01 23:09:58'),
  ('9f788174b227d', 's007665', null, 'page_view', '2026-01-01 22:41:23', '/category/fashion', '2026-01-01 23:21:23'),
  ('cc41f7ab0b8a0', 's007665', null, 'page_view', '2026-01-01 22:44:15', '/category/electronics', '2026-01-01 23:06:15'),
  ('f7471052c4fec', 's007665', null, 'page_view', '2026-01-01 22:46:33', '/category/electronics', '2026-01-01 22:51:33');

select 'day2 applied' as status;
