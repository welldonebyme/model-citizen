-- =====================================================================
--  day3.sql -- ShopFlow, loading day 2026-01-02
--  From the shopflow-data folder:   duckdb shopflow.duckdb < updates/day3.sql
--  Apply it ONCE, after day2.sql (Chapter 26, milestone m09).
--  Reset everything: duckdb shopflow.duckdb < setup.sql
-- =====================================================================

-- orders: 34 paid->shipped, 59 shipped->delivered
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-02 10:06:17', _loaded_at = '2026-01-02 11:06:17' where order_id = 3001;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-02 17:26:57', _loaded_at = '2026-01-02 19:26:57' where order_id = 3002;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-02 17:04:58', _loaded_at = '2026-01-02 19:04:58' where order_id = 3003;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-02 13:55:02', _loaded_at = '2026-01-02 15:55:02' where order_id = 3004;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-02 09:15:07', _loaded_at = '2026-01-02 12:15:07' where order_id = 3005;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-02 14:04:44', _loaded_at = '2026-01-02 16:04:44' where order_id = 3006;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-02 15:52:05', _loaded_at = '2026-01-02 17:52:05' where order_id = 3007;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-02 15:41:14', _loaded_at = '2026-01-02 17:41:14' where order_id = 3009;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-02 13:26:10', _loaded_at = '2026-01-02 15:26:10' where order_id = 3010;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-02 09:00:25', _loaded_at = '2026-01-02 10:00:25' where order_id = 3011;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-02 10:55:34', _loaded_at = '2026-01-02 12:55:34' where order_id = 3013;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-02 09:43:04', _loaded_at = '2026-01-02 12:43:04' where order_id = 3016;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-02 13:20:57', _loaded_at = '2026-01-02 16:20:57' where order_id = 3017;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-02 11:10:31', _loaded_at = '2026-01-02 14:10:31' where order_id = 3018;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-02 14:10:57', _loaded_at = '2026-01-02 16:10:57' where order_id = 3019;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-02 16:30:02', _loaded_at = '2026-01-02 18:30:02' where order_id = 3020;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-02 14:47:41', _loaded_at = '2026-01-02 15:47:41' where order_id = 3021;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-02 11:44:29', _loaded_at = '2026-01-02 14:44:29' where order_id = 3022;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-02 09:45:40', _loaded_at = '2026-01-02 12:45:40' where order_id = 3023;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-02 15:25:43', _loaded_at = '2026-01-02 18:25:43' where order_id = 3024;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-02 15:28:48', _loaded_at = '2026-01-02 16:28:48' where order_id = 3025;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-02 09:24:05', _loaded_at = '2026-01-02 12:24:05' where order_id = 3026;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-02 12:20:46', _loaded_at = '2026-01-02 13:20:46' where order_id = 3027;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-02 12:34:47', _loaded_at = '2026-01-02 13:34:47' where order_id = 3028;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-02 11:53:05', _loaded_at = '2026-01-02 14:53:05' where order_id = 3029;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-02 17:34:08', _loaded_at = '2026-01-02 20:34:08' where order_id = 3030;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-02 13:31:39', _loaded_at = '2026-01-02 15:31:39' where order_id = 3031;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-02 14:54:22', _loaded_at = '2026-01-02 15:54:22' where order_id = 3032;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-02 16:55:06', _loaded_at = '2026-01-02 17:55:06' where order_id = 3034;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-02 11:06:16', _loaded_at = '2026-01-02 14:06:16' where order_id = 3036;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-02 09:34:34', _loaded_at = '2026-01-02 10:34:34' where order_id = 3037;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-02 10:35:20', _loaded_at = '2026-01-02 11:35:20' where order_id = 3038;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-02 10:53:11', _loaded_at = '2026-01-02 12:53:11' where order_id = 3039;
update shopflow_app.orders set status = 'shipped', updated_at = '2026-01-02 16:24:38', _loaded_at = '2026-01-02 19:24:38' where order_id = 3040;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 14:39:34', _loaded_at = '2026-01-02 16:39:34' where order_id = 335;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 15:21:28', _loaded_at = '2026-01-02 16:21:28' where order_id = 485;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 10:09:57', _loaded_at = '2026-01-02 11:09:57' where order_id = 654;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 08:45:39', _loaded_at = '2026-01-02 09:45:39' where order_id = 785;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 12:20:21', _loaded_at = '2026-01-02 15:20:21' where order_id = 1166;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 16:47:31', _loaded_at = '2026-01-02 17:47:31' where order_id = 1346;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 08:56:54', _loaded_at = '2026-01-02 09:56:54' where order_id = 1769;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 14:55:46', _loaded_at = '2026-01-02 16:55:46' where order_id = 1858;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 10:17:29', _loaded_at = '2026-01-02 13:17:29' where order_id = 1862;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 12:03:07', _loaded_at = '2026-01-02 13:03:07' where order_id = 1963;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 13:10:25', _loaded_at = '2026-01-02 16:10:25' where order_id = 2109;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 10:18:20', _loaded_at = '2026-01-02 12:18:20' where order_id = 2332;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 10:55:58', _loaded_at = '2026-01-02 11:55:58' where order_id = 2350;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 16:54:49', _loaded_at = '2026-01-02 19:54:49' where order_id = 2410;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 14:36:54', _loaded_at = '2026-01-02 16:36:54' where order_id = 2532;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 08:38:37', _loaded_at = '2026-01-02 10:38:37' where order_id = 2649;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 11:08:25', _loaded_at = '2026-01-02 14:08:25' where order_id = 2654;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 17:38:07', _loaded_at = '2026-01-02 20:38:07' where order_id = 2661;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 13:30:38', _loaded_at = '2026-01-02 14:30:38' where order_id = 2678;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 13:13:39', _loaded_at = '2026-01-02 15:13:39' where order_id = 2690;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 08:00:39', _loaded_at = '2026-01-02 09:00:39' where order_id = 2700;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 08:16:59', _loaded_at = '2026-01-02 11:16:59' where order_id = 2703;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 08:20:10', _loaded_at = '2026-01-02 10:20:10' where order_id = 2711;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 11:10:30', _loaded_at = '2026-01-02 14:10:30' where order_id = 2738;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 11:22:27', _loaded_at = '2026-01-02 14:22:27' where order_id = 2743;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 08:20:26', _loaded_at = '2026-01-02 09:20:26' where order_id = 2769;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 17:48:42', _loaded_at = '2026-01-02 19:48:42' where order_id = 2787;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 15:53:22', _loaded_at = '2026-01-02 18:53:22' where order_id = 2804;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 14:42:14', _loaded_at = '2026-01-02 17:42:14' where order_id = 2818;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 09:38:05', _loaded_at = '2026-01-02 11:38:05' where order_id = 2834;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 16:38:26', _loaded_at = '2026-01-02 19:38:26' where order_id = 2843;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 08:08:04', _loaded_at = '2026-01-02 10:08:04' where order_id = 2845;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 12:59:45', _loaded_at = '2026-01-02 15:59:45' where order_id = 2850;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 09:37:10', _loaded_at = '2026-01-02 11:37:10' where order_id = 2871;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 17:47:11', _loaded_at = '2026-01-02 20:47:11' where order_id = 2873;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 16:30:08', _loaded_at = '2026-01-02 18:30:08' where order_id = 2879;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 14:12:54', _loaded_at = '2026-01-02 17:12:54' where order_id = 2883;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 12:34:28', _loaded_at = '2026-01-02 14:34:28' where order_id = 2885;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 09:39:38', _loaded_at = '2026-01-02 12:39:38' where order_id = 2892;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 10:01:32', _loaded_at = '2026-01-02 12:01:32' where order_id = 2895;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 08:44:34', _loaded_at = '2026-01-02 11:44:34' where order_id = 2899;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 12:12:17', _loaded_at = '2026-01-02 14:12:17' where order_id = 2901;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 13:32:56', _loaded_at = '2026-01-02 16:32:56' where order_id = 2909;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 17:36:13', _loaded_at = '2026-01-02 20:36:13' where order_id = 2912;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 16:31:54', _loaded_at = '2026-01-02 19:31:54' where order_id = 2916;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 13:40:04', _loaded_at = '2026-01-02 14:40:04' where order_id = 2917;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 16:01:51', _loaded_at = '2026-01-02 19:01:51' where order_id = 2918;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 11:39:27', _loaded_at = '2026-01-02 12:39:27' where order_id = 2924;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 10:24:18', _loaded_at = '2026-01-02 13:24:18' where order_id = 2926;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 15:06:04', _loaded_at = '2026-01-02 16:06:04' where order_id = 2929;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 17:14:27', _loaded_at = '2026-01-02 18:14:27' where order_id = 2935;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 08:36:03', _loaded_at = '2026-01-02 09:36:03' where order_id = 2938;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 10:14:45', _loaded_at = '2026-01-02 11:14:45' where order_id = 2939;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 12:35:06', _loaded_at = '2026-01-02 13:35:06' where order_id = 2940;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 17:12:25', _loaded_at = '2026-01-02 18:12:25' where order_id = 2942;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 11:38:44', _loaded_at = '2026-01-02 12:38:44' where order_id = 2943;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 11:50:50', _loaded_at = '2026-01-02 14:50:50' where order_id = 2945;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 17:02:43', _loaded_at = '2026-01-02 20:02:43' where order_id = 2954;
update shopflow_app.orders set status = 'delivered', updated_at = '2026-01-02 15:47:35', _loaded_at = '2026-01-02 16:47:35' where order_id = 2956;

-- 30 new orders placed on 2026-01-02 (+ items and payments)
insert into shopflow_app.orders (order_id, customer_id, order_at, status, currency, shipping_address_id, updated_at, _loaded_at) values
  (3041, 87, '2026-01-02 09:06:33', 'pending', 'MAD', 108, '2026-01-02 09:54:33', '2026-01-02 10:55:33'),
  (3042, 322, '2026-01-02 12:15:58', 'paid', 'EUR', 407, '2026-01-02 12:57:58', '2026-01-02 15:02:58'),
  (3043, 342, '2026-01-02 16:29:14', 'pending', 'MAD', 435, '2026-01-02 17:11:14', '2026-01-02 19:11:14'),
  (3044, 36, '2026-01-02 11:37:52', 'paid', 'MAD', 44, '2026-01-02 11:55:52', '2026-01-02 16:15:52'),
  (3045, 64, '2026-01-02 19:57:39', 'paid', 'EUR', 79, '2026-01-02 20:18:39', '2026-01-02 23:56:39'),
  (3046, 228, '2026-01-02 19:52:17', 'paid', 'EUR', 288, '2026-01-02 20:28:17', '2026-01-02 21:50:17'),
  (3047, 263, '2026-01-02 12:09:00', 'paid', 'USD', 331, '2026-01-02 12:23:00', '2026-01-02 14:23:00'),
  (3048, 275, '2026-01-02 09:09:54', 'paid', 'EUR', 346, '2026-01-02 09:24:54', '2026-01-02 13:24:54'),
  (3049, 311, '2026-01-02 09:29:48', 'paid', 'EUR', 392, '2026-01-02 09:48:48', '2026-01-02 14:16:48'),
  (3050, 66, '2026-01-02 16:06:28', 'paid', 'EUR', 82, '2026-01-02 16:25:28', '2026-01-02 18:58:28'),
  (3051, 167, '2026-01-02 07:43:36', 'paid', 'EUR', 215, '2026-01-02 07:49:36', '2026-01-02 09:37:36'),
  (3052, 33, '2026-01-02 12:30:04', 'pending', 'USD', 41, '2026-01-02 12:58:04', '2026-01-02 16:45:04'),
  (3053, 157, '2026-01-02 14:34:09', 'pending', 'MAD', 203, '2026-01-02 15:28:09', '2026-01-02 18:33:09'),
  (3054, 337, '2026-01-02 16:20:26', 'paid', 'MAD', 429, '2026-01-02 16:40:26', '2026-01-02 18:35:26'),
  (3055, 87, '2026-01-02 15:19:09', 'pending', 'MAD', 108, '2026-01-02 15:52:09', '2026-01-02 17:31:09'),
  (3056, 445, '2026-01-02 17:28:18', 'paid', 'MAD', 562, '2026-01-02 17:40:18', '2026-01-02 21:30:18'),
  (3057, 270, '2026-01-02 15:03:31', 'paid', 'EUR', 339, '2026-01-02 15:14:31', '2026-01-02 16:54:31'),
  (3058, 386, '2026-01-02 19:15:52', 'paid', 'EUR', 487, '2026-01-02 19:26:52', '2026-01-03 00:23:52'),
  (3059, 392, '2026-01-02 11:11:43', 'paid', 'EUR', 494, '2026-01-02 11:47:43', '2026-01-02 14:01:43'),
  (3060, 276, '2026-01-02 08:27:44', 'paid', 'EUR', 347, '2026-01-02 08:43:44', '2026-01-02 11:57:44'),
  (3061, 25, '2026-01-02 10:27:56', 'paid', 'MAD', 29, '2026-01-02 10:37:56', '2026-01-02 11:52:56'),
  (3062, 202, '2026-01-02 16:31:05', 'paid', 'EUR', 255, '2026-01-02 16:38:05', '2026-01-02 20:03:05'),
  (3063, 364, '2026-01-02 16:09:45', 'paid', 'EUR', 460, '2026-01-02 16:22:45', '2026-01-02 19:07:45'),
  (3064, 293, '2026-01-02 17:58:08', 'pending', 'EUR', 369, '2026-01-02 18:19:08', '2026-01-02 20:51:08'),
  (3065, 475, '2026-01-02 12:20:17', 'paid', 'EUR', 603, '2026-01-02 12:40:17', '2026-01-02 17:04:17'),
  (3066, 422, '2026-01-02 11:02:09', 'paid', 'EUR', 532, '2026-01-02 11:08:09', '2026-01-02 13:57:09'),
  (3067, 234, '2026-01-02 11:20:21', 'paid', 'USD', 296, '2026-01-02 11:28:21', '2026-01-02 16:07:21'),
  (3068, 165, '2026-01-02 16:06:52', 'paid', 'EUR', 213, '2026-01-02 16:12:52', '2026-01-02 18:27:52'),
  (3069, 11, '2026-01-02 19:10:25', 'paid', 'USD', 13, '2026-01-02 19:26:25', '2026-01-02 23:17:25'),
  (3070, 96, '2026-01-02 14:25:54', 'paid', 'EUR', 122, '2026-01-02 14:46:54', '2026-01-02 16:17:54');
insert into shopflow_app.order_items (order_item_id, order_id, product_id, quantity, unit_price) values
  (5963, 3041, 8, 1, '936.95'),
  (5964, 3041, 24, 1, '121.60'),
  (5965, 3042, 25, 1, '11.14'),
  (5966, 3042, 20, 3, '36.84'),
  (5967, 3042, 22, 1, '7.37'),
  (5968, 3043, 12, 1, '952.16'),
  (5969, 3044, 11, 1, '927.49'),
  (5970, 3044, 4, 1, '1504.40'),
  (5971, 3045, 10, 1, '25.98'),
  (5972, 3045, 21, 2, '50.07'),
  (5973, 3046, 6, 1, '30.54'),
  (5974, 3046, 25, 1, '11.14'),
  (5975, 3046, 29, 1, '15.08'),
  (5976, 3047, 3, 1, '55.88'),
  (5977, 3048, 21, 1, '50.07'),
  (5978, 3048, 2, 1, '46.71'),
  (5979, 3048, 18, 1, '16.12'),
  (5980, 3049, 30, 2, '8.83'),
  (5981, 3050, 18, 2, '16.12'),
  (5982, 3051, 19, 1, '15.12'),
  (5983, 3051, 25, 1, '11.14'),
  (5984, 3051, 2, 1, '46.71'),
  (5985, 3051, 32, 1, '11.50'),
  (5986, 3052, 28, 2, '19.24'),
  (5987, 3053, 23, 2, '262.88'),
  (5988, 3053, 28, 1, '189.38'),
  (5989, 3054, 28, 1, '189.38'),
  (5990, 3054, 18, 2, '174.46'),
  (5991, 3055, 22, 1, '79.74'),
  (5992, 3056, 23, 1, '262.88'),
  (5993, 3056, 29, 2, '163.20'),
  (5994, 3056, 9, 3, '276.10'),
  (5995, 3056, 1, 2, '737.77'),
  (5996, 3057, 23, 1, '24.29'),
  (5997, 3057, 32, 2, '11.50'),
  (5998, 3058, 25, 2, '11.14'),
  (5999, 3058, 4, 1, '139.01'),
  (6000, 3059, 4, 1, '139.01'),
  (6001, 3060, 17, 3, '79.17'),
  (6002, 3060, 1, 1, '68.17'),
  (6003, 3061, 21, 1, '541.88'),
  (6004, 3061, 16, 1, '1146.00'),
  (6005, 3062, 12, 1, '87.98'),
  (6006, 3063, 30, 1, '8.83'),
  (6007, 3064, 17, 3, '79.17'),
  (6008, 3064, 29, 1, '15.08'),
  (6009, 3064, 25, 1, '11.14'),
  (6010, 3065, 29, 2, '15.08'),
  (6011, 3066, 22, 1, '7.37'),
  (6012, 3066, 20, 1, '36.84'),
  (6013, 3067, 11, 2, '94.24'),
  (6014, 3067, 23, 1, '26.71'),
  (6015, 3068, 18, 2, '16.12'),
  (6016, 3068, 1, 1, '68.17'),
  (6017, 3069, 10, 2, '28.57'),
  (6018, 3069, 23, 1, '26.71'),
  (6019, 3069, 18, 2, '17.73'),
  (6020, 3070, 9, 1, '25.51');
insert into payments_provider.payments (payment_id, order_id, payment_method, status, amount_cents, currency, created_at, _loaded_at) values
  (3210, 3042, 'card', 'failed', 12903, 'EUR', '2026-01-02 12:27:58', '2026-01-02 13:49:58'),
  (3211, 3042, 'paypal', 'succeeded', 12903, 'EUR', '2026-01-02 12:53:58', '2026-01-02 14:05:58'),
  (3212, 3043, 'card', 'pending', 95216, 'MAD', '2026-01-02 16:49:14', '2026-01-02 18:00:14'),
  (3213, 3044, 'bank_transfer', 'succeeded', 243189, 'MAD', '2026-01-02 11:50:52', '2026-01-02 13:05:52'),
  (3214, 3045, 'bank_transfer', 'succeeded', 12612, 'EUR', '2026-01-02 20:16:39', '2026-01-02 21:35:39'),
  (3215, 3046, 'paypal', 'failed', 5676, 'EUR', '2026-01-02 19:57:17', '2026-01-02 20:48:17'),
  (3216, 3046, 'card', 'succeeded', 5676, 'EUR', '2026-01-02 20:23:17', '2026-01-02 20:42:17'),
  (3217, 3047, 'card', 'succeeded', 5588, 'USD', '2026-01-02 12:21:00', '2026-01-02 13:23:00'),
  (3218, 3048, 'card', 'succeeded', 11290, 'EUR', '2026-01-02 09:23:54', '2026-01-02 10:21:54'),
  (3219, 3049, 'card', 'succeeded', 1766, 'EUR', '2026-01-02 09:46:48', '2026-01-02 09:57:48'),
  (3220, 3050, 'card', 'failed', 3224, 'EUR', '2026-01-02 16:11:28', '2026-01-02 16:34:28'),
  (3221, 3050, 'paypal', 'succeeded', 3224, 'EUR', '2026-01-02 16:22:28', '2026-01-02 17:16:28'),
  (3222, 3051, 'card', 'succeeded', 8447, 'EUR', '2026-01-02 07:48:36', '2026-01-02 09:11:36'),
  (3223, 3052, 'card', 'pending', 3848, 'USD', '2026-01-02 12:43:04', '2026-01-02 13:35:04'),
  (3224, 3053, 'paypal', 'pending', 71514, 'MAD', '2026-01-02 14:49:09', '2026-01-02 15:30:09'),
  (3225, 3054, 'cash_on_delivery', 'succeeded', 53830, 'MAD', '2026-01-02 16:39:26', '2026-01-02 17:22:26'),
  (3226, 3055, 'paypal', 'pending', 7974, 'MAD', '2026-01-02 15:23:09', '2026-01-02 16:26:09'),
  (3227, 3056, 'cash_on_delivery', 'succeeded', 289312, 'MAD', '2026-01-02 17:37:18', '2026-01-02 17:47:18'),
  (3228, 3057, 'card', 'succeeded', 4729, 'EUR', '2026-01-02 15:09:31', '2026-01-02 16:39:31'),
  (3229, 3058, 'paypal', 'succeeded', 16129, 'EUR', '2026-01-02 19:22:52', '2026-01-02 20:25:52'),
  (3230, 3059, 'card', 'failed', 13901, 'EUR', '2026-01-02 11:18:43', '2026-01-02 11:37:43'),
  (3231, 3059, 'paypal', 'succeeded', 13901, 'EUR', '2026-01-02 11:45:43', '2026-01-02 11:58:43'),
  (3232, 3060, 'card', 'succeeded', 30568, 'EUR', '2026-01-02 08:38:44', '2026-01-02 09:58:44'),
  (3233, 3061, 'paypal', 'succeeded', 168788, 'MAD', '2026-01-02 10:36:56', '2026-01-02 11:34:56'),
  (3234, 3062, 'card', 'succeeded', 8798, 'EUR', '2026-01-02 16:35:05', '2026-01-02 17:06:05'),
  (3235, 3063, 'card', 'succeeded', 883, 'EUR', '2026-01-02 16:19:45', '2026-01-02 17:39:45'),
  (3236, 3065, 'card', 'succeeded', 3016, 'EUR', '2026-01-02 12:39:17', '2026-01-02 13:40:17'),
  (3237, 3066, 'bank_transfer', 'succeeded', 4421, 'EUR', '2026-01-02 11:07:09', '2026-01-02 12:25:09'),
  (3238, 3067, 'card', 'succeeded', 21519, 'USD', '2026-01-02 11:23:21', '2026-01-02 11:43:21'),
  (3239, 3068, 'paypal', 'succeeded', 10041, 'EUR', '2026-01-02 16:07:52', '2026-01-02 16:45:52'),
  (3240, 3069, 'paypal', 'succeeded', 11931, 'USD', '2026-01-02 19:23:25', '2026-01-02 20:32:25'),
  (3241, 3070, 'card', 'succeeded', 2551, 'EUR', '2026-01-02 14:42:54', '2026-01-02 16:12:54');

-- shipments: 34 new (in_transit), 59 delivered
insert into shipping.shipments (shipment_id, order_id, carrier, tracking_number, status, shipped_at, delivered_at, updated_at, _loaded_at) values
  (2712, 3001, 'Amana', 'TRK00300182', 'in_transit', '2026-01-02 10:06:17', null, '2026-01-02 10:06:17', '2026-01-02 11:06:17'),
  (2713, 3002, 'Colissimo', 'TRK00300257', 'in_transit', '2026-01-02 17:26:57', null, '2026-01-02 17:26:57', '2026-01-02 19:26:57'),
  (2714, 3003, 'Amana', 'TRK00300340', 'in_transit', '2026-01-02 17:04:58', null, '2026-01-02 17:04:58', '2026-01-02 19:04:58'),
  (2715, 3004, 'bpost', 'TRK00300436', 'in_transit', '2026-01-02 13:55:02', null, '2026-01-02 13:55:02', '2026-01-02 15:55:02'),
  (2716, 3005, 'Amana', 'TRK00300567', 'in_transit', '2026-01-02 09:15:07', null, '2026-01-02 09:15:07', '2026-01-02 12:15:07'),
  (2717, 3006, 'DHL', 'TRK00300612', 'in_transit', '2026-01-02 14:04:44', null, '2026-01-02 14:04:44', '2026-01-02 16:04:44'),
  (2718, 3007, 'bpost', 'TRK00300790', 'in_transit', '2026-01-02 15:52:05', null, '2026-01-02 15:52:05', '2026-01-02 17:52:05'),
  (2719, 3009, 'Colissimo', 'TRK00300990', 'in_transit', '2026-01-02 15:41:14', null, '2026-01-02 15:41:14', '2026-01-02 17:41:14'),
  (2720, 3010, 'bpost', 'TRK00301073', 'in_transit', '2026-01-02 13:26:10', null, '2026-01-02 13:26:10', '2026-01-02 15:26:10'),
  (2721, 3011, 'DHL', 'TRK00301125', 'in_transit', '2026-01-02 09:00:25', null, '2026-01-02 09:00:25', '2026-01-02 10:00:25'),
  (2722, 3013, 'DHL', 'TRK00301381', 'in_transit', '2026-01-02 10:55:34', null, '2026-01-02 10:55:34', '2026-01-02 12:55:34'),
  (2723, 3016, 'CTM Messagerie', 'TRK00301649', 'in_transit', '2026-01-02 09:43:04', null, '2026-01-02 09:43:04', '2026-01-02 12:43:04'),
  (2724, 3017, 'DHL', 'TRK00301717', 'in_transit', '2026-01-02 13:20:57', null, '2026-01-02 13:20:57', '2026-01-02 16:20:57'),
  (2725, 3018, 'DHL', 'TRK00301867', 'in_transit', '2026-01-02 11:10:31', null, '2026-01-02 11:10:31', '2026-01-02 14:10:31'),
  (2726, 3019, 'FedEx', 'TRK00301947', 'in_transit', '2026-01-02 14:10:57', null, '2026-01-02 14:10:57', '2026-01-02 16:10:57'),
  (2727, 3020, 'Amana', 'TRK00302068', 'in_transit', '2026-01-02 16:30:02', null, '2026-01-02 16:30:02', '2026-01-02 18:30:02'),
  (2728, 3021, 'DHL', 'TRK00302198', 'in_transit', '2026-01-02 14:47:41', null, '2026-01-02 14:47:41', '2026-01-02 15:47:41'),
  (2729, 3022, 'UPS', 'TRK00302220', 'in_transit', '2026-01-02 11:44:29', null, '2026-01-02 11:44:29', '2026-01-02 14:44:29'),
  (2730, 3023, 'DHL', 'TRK00302350', 'in_transit', '2026-01-02 09:45:40', null, '2026-01-02 09:45:40', '2026-01-02 12:45:40'),
  (2731, 3024, 'DHL', 'TRK00302490', 'in_transit', '2026-01-02 15:25:43', null, '2026-01-02 15:25:43', '2026-01-02 18:25:43'),
  (2732, 3025, 'Amana', 'TRK00302556', 'in_transit', '2026-01-02 15:28:48', null, '2026-01-02 15:28:48', '2026-01-02 16:28:48'),
  (2733, 3026, 'Amana', 'TRK00302638', 'in_transit', '2026-01-02 09:24:05', null, '2026-01-02 09:24:05', '2026-01-02 12:24:05'),
  (2734, 3027, 'DHL', 'TRK00302770', 'in_transit', '2026-01-02 12:20:46', null, '2026-01-02 12:20:46', '2026-01-02 13:20:46'),
  (2735, 3028, 'Amana', 'TRK00302886', 'in_transit', '2026-01-02 12:34:47', null, '2026-01-02 12:34:47', '2026-01-02 13:34:47'),
  (2736, 3029, 'DHL', 'TRK00302928', 'in_transit', '2026-01-02 11:53:05', null, '2026-01-02 11:53:05', '2026-01-02 14:53:05'),
  (2737, 3030, 'CTM Messagerie', 'TRK00303079', 'in_transit', '2026-01-02 17:34:08', null, '2026-01-02 17:34:08', '2026-01-02 20:34:08'),
  (2738, 3031, 'Colissimo', 'TRK00303121', 'in_transit', '2026-01-02 13:31:39', null, '2026-01-02 13:31:39', '2026-01-02 15:31:39'),
  (2739, 3032, 'DHL', 'TRK00303259', 'in_transit', '2026-01-02 14:54:22', null, '2026-01-02 14:54:22', '2026-01-02 15:54:22'),
  (2740, 3034, 'Amana', 'TRK00303434', 'in_transit', '2026-01-02 16:55:06', null, '2026-01-02 16:55:06', '2026-01-02 17:55:06'),
  (2741, 3036, 'DHL', 'TRK00303646', 'in_transit', '2026-01-02 11:06:16', null, '2026-01-02 11:06:16', '2026-01-02 14:06:16'),
  (2742, 3037, 'Amana', 'TRK00303756', 'in_transit', '2026-01-02 09:34:34', null, '2026-01-02 09:34:34', '2026-01-02 10:34:34'),
  (2743, 3038, 'DHL', 'TRK00303891', 'in_transit', '2026-01-02 10:35:20', null, '2026-01-02 10:35:20', '2026-01-02 11:35:20'),
  (2744, 3039, 'CTM Messagerie', 'TRK00303995', 'in_transit', '2026-01-02 10:53:11', null, '2026-01-02 10:53:11', '2026-01-02 12:53:11'),
  (2745, 3040, 'CTM Messagerie', 'TRK00304021', 'in_transit', '2026-01-02 16:24:38', null, '2026-01-02 16:24:38', '2026-01-02 19:24:38');
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 14:39:34', updated_at = '2026-01-02 14:39:34', _loaded_at = '2026-01-02 16:39:34' where shipment_id = 310;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 15:21:28', updated_at = '2026-01-02 15:21:28', _loaded_at = '2026-01-02 16:21:28' where shipment_id = 450;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 10:09:57', updated_at = '2026-01-02 10:09:57', _loaded_at = '2026-01-02 11:09:57' where shipment_id = 609;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 08:45:39', updated_at = '2026-01-02 08:45:39', _loaded_at = '2026-01-02 09:45:39' where shipment_id = 728;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 12:20:21', updated_at = '2026-01-02 12:20:21', _loaded_at = '2026-01-02 15:20:21' where shipment_id = 1072;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 16:47:31', updated_at = '2026-01-02 16:47:31', _loaded_at = '2026-01-02 17:47:31' where shipment_id = 1235;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 08:56:54', updated_at = '2026-01-02 08:56:54', _loaded_at = '2026-01-02 09:56:54' where shipment_id = 1622;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 14:55:46', updated_at = '2026-01-02 14:55:46', _loaded_at = '2026-01-02 16:55:46' where shipment_id = 1700;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 10:17:29', updated_at = '2026-01-02 10:17:29', _loaded_at = '2026-01-02 13:17:29' where shipment_id = 1704;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 12:03:07', updated_at = '2026-01-02 12:03:07', _loaded_at = '2026-01-02 13:03:07' where shipment_id = 1793;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 13:10:25', updated_at = '2026-01-02 13:10:25', _loaded_at = '2026-01-02 16:10:25' where shipment_id = 1927;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 10:18:20', updated_at = '2026-01-02 10:18:20', _loaded_at = '2026-01-02 12:18:20' where shipment_id = 2126;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 10:55:58', updated_at = '2026-01-02 10:55:58', _loaded_at = '2026-01-02 11:55:58' where shipment_id = 2143;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 16:54:49', updated_at = '2026-01-02 16:54:49', _loaded_at = '2026-01-02 19:54:49' where shipment_id = 2194;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 14:36:54', updated_at = '2026-01-02 14:36:54', _loaded_at = '2026-01-02 16:36:54' where shipment_id = 2305;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 08:38:37', updated_at = '2026-01-02 08:38:37', _loaded_at = '2026-01-02 10:38:37' where shipment_id = 2415;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 11:08:25', updated_at = '2026-01-02 11:08:25', _loaded_at = '2026-01-02 14:08:25' where shipment_id = 2420;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 17:38:07', updated_at = '2026-01-02 17:38:07', _loaded_at = '2026-01-02 20:38:07' where shipment_id = 2427;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 13:30:38', updated_at = '2026-01-02 13:30:38', _loaded_at = '2026-01-02 14:30:38' where shipment_id = 2441;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 13:13:39', updated_at = '2026-01-02 13:13:39', _loaded_at = '2026-01-02 15:13:39' where shipment_id = 2649;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 08:00:39', updated_at = '2026-01-02 08:00:39', _loaded_at = '2026-01-02 09:00:39' where shipment_id = 2460;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 08:16:59', updated_at = '2026-01-02 08:16:59', _loaded_at = '2026-01-02 11:16:59' where shipment_id = 2463;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 08:20:10', updated_at = '2026-01-02 08:20:10', _loaded_at = '2026-01-02 10:20:10' where shipment_id = 2471;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 11:10:30', updated_at = '2026-01-02 11:10:30', _loaded_at = '2026-01-02 14:10:30' where shipment_id = 2495;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 11:22:27', updated_at = '2026-01-02 11:22:27', _loaded_at = '2026-01-02 14:22:27' where shipment_id = 2500;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 08:20:26', updated_at = '2026-01-02 08:20:26', _loaded_at = '2026-01-02 09:20:26' where shipment_id = 2524;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 17:48:42', updated_at = '2026-01-02 17:48:42', _loaded_at = '2026-01-02 19:48:42' where shipment_id = 2541;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 15:53:22', updated_at = '2026-01-02 15:53:22', _loaded_at = '2026-01-02 18:53:22' where shipment_id = 2556;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 14:42:14', updated_at = '2026-01-02 14:42:14', _loaded_at = '2026-01-02 17:42:14' where shipment_id = 2566;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 09:38:05', updated_at = '2026-01-02 09:38:05', _loaded_at = '2026-01-02 11:38:05' where shipment_id = 2579;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 16:38:26', updated_at = '2026-01-02 16:38:26', _loaded_at = '2026-01-02 19:38:26' where shipment_id = 2588;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 08:08:04', updated_at = '2026-01-02 08:08:04', _loaded_at = '2026-01-02 10:08:04' where shipment_id = 2590;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 12:59:45', updated_at = '2026-01-02 12:59:45', _loaded_at = '2026-01-02 15:59:45' where shipment_id = 2594;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 09:37:10', updated_at = '2026-01-02 09:37:10', _loaded_at = '2026-01-02 11:37:10' where shipment_id = 2613;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 17:47:11', updated_at = '2026-01-02 17:47:11', _loaded_at = '2026-01-02 20:47:11' where shipment_id = 2615;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 16:30:08', updated_at = '2026-01-02 16:30:08', _loaded_at = '2026-01-02 18:30:08' where shipment_id = 2621;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 14:12:54', updated_at = '2026-01-02 14:12:54', _loaded_at = '2026-01-02 17:12:54' where shipment_id = 2624;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 12:34:28', updated_at = '2026-01-02 12:34:28', _loaded_at = '2026-01-02 14:34:28' where shipment_id = 2625;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 09:39:38', updated_at = '2026-01-02 09:39:38', _loaded_at = '2026-01-02 12:39:38' where shipment_id = 2628;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 10:01:32', updated_at = '2026-01-02 10:01:32', _loaded_at = '2026-01-02 12:01:32' where shipment_id = 2659;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 08:44:34', updated_at = '2026-01-02 08:44:34', _loaded_at = '2026-01-02 11:44:34' where shipment_id = 2660;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 12:12:17', updated_at = '2026-01-02 12:12:17', _loaded_at = '2026-01-02 14:12:17' where shipment_id = 2662;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 13:32:56', updated_at = '2026-01-02 13:32:56', _loaded_at = '2026-01-02 16:32:56' where shipment_id = 2663;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 17:36:13', updated_at = '2026-01-02 17:36:13', _loaded_at = '2026-01-02 20:36:13' where shipment_id = 2633;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 16:31:54', updated_at = '2026-01-02 16:31:54', _loaded_at = '2026-01-02 19:31:54' where shipment_id = 2665;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 13:40:04', updated_at = '2026-01-02 13:40:04', _loaded_at = '2026-01-02 14:40:04' where shipment_id = 2666;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 16:01:51', updated_at = '2026-01-02 16:01:51', _loaded_at = '2026-01-02 19:01:51' where shipment_id = 2636;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 11:39:27', updated_at = '2026-01-02 11:39:27', _loaded_at = '2026-01-02 12:39:27' where shipment_id = 2637;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 10:24:18', updated_at = '2026-01-02 10:24:18', _loaded_at = '2026-01-02 13:24:18' where shipment_id = 2638;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 15:06:04', updated_at = '2026-01-02 15:06:04', _loaded_at = '2026-01-02 16:06:04' where shipment_id = 2670;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 17:14:27', updated_at = '2026-01-02 17:14:27', _loaded_at = '2026-01-02 18:14:27' where shipment_id = 2674;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 08:36:03', updated_at = '2026-01-02 08:36:03', _loaded_at = '2026-01-02 09:36:03' where shipment_id = 2676;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 10:14:45', updated_at = '2026-01-02 10:14:45', _loaded_at = '2026-01-02 11:14:45' where shipment_id = 2677;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 12:35:06', updated_at = '2026-01-02 12:35:06', _loaded_at = '2026-01-02 13:35:06' where shipment_id = 2678;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 17:12:25', updated_at = '2026-01-02 17:12:25', _loaded_at = '2026-01-02 18:12:25' where shipment_id = 2679;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 11:38:44', updated_at = '2026-01-02 11:38:44', _loaded_at = '2026-01-02 12:38:44' where shipment_id = 2680;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 11:50:50', updated_at = '2026-01-02 11:50:50', _loaded_at = '2026-01-02 14:50:50' where shipment_id = 2681;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 17:02:43', updated_at = '2026-01-02 17:02:43', _loaded_at = '2026-01-02 20:02:43' where shipment_id = 2684;
update shipping.shipments set status = 'delivered', delivered_at = '2026-01-02 15:47:35', updated_at = '2026-01-02 15:47:35', _loaded_at = '2026-01-02 16:47:35' where shipment_id = 2644;

-- web events: 274 events of 2026-01-02, 43 LATE events of 2025-12-30/31, 4 duplicates
insert into web_analytics.events (event_id, session_id, customer_id, event_type, event_timestamp, page, _loaded_at) values
  ('25471d44387d6', 's007818', null, 'page_view', '2025-12-30 11:29:21', '/product/sf-boo-0028', '2026-01-02 10:06:00'),
  ('9dae182871463', 's007818', null, 'page_view', '2025-12-30 11:30:11', '/category/electronics', '2026-01-02 08:41:00'),
  ('61c25ca99147b', 's007818', null, 'add_to_cart', '2025-12-30 11:32:43', '/cart', '2026-01-02 09:54:00'),
  ('cc9dbb097a15e', 's007818', null, 'checkout_start', '2025-12-30 11:36:21', '/checkout', '2026-01-02 06:04:00'),
  ('5c3f38ecb1ada', 's007818', null, 'purchase', '2025-12-30 11:38:22', '/checkout/confirmation', '2026-01-02 06:53:00'),
  ('baa6b3e449ed4', 's007814', null, 'page_view', '2025-12-30 14:49:41', '/product/sf-boo-0028', '2026-01-02 09:30:00'),
  ('9d526a3f2eb92', 's007814', null, 'page_view', '2025-12-30 14:50:32', '/category/fashion', '2026-01-02 07:55:00'),
  ('2dc38165390a3', 's007814', null, 'page_view', '2025-12-30 14:52:24', '/category/electronics', '2026-01-02 10:05:00'),
  ('868063cad064b', 's007814', null, 'page_view', '2025-12-30 14:55:21', '/product/sf-boo-0033', '2026-01-02 07:39:00'),
  ('c875ced34b199', 's007816', 322, 'page_view', '2025-12-30 16:06:40', '/category/books', '2026-01-02 07:08:00'),
  ('58ab4c484d794', 's007815', 266, 'page_view', '2025-12-30 17:08:39', '/product/sf-ele-0002', '2026-01-02 06:52:00'),
  ('acd34e67b10a7', 's007815', 266, 'page_view', '2025-12-30 17:11:30', '/product/sf-ele-0006', '2026-01-02 11:29:00'),
  ('07355656324c5', 's007815', 266, 'page_view', '2025-12-30 17:11:52', '/product/sf-ele-0035', '2026-01-02 09:09:00'),
  ('bdc9f8e8a7374', 's007815', 266, 'page_view', '2025-12-30 17:14:38', '/category/electronics', '2026-01-02 11:56:00'),
  ('5d3ffb3de1073', 's007813', null, 'page_view', '2025-12-30 19:52:06', '/product/sf-fas-0015', '2026-01-02 07:39:00'),
  ('5d3ffb3de1073', 's007813', null, 'page_view', '2025-12-30 19:52:06', '/product/sf-fas-0015', '2026-01-02 07:42:00'),
  ('b1ffaeaf823d4', 's007813', null, 'page_view', '2025-12-30 19:54:43', '/category/fashion', '2026-01-02 08:59:00'),
  ('b1ffaeaf823d4', 's007813', null, 'page_view', '2025-12-30 19:54:43', '/category/fashion', '2026-01-02 09:02:00'),
  ('45e2afdbb850d', 's007813', null, 'page_view', '2025-12-30 19:56:22', '/category/home', '2026-01-02 10:56:00'),
  ('45e2afdbb850d', 's007813', null, 'page_view', '2025-12-30 19:56:22', '/category/home', '2026-01-02 10:59:00'),
  ('c65b5ffe5d571', 's007813', null, 'page_view', '2025-12-30 19:59:57', '/category/home', '2026-01-02 07:57:00'),
  ('c65b5ffe5d571', 's007813', null, 'page_view', '2025-12-30 19:59:57', '/category/home', '2026-01-02 08:00:00'),
  ('b0b6fe1974b1d', 's007817', 125, 'page_view', '2025-12-30 21:24:12', '/', '2026-01-02 10:18:00'),
  ('56d207e1f66a7', 's007817', 125, 'add_to_cart', '2025-12-30 21:25:02', '/cart', '2026-01-02 08:26:00'),
  ('0f086d4d5a3c0', 's007817', 125, 'checkout_start', '2025-12-30 21:26:45', '/checkout', '2026-01-02 12:50:00'),
  ('ed108beb413a2', 's007824', 187, 'page_view', '2025-12-31 09:54:51', '/', '2026-01-02 07:28:00'),
  ('02e95f9e95f7e', 's007824', 187, 'page_view', '2025-12-31 09:55:10', '/category/beauty', '2026-01-02 11:36:00'),
  ('eb48d04da2b1a', 's007824', 187, 'page_view', '2025-12-31 09:57:00', '/product/sf-boo-0028', '2026-01-02 08:50:00'),
  ('0a6fe2408ade7', 's007819', null, 'page_view', '2025-12-31 13:06:24', '/category/fashion', '2026-01-02 09:54:00'),
  ('09ff9b68c3a0b', 's007819', null, 'page_view', '2025-12-31 13:08:50', '/category/electronics', '2026-01-02 12:21:00'),
  ('008b82879825e', 's007819', null, 'page_view', '2025-12-31 13:10:20', '/category/electronics', '2026-01-02 11:43:00'),
  ('741f4f5e788c9', 's007819', null, 'page_view', '2025-12-31 13:13:15', '/category/electronics', '2026-01-02 09:37:00'),
  ('9dcd5c1feeb0b', 's007821', null, 'page_view', '2025-12-31 14:26:28', '/product/sf-fas-0020', '2026-01-02 07:08:00'),
  ('3698da87591f8', 's007821', null, 'page_view', '2025-12-31 14:28:35', '/product/sf-ele-0007', '2026-01-02 08:18:00'),
  ('7334eebcd8f37', 's007821', null, 'add_to_cart', '2025-12-31 14:29:09', '/cart', '2026-01-02 12:58:00'),
  ('b0c7d30060e87', 's007821', null, 'checkout_start', '2025-12-31 14:33:09', '/checkout', '2026-01-02 12:47:00'),
  ('a1a98d63285a2', 's007821', null, 'purchase', '2025-12-31 14:36:33', '/checkout/confirmation', '2026-01-02 11:26:00'),
  ('725bc434320b6', 's007822', 187, 'page_view', '2025-12-31 15:18:54', '/category/home', '2026-01-02 06:31:00'),
  ('5903ba8c7c108', 's007822', 187, 'page_view', '2025-12-31 15:19:16', '/category/home', '2026-01-02 09:56:00'),
  ('5cc3f03516211', 's007822', 187, 'page_view', '2025-12-31 15:20:35', '/category/home', '2026-01-02 09:57:00'),
  ('a9994e578ff0c', 's007822', 187, 'page_view', '2025-12-31 15:24:10', '/product/sf-hom-0013', '2026-01-02 09:59:00'),
  ('969a2110bdfd6', 's007822', 187, 'page_view', '2025-12-31 15:24:20', '/category/fashion', '2026-01-02 06:15:00'),
  ('cf476bbea73bb', 's007820', 187, 'page_view', '2025-12-31 18:23:22', '/product/sf-hom-0008', '2026-01-02 09:55:00'),
  ('542feb44fda99', 's007823', null, 'page_view', '2025-12-31 21:10:43', '/category/beauty', '2026-01-02 09:45:00'),
  ('afaf38e8ae64b', 's007823', null, 'page_view', '2025-12-31 21:11:15', '/product/sf-hom-0034', '2026-01-02 11:08:00'),
  ('b676e840e8c48', 's007823', null, 'page_view', '2025-12-31 21:14:59', '/category/home', '2026-01-02 06:05:00'),
  ('93f9d3ac85e6d', 's007823', null, 'page_view', '2025-12-31 21:18:06', '/category/books', '2026-01-02 12:21:00'),
  ('703c2241533f0', 's007797', 277, 'page_view', '2026-01-02 07:20:33', '/', '2026-01-02 07:56:33'),
  ('ac5344c6a9f96', 's007797', 277, 'page_view', '2026-01-02 07:22:02', '/category/fashion', '2026-01-02 08:17:02'),
  ('f62b257e868ef', 's007797', 277, 'page_view', '2026-01-02 07:22:33', '/category/electronics', '2026-01-02 07:59:33'),
  ('d4c9297c0621c', 's007797', 277, 'page_view', '2026-01-02 07:26:31', '/product/sf-fas-0019', '2026-01-02 07:33:31'),
  ('b8a6296fb386a', 's007797', 277, 'add_to_cart', '2026-01-02 07:27:00', '/cart', '2026-01-02 07:46:00'),
  ('52c04a90d25f6', 's007756', null, 'page_view', '2026-01-02 07:48:57', '/product/sf-hom-0013', '2026-01-02 07:58:57'),
  ('4d8889a684871', 's007756', null, 'page_view', '2026-01-02 07:52:16', '/product/sf-bea-0026', '2026-01-02 08:06:16'),
  ('c703cd92d25bb', 's007768', 172, 'page_view', '2026-01-02 07:52:51', '/', '2026-01-02 08:19:51'),
  ('489f4af2572d2', 's007768', 172, 'page_view', '2026-01-02 07:53:27', '/product/sf-ele-0006', '2026-01-02 08:19:27'),
  ('e45ff0a2e1d7a', 's007767', null, 'page_view', '2026-01-02 07:54:44', '/category/fashion', '2026-01-02 08:29:44'),
  ('4f9d17d9ce6ff', 's007767', null, 'page_view', '2026-01-02 07:55:03', '/category/electronics', '2026-01-02 08:23:03'),
  ('fb8d2b0774f60', 's007768', 172, 'page_view', '2026-01-02 07:55:29', '/category/beauty', '2026-01-02 08:44:29'),
  ('72c2dffcf3230', 's007767', null, 'page_view', '2026-01-02 07:55:39', '/category/home', '2026-01-02 08:15:39'),
  ('47db9dfed8382', 's007767', null, 'page_view', '2026-01-02 07:56:36', '/category/electronics', '2026-01-02 08:29:36'),
  ('aa60660dac380', 's007768', 172, 'page_view', '2026-01-02 07:58:32', '/category/beauty', '2026-01-02 08:24:32'),
  ('d4bb70051a969', 's007767', null, 'add_to_cart', '2026-01-02 07:58:38', '/cart', '2026-01-02 08:15:38'),
  ('8758ef9c2c563', 's007768', 172, 'page_view', '2026-01-02 07:58:51', '/category/electronics', '2026-01-02 08:14:51'),
  ('7b580506cace7', 's007768', 172, 'add_to_cart', '2026-01-02 07:59:14', '/cart', '2026-01-02 08:04:14'),
  ('ed923ebb92c6d', 's007768', 172, 'checkout_start', '2026-01-02 08:01:45', '/checkout', '2026-01-02 08:51:45'),
  ('94eb3de07e15e', 's007782', null, 'page_view', '2026-01-02 08:10:40', '/product/sf-bea-0026', '2026-01-02 08:41:40'),
  ('12df0e0e7f0b7', 's007782', null, 'page_view', '2026-01-02 08:12:31', '/category/fashion', '2026-01-02 08:22:31'),
  ('d4e9a0b8f5bde', 's007761', 12, 'page_view', '2026-01-02 08:23:40', '/category/beauty', '2026-01-02 08:34:40'),
  ('90c83e9ec2a78', 's007761', 12, 'page_view', '2026-01-02 08:26:42', '/category/fashion', '2026-01-02 09:16:42'),
  ('4d47c73506a15', 's007761', 12, 'page_view', '2026-01-02 08:27:54', '/product/sf-ele-0004', '2026-01-02 08:46:54'),
  ('1fe8d79e4cc84', 's007761', 12, 'page_view', '2026-01-02 08:29:34', '/category/beauty', '2026-01-02 08:51:34'),
  ('2d7a7e050d45c', 's007761', 12, 'page_view', '2026-01-02 08:31:42', '/category/electronics', '2026-01-02 09:22:42'),
  ('cbb510b53a503', 's007739', null, 'page_view', '2026-01-02 08:34:20', '/', '2026-01-02 09:10:20'),
  ('e8604befe6108', 's007739', null, 'page_view', '2026-01-02 08:37:50', '/product/sf-boo-0031', '2026-01-02 09:10:50'),
  ('8220ee0d80cfc', 's007745', 273, 'page_view', '2026-01-02 08:39:37', '/product/sf-hom-0013', '2026-01-02 08:53:37'),
  ('52c7480ea4657', 's007739', null, 'page_view', '2026-01-02 08:40:29', '/category/home', '2026-01-02 09:12:29'),
  ('9d7ab54f73bc3', 's007739', null, 'page_view', '2026-01-02 08:42:18', '/category/books', '2026-01-02 09:26:18'),
  ('6790ddd7f02b0', 's007745', 273, 'page_view', '2026-01-02 08:42:39', '/category/home', '2026-01-02 09:15:39'),
  ('91bf079d5c2c7', 's007735', 219, 'page_view', '2026-01-02 08:42:42', '/', '2026-01-02 09:36:42'),
  ('ed6319f7c18ab', 's007739', null, 'page_view', '2026-01-02 08:43:28', '/category/electronics', '2026-01-02 09:11:28'),
  ('d12daf3f70742', 's007755', null, 'page_view', '2026-01-02 08:59:13', '/product/sf-bea-0025', '2026-01-02 09:28:13'),
  ('416aa18f627e8', 's007755', null, 'page_view', '2026-01-02 09:00:15', '/category/fashion', '2026-01-02 09:24:15'),
  ('05666a1a3bab3', 's007743', null, 'page_view', '2026-01-02 09:05:36', '/', '2026-01-02 09:52:36'),
  ('97810c2c06cd9', 's007743', null, 'page_view', '2026-01-02 09:09:10', '/product/sf-fas-0018', '2026-01-02 09:21:10'),
  ('e177c491e5ad6', 's007743', null, 'add_to_cart', '2026-01-02 09:13:10', '/cart', '2026-01-02 09:53:10'),
  ('10cd8f017bacf', 's007743', null, 'checkout_start', '2026-01-02 09:15:22', '/checkout', '2026-01-02 10:08:22'),
  ('66ab3681e9380', 's007799', 299, 'page_view', '2026-01-02 09:17:45', '/', '2026-01-02 09:23:45'),
  ('78449d7676da0', 's007799', 299, 'page_view', '2026-01-02 09:19:41', '/product/sf-bea-0027', '2026-01-02 09:49:41'),
  ('745ff106bbaf3', 's007799', 299, 'page_view', '2026-01-02 09:19:59', '/category/home', '2026-01-02 09:43:59'),
  ('21b9d5ece1f35', 's007770', 411, 'page_view', '2026-01-02 09:39:15', '/category/fashion', '2026-01-02 09:55:15'),
  ('d1ab13c62263d', 's007770', 411, 'page_view', '2026-01-02 09:39:27', '/product/sf-ele-0007', '2026-01-02 10:08:27'),
  ('9026f940cd226', 's007770', 411, 'page_view', '2026-01-02 09:42:37', '/category/books', '2026-01-02 10:31:37'),
  ('e78c4a2a3dc9b', 's007752', null, 'page_view', '2026-01-02 09:43:45', '/', '2026-01-02 10:05:45'),
  ('a5f2a283be143', 's007752', null, 'page_view', '2026-01-02 09:45:10', '/category/fashion', '2026-01-02 09:50:10'),
  ('a2889a4cf72d0', 's007801', null, 'page_view', '2026-01-02 09:45:35', '/', '2026-01-02 10:17:35'),
  ('513eb8ed3931e', 's007752', null, 'page_view', '2026-01-02 09:48:48', '/category/electronics', '2026-01-02 10:31:48'),
  ('9d17f6ae2382c', 's007752', null, 'page_view', '2026-01-02 09:52:24', '/category/electronics', '2026-01-02 10:17:24'),
  ('5a5da4f6fe246', 's007752', null, 'add_to_cart', '2026-01-02 09:56:10', '/cart', '2026-01-02 10:10:10'),
  ('a335acdcd6603', 's007809', null, 'page_view', '2026-01-02 10:04:11', '/product/sf-hom-0009', '2026-01-02 10:26:11'),
  ('56c788e61e37f', 's007809', null, 'page_view', '2026-01-02 10:07:59', '/product/sf-hom-0010', '2026-01-02 10:59:59'),
  ('f8b9c0a90ffb9', 's007809', null, 'page_view', '2026-01-02 10:09:47', '/category/books', '2026-01-02 10:52:47'),
  ('58471cf5db69e', 's007775', 399, 'page_view', '2026-01-02 10:19:53', '/product/sf-boo-0033', '2026-01-02 10:39:53'),
  ('b7db4a51dc873', 's007775', 399, 'page_view', '2026-01-02 10:20:17', '/product/sf-fas-0016', '2026-01-02 10:27:17'),
  ('9f86be54b64ec', 's007791', 176, 'page_view', '2026-01-02 10:21:07', '/category/fashion', '2026-01-02 11:08:07'),
  ('384d98eecf5c8', 's007775', 399, 'page_view', '2026-01-02 10:22:06', '/category/fashion', '2026-01-02 10:37:06'),
  ('248306255077c', 's007775', 399, 'page_view', '2026-01-02 10:26:03', '/category/books', '2026-01-02 11:09:03'),
  ('72a164c642071', 's007775', 399, 'page_view', '2026-01-02 10:29:43', '/category/books', '2026-01-02 11:16:43'),
  ('0959a75ea4560', 's007775', 399, 'add_to_cart', '2026-01-02 10:30:52', '/cart', '2026-01-02 10:59:52'),
  ('bc5187d60c3d4', 's007775', 399, 'checkout_start', '2026-01-02 10:32:23', '/checkout', '2026-01-02 10:44:23'),
  ('1a28cf4123f61', 's007775', 399, 'purchase', '2026-01-02 10:33:09', '/checkout/confirmation', '2026-01-02 11:28:09'),
  ('2b27e9ccb00dc', 's007788', null, 'page_view', '2026-01-02 10:47:33', '/category/books', '2026-01-02 11:27:33'),
  ('e076e1c2e4103', 's007807', null, 'page_view', '2026-01-02 10:58:11', '/', '2026-01-02 11:41:11'),
  ('22cbfc1d7ef5d', 's007807', null, 'page_view', '2026-01-02 11:00:40', '/product/sf-bea-0027', '2026-01-02 11:15:40'),
  ('d0b99d9390a90', 's007807', null, 'add_to_cart', '2026-01-02 11:04:21', '/cart', '2026-01-02 11:44:21'),
  ('cde957a7f3765', 's007746', null, 'page_view', '2026-01-02 11:07:55', '/category/electronics', '2026-01-02 11:45:55'),
  ('ef4cb7b7b1a07', 's007746', null, 'page_view', '2026-01-02 11:10:47', '/category/fashion', '2026-01-02 11:17:47'),
  ('fed29a6d9f720', 's007793', null, 'page_view', '2026-01-02 11:12:56', '/category/beauty', '2026-01-02 11:28:56'),
  ('19715d0178138', 's007759', null, 'page_view', '2026-01-02 11:13:13', '/', '2026-01-02 11:37:13'),
  ('9d0cadaeee35b', 's007744', 274, 'page_view', '2026-01-02 11:14:19', '/product/sf-hom-0012', '2026-01-02 11:48:19'),
  ('d1a891a1b7513', 's007793', null, 'page_view', '2026-01-02 11:14:59', '/category/books', '2026-01-02 11:24:59'),
  ('6f2c34325e080', 's007759', null, 'add_to_cart', '2026-01-02 11:16:01', '/cart', '2026-01-02 12:11:01'),
  ('5b0884db379a3', 's007793', null, 'page_view', '2026-01-02 11:16:02', '/category/books', '2026-01-02 11:31:02'),
  ('17915259ab477', 's007759', null, 'checkout_start', '2026-01-02 11:16:58', '/checkout', '2026-01-02 12:08:58'),
  ('704954d314012', 's007744', 274, 'page_view', '2026-01-02 11:17:13', '/category/books', '2026-01-02 11:52:13'),
  ('31bc8161062e1', 's007793', null, 'page_view', '2026-01-02 11:19:00', '/category/books', '2026-01-02 11:55:00'),
  ('1777a76c7bce4', 's007780', null, 'page_view', '2026-01-02 11:48:47', '/', '2026-01-02 12:29:47'),
  ('a40201077e009', 's007780', null, 'page_view', '2026-01-02 11:50:32', '/category/home', '2026-01-02 12:21:32'),
  ('5b4fe9c7d4734', 's007780', null, 'page_view', '2026-01-02 11:51:23', '/product/sf-hom-0034', '2026-01-02 12:07:23'),
  ('eb55f644c82ce', 's007737', null, 'page_view', '2026-01-02 11:53:28', '/product/sf-boo-0033', '2026-01-02 12:46:28'),
  ('338ac702b9e75', 's007737', null, 'page_view', '2026-01-02 11:53:51', '/category/electronics', '2026-01-02 12:06:51'),
  ('a1d2360fbd9aa', 's007780', null, 'page_view', '2026-01-02 11:55:20', '/category/fashion', '2026-01-02 12:43:20'),
  ('da8ac449ca2b5', 's007737', null, 'page_view', '2026-01-02 11:57:24', '/category/fashion', '2026-01-02 12:18:24'),
  ('b55b002a97dba', 's007780', null, 'page_view', '2026-01-02 11:58:02', '/product/sf-bea-0027', '2026-01-02 12:34:02'),
  ('7143c6211a4a9', 's007762', null, 'page_view', '2026-01-02 11:58:23', '/product/sf-ele-0001', '2026-01-02 12:06:23'),
  ('61aaed257baee', 's007737', null, 'page_view', '2026-01-02 11:59:26', '/category/books', '2026-01-02 12:31:26'),
  ('b16676fc77818', 's007762', null, 'page_view', '2026-01-02 12:00:47', '/product/sf-hom-0012', '2026-01-02 12:35:47'),
  ('d656c6528bf29', 's007762', null, 'page_view', '2026-01-02 12:01:16', '/category/beauty', '2026-01-02 12:22:16'),
  ('0bbafb3a8d96c', 's007737', null, 'page_view', '2026-01-02 12:01:17', '/category/books', '2026-01-02 12:48:17'),
  ('c832e57a2fbe6', 's007783', null, 'page_view', '2026-01-02 12:01:43', '/category/books', '2026-01-02 12:23:43'),
  ('93987fa87086f', 's007737', null, 'add_to_cart', '2026-01-02 12:02:43', '/cart', '2026-01-02 12:10:43'),
  ('4d3e34c8038c8', 's007762', null, 'page_view', '2026-01-02 12:02:54', '/category/home', '2026-01-02 12:09:54'),
  ('89fb43407c3eb', 's007783', null, 'page_view', '2026-01-02 12:04:03', '/category/fashion', '2026-01-02 12:10:03'),
  ('30a15172938ab', 's007783', null, 'page_view', '2026-01-02 12:06:16', '/category/beauty', '2026-01-02 13:00:16'),
  ('d3adcab42d82b', 's007783', null, 'page_view', '2026-01-02 12:06:37', '/category/home', '2026-01-02 12:59:37'),
  ('872b3475548cd', 's007804', 117, 'page_view', '2026-01-02 12:07:35', '/', '2026-01-02 12:34:35'),
  ('074eb105ee01d', 's007804', 117, 'page_view', '2026-01-02 12:10:23', '/product/sf-hom-0009', '2026-01-02 12:16:23'),
  ('99fa24d878614', 's007757', null, 'page_view', '2026-01-02 12:14:02', '/product/sf-bea-0023', '2026-01-02 12:51:02'),
  ('7dbb7ef1bfae2', 's007757', null, 'page_view', '2026-01-02 12:15:35', '/product/sf-fas-0018', '2026-01-02 12:55:35'),
  ('f1a80535bf4a3', 's007757', null, 'page_view', '2026-01-02 12:17:42', '/product/sf-ele-0002', '2026-01-02 12:53:42'),
  ('2649a75912dea', 's007740', 344, 'page_view', '2026-01-02 12:34:37', '/', '2026-01-02 13:22:37'),
  ('85b360274f160', 's007740', 344, 'page_view', '2026-01-02 12:38:20', '/category/books', '2026-01-02 13:04:20'),
  ('6f95b71384966', 's007748', 295, 'page_view', '2026-01-02 12:45:57', '/product/sf-fas-0015', '2026-01-02 13:00:57'),
  ('a55487c79e96e', 's007748', 295, 'page_view', '2026-01-02 12:47:26', '/category/beauty', '2026-01-02 12:54:26'),
  ('376090ea40472', 's007748', 295, 'page_view', '2026-01-02 12:51:14', '/category/books', '2026-01-02 12:56:14'),
  ('3214777ee5bc9', 's007748', 295, 'page_view', '2026-01-02 12:54:25', '/product/sf-hom-0034', '2026-01-02 13:47:25'),
  ('c8bf49b174f65', 's007748', 295, 'add_to_cart', '2026-01-02 12:57:50', '/cart', '2026-01-02 13:12:50'),
  ('6212e6c6c247f', 's007805', null, 'page_view', '2026-01-02 13:05:38', '/', '2026-01-02 13:35:38'),
  ('eeb43146f1cb3', 's007805', null, 'page_view', '2026-01-02 13:05:49', '/category/home', '2026-01-02 13:58:49'),
  ('b64b4ebfebbfa', 's007773', 480, 'page_view', '2026-01-02 13:14:55', '/', '2026-01-02 13:23:55'),
  ('719f5f59396a6', 's007785', 150, 'page_view', '2026-01-02 13:45:18', '/product/sf-ele-0007', '2026-01-02 14:21:18'),
  ('24e46656a3b4d', 's007785', 150, 'page_view', '2026-01-02 13:46:11', '/category/books', '2026-01-02 14:12:11'),
  ('999309c13d15c', 's007734', null, 'page_view', '2026-01-02 13:48:01', '/product/sf-ele-0002', '2026-01-02 14:38:01'),
  ('bd4eba396f2a7', 's007785', 150, 'page_view', '2026-01-02 13:50:08', '/category/home', '2026-01-02 14:31:08'),
  ('f4b51661bd611', 's007734', null, 'page_view', '2026-01-02 13:51:51', '/category/beauty', '2026-01-02 14:23:51'),
  ('54028be9223d1', 's007785', 150, 'page_view', '2026-01-02 13:51:55', '/product/sf-ele-0004', '2026-01-02 14:40:55'),
  ('e1cb4bd4e8976', 's007734', null, 'page_view', '2026-01-02 13:53:25', '/category/beauty', '2026-01-02 14:40:25'),
  ('8e9b8cef34a5c', 's007785', 150, 'page_view', '2026-01-02 13:53:33', '/category/electronics', '2026-01-02 14:17:33'),
  ('913d9a215c076', 's007785', 150, 'add_to_cart', '2026-01-02 13:55:59', '/cart', '2026-01-02 14:24:59'),
  ('21925fdb3538f', 's007747', 352, 'page_view', '2026-01-02 13:58:58', '/product/sf-ele-0003', '2026-01-02 14:40:58'),
  ('5d8b54d4ca99d', 's007808', 169, 'page_view', '2026-01-02 13:59:49', '/', '2026-01-02 14:34:49'),
  ('fd4c378b8cdff', 's007808', 169, 'page_view', '2026-01-02 14:00:18', '/category/beauty', '2026-01-02 14:19:18'),
  ('8ddbb0dc2d6ce', 's007808', 169, 'page_view', '2026-01-02 14:01:31', '/category/books', '2026-01-02 14:48:31'),
  ('57c0c1bad2b44', 's007808', 169, 'page_view', '2026-01-02 14:03:48', '/category/fashion', '2026-01-02 14:12:48'),
  ('412545a13c803', 's007808', 169, 'page_view', '2026-01-02 14:04:20', '/product/sf-bea-0023', '2026-01-02 14:25:20'),
  ('69a73890ddf02', 's007774', 390, 'page_view', '2026-01-02 14:04:36', '/', '2026-01-02 14:22:36'),
  ('d2b65f77dd0ca', 's007774', 390, 'page_view', '2026-01-02 14:04:54', '/product/sf-hom-0034', '2026-01-02 14:19:54'),
  ('b6f5ddcc21b22', 's007774', 390, 'page_view', '2026-01-02 14:08:53', '/category/home', '2026-01-02 14:36:53'),
  ('c1c285f7cda6d', 's007774', 390, 'page_view', '2026-01-02 14:12:09', '/category/beauty', '2026-01-02 15:05:09'),
  ('ad0e9702ed997', 's007802', null, 'page_view', '2026-01-02 14:35:28', '/product/sf-hom-0009', '2026-01-02 15:20:28'),
  ('6779955a2fcd1', 's007802', null, 'page_view', '2026-01-02 14:38:25', '/category/books', '2026-01-02 14:46:25'),
  ('32d5d9d067bab', 's007781', 391, 'page_view', '2026-01-02 14:52:10', '/category/fashion', '2026-01-02 15:36:10'),
  ('e8198b4a085c0', 's007781', 391, 'page_view', '2026-01-02 14:52:22', '/product/sf-bea-0024', '2026-01-02 15:05:22'),
  ('ea47520590b05', 's007750', null, 'page_view', '2026-01-02 14:52:53', '/product/sf-hom-0010', '2026-01-02 14:57:53'),
  ('8b72e17bea317', 's007794', 169, 'page_view', '2026-01-02 14:55:12', '/category/books', '2026-01-02 15:12:12'),
  ('c2a813fa8ad13', 's007794', 169, 'page_view', '2026-01-02 14:55:49', '/category/home', '2026-01-02 15:49:49'),
  ('e6bfbbf6a55e9', 's007781', 391, 'page_view', '2026-01-02 14:55:58', '/product/sf-hom-0008', '2026-01-02 15:25:58'),
  ('8b2fce55ac438', 's007753', null, 'page_view', '2026-01-02 14:56:14', '/product/sf-boo-0032', '2026-01-02 15:23:14'),
  ('298eb909223e4', 's007781', 391, 'page_view', '2026-01-02 14:56:27', '/category/books', '2026-01-02 15:19:27'),
  ('a66392f972036', 's007753', null, 'add_to_cart', '2026-01-02 14:56:39', '/cart', '2026-01-02 15:15:39'),
  ('0de23a2a8f3de', 's007794', 169, 'add_to_cart', '2026-01-02 14:57:42', '/cart', '2026-01-02 15:32:42'),
  ('c0a60228851c4', 's007794', 169, 'checkout_start', '2026-01-02 14:59:17', '/checkout', '2026-01-02 15:13:17'),
  ('6e107592ccda0', 's007794', 169, 'purchase', '2026-01-02 14:59:49', '/checkout/confirmation', '2026-01-02 15:53:49'),
  ('5d751cfe9d677', 's007796', null, 'page_view', '2026-01-02 15:08:00', '/category/home', '2026-01-02 15:24:00'),
  ('48841e5b1209c', 's007796', null, 'page_view', '2026-01-02 15:11:53', '/category/electronics', '2026-01-02 15:41:53'),
  ('42dc3c66191a8', 's007796', null, 'page_view', '2026-01-02 15:14:17', '/category/fashion', '2026-01-02 15:38:17'),
  ('5645310e23888', 's007796', null, 'page_view', '2026-01-02 15:15:45', '/product/sf-fas-0018', '2026-01-02 15:32:45'),
  ('eb22c87323413', 's007796', null, 'page_view', '2026-01-02 15:16:23', '/product/sf-hom-0008', '2026-01-02 15:58:23'),
  ('8cc5347e9d7aa', 's007749', 206, 'page_view', '2026-01-02 15:20:29', '/category/beauty', '2026-01-02 16:06:29'),
  ('c290cdb265762', 's007749', 206, 'page_view', '2026-01-02 15:20:58', '/category/electronics', '2026-01-02 15:58:58');
insert into web_analytics.events (event_id, session_id, customer_id, event_type, event_timestamp, page, _loaded_at) values
  ('d498cc5617991', 's007749', 206, 'page_view', '2026-01-02 15:22:00', '/product/sf-boo-0032', '2026-01-02 15:48:00'),
  ('82f2247d8eede', 's007749', 206, 'page_view', '2026-01-02 15:23:42', '/category/beauty', '2026-01-02 16:18:42'),
  ('9b0364e54c3e0', 's007749', 206, 'add_to_cart', '2026-01-02 15:24:13', '/cart', '2026-01-02 16:04:13'),
  ('dc9c5705d8ddb', 's007806', null, 'page_view', '2026-01-02 15:26:59', '/category/beauty', '2026-01-02 15:31:59'),
  ('df2b6195c2bb4', 's007806', null, 'page_view', '2026-01-02 15:29:42', '/category/electronics', '2026-01-02 15:51:42'),
  ('39dc8a77c06a0', 's007763', 302, 'page_view', '2026-01-02 15:36:57', '/product/sf-bea-0024', '2026-01-02 16:01:57'),
  ('1acbfba382305', 's007763', 302, 'add_to_cart', '2026-01-02 15:38:23', '/cart', '2026-01-02 16:12:23'),
  ('17cea574b9523', 's007811', 7, 'page_view', '2026-01-02 16:04:14', '/category/beauty', '2026-01-02 16:11:14'),
  ('88d54726e23dc', 's007811', 7, 'page_view', '2026-01-02 16:06:40', '/category/fashion', '2026-01-02 16:23:40'),
  ('e4425e41d25a1', 's007811', 7, 'page_view', '2026-01-02 16:07:42', '/category/electronics', '2026-01-02 16:31:42'),
  ('74adb74309eca', 's007790', null, 'page_view', '2026-01-02 16:41:58', '/product/sf-bea-0023', '2026-01-02 16:52:58'),
  ('074bb03706847', 's007778', 115, 'page_view', '2026-01-02 16:46:48', '/product/sf-boo-0032', '2026-01-02 17:08:48'),
  ('b4f36f3f5c0b4', 's007778', 115, 'page_view', '2026-01-02 16:49:12', '/category/fashion', '2026-01-02 17:10:12'),
  ('f36658917e043', 's007800', 134, 'page_view', '2026-01-02 17:13:26', '/category/electronics', '2026-01-02 17:27:26'),
  ('f188054683fa7', 's007741', 45, 'page_view', '2026-01-02 17:14:58', '/', '2026-01-02 17:57:58'),
  ('96dc19751d5d9', 's007742', 192, 'page_view', '2026-01-02 17:15:40', '/', '2026-01-02 17:38:40'),
  ('4272cbda342d7', 's007741', 45, 'page_view', '2026-01-02 17:16:34', '/category/books', '2026-01-02 17:27:34'),
  ('40898b9cad850', 's007800', 134, 'page_view', '2026-01-02 17:16:46', '/category/home', '2026-01-02 17:45:46'),
  ('f089ee92bef87', 's007742', 192, 'add_to_cart', '2026-01-02 17:18:00', '/cart', '2026-01-02 17:40:00'),
  ('7484e62409fa1', 's007789', null, 'page_view', '2026-01-02 17:18:06', '/product/sf-ele-0006', '2026-01-02 17:24:06'),
  ('0b983a059c28d', 's007742', 192, 'checkout_start', '2026-01-02 17:18:28', '/checkout', '2026-01-02 17:29:28'),
  ('a32c162fd8e60', 's007789', null, 'add_to_cart', '2026-01-02 17:19:57', '/cart', '2026-01-02 17:58:57'),
  ('6e9129a205ef1', 's007800', 134, 'page_view', '2026-01-02 17:20:11', '/category/fashion', '2026-01-02 18:11:11'),
  ('7ec532defff33', 's007789', null, 'checkout_start', '2026-01-02 17:20:28', '/checkout', '2026-01-02 17:49:28'),
  ('479abbfbd7c40', 's007742', 192, 'purchase', '2026-01-02 17:21:41', '/checkout/confirmation', '2026-01-02 17:35:41'),
  ('893e55a32d213', 's007800', 134, 'page_view', '2026-01-02 17:22:27', '/product/sf-hom-0010', '2026-01-02 17:30:27'),
  ('8c743542ab136', 's007800', 134, 'page_view', '2026-01-02 17:23:02', '/category/home', '2026-01-02 17:30:02'),
  ('694b47982c260', 's007789', null, 'purchase', '2026-01-02 17:23:46', '/checkout/confirmation', '2026-01-02 17:36:46'),
  ('bd24d90fc3bc0', 's007800', 134, 'add_to_cart', '2026-01-02 17:24:16', '/cart', '2026-01-02 17:30:16'),
  ('45bcccbbbd93c', 's007800', 134, 'checkout_start', '2026-01-02 17:27:20', '/checkout', '2026-01-02 17:34:20'),
  ('ca32e80bea805', 's007772', 78, 'page_view', '2026-01-02 17:56:57', '/', '2026-01-02 18:25:57'),
  ('2fc1495626923', 's007769', 440, 'page_view', '2026-01-02 18:02:33', '/category/fashion', '2026-01-02 18:53:33'),
  ('27b8bd1dd73ec', 's007769', 440, 'page_view', '2026-01-02 18:06:25', '/category/home', '2026-01-02 18:42:25'),
  ('26dc04576431f', 's007769', 440, 'page_view', '2026-01-02 18:09:16', '/product/sf-hom-0011', '2026-01-02 18:47:16'),
  ('3d1119ebc30b8', 's007769', 440, 'page_view', '2026-01-02 18:12:16', '/product/sf-hom-0013', '2026-01-02 19:02:16'),
  ('8ab8a4bf7bfc5', 's007771', 349, 'page_view', '2026-01-02 18:32:33', '/category/home', '2026-01-02 19:08:33'),
  ('ea9be0d2238ee', 's007771', 349, 'page_view', '2026-01-02 18:35:45', '/category/home', '2026-01-02 19:08:45'),
  ('bb966f8126802', 's007771', 349, 'page_view', '2026-01-02 18:37:42', '/category/electronics', '2026-01-02 18:47:42'),
  ('6210465bed846', 's007765', 500, 'page_view', '2026-01-02 18:58:21', '/category/home', '2026-01-02 19:15:21'),
  ('898e3a6bfe81e', 's007765', 500, 'page_view', '2026-01-02 18:59:59', '/product/sf-bea-0027', '2026-01-02 19:07:59'),
  ('b5a449b57fb9c', 's007765', 500, 'page_view', '2026-01-02 19:03:34', '/category/beauty', '2026-01-02 19:36:34'),
  ('3b5e745c2e31d', 's007765', 500, 'page_view', '2026-01-02 19:04:04', '/category/fashion', '2026-01-02 19:52:04'),
  ('616bf9cbb4eca', 's007798', null, 'page_view', '2026-01-02 19:05:27', '/product/sf-hom-0012', '2026-01-02 19:38:27'),
  ('f1884810f976c', 's007792', null, 'page_view', '2026-01-02 19:05:47', '/', '2026-01-02 19:25:47'),
  ('7bab6f4318a4a', 's007792', null, 'add_to_cart', '2026-01-02 19:06:26', '/cart', '2026-01-02 19:11:26'),
  ('8511700b6561b', 's007765', 500, 'add_to_cart', '2026-01-02 19:07:32', '/cart', '2026-01-02 19:44:32'),
  ('0dc4cca021898', 's007798', null, 'page_view', '2026-01-02 19:09:10', '/category/electronics', '2026-01-02 19:25:10'),
  ('66549507f42dc', 's007798', null, 'page_view', '2026-01-02 19:09:42', '/product/sf-boo-0030', '2026-01-02 20:03:42'),
  ('8b73205080ae0', 's007798', null, 'page_view', '2026-01-02 19:10:40', '/category/electronics', '2026-01-02 19:37:40'),
  ('3448c5f51ddf9', 's007779', null, 'page_view', '2026-01-02 19:18:59', '/', '2026-01-02 19:24:59'),
  ('1c30df3db2c4e', 's007776', 28, 'page_view', '2026-01-02 19:20:09', '/category/home', '2026-01-02 19:28:09'),
  ('7d41df88b32c9', 's007779', null, 'page_view', '2026-01-02 19:21:24', '/category/books', '2026-01-02 20:03:24'),
  ('90a10b8b2a66f', 's007776', 28, 'page_view', '2026-01-02 19:22:20', '/product/sf-bea-0026', '2026-01-02 20:13:20'),
  ('72436a0afba68', 's007779', null, 'page_view', '2026-01-02 19:24:44', '/category/beauty', '2026-01-02 19:34:44'),
  ('bef904f91acbf', 's007779', null, 'page_view', '2026-01-02 19:25:43', '/category/electronics', '2026-01-02 20:19:43'),
  ('067ad850adbc4', 's007776', 28, 'page_view', '2026-01-02 19:25:50', '/category/books', '2026-01-02 20:09:50'),
  ('6c53f41a5877b', 's007776', 28, 'page_view', '2026-01-02 19:26:06', '/category/electronics', '2026-01-02 19:34:06'),
  ('cecc49ebf2e9f', 's007776', 28, 'add_to_cart', '2026-01-02 19:26:48', '/cart', '2026-01-02 19:58:48'),
  ('a65ddcf868176', 's007779', null, 'page_view', '2026-01-02 19:27:38', '/product/sf-hom-0011', '2026-01-02 19:52:38'),
  ('66e5ca3ee1eae', 's007776', 28, 'checkout_start', '2026-01-02 19:30:33', '/checkout', '2026-01-02 20:19:33'),
  ('c390c6b53eecc', 's007776', 28, 'purchase', '2026-01-02 19:32:06', '/checkout/confirmation', '2026-01-02 19:56:06'),
  ('b591d1227f27e', 's007803', 47, 'page_view', '2026-01-02 19:32:11', '/', '2026-01-02 19:55:11'),
  ('26a0df244985d', 's007803', 47, 'page_view', '2026-01-02 19:36:02', '/category/beauty', '2026-01-02 20:11:02'),
  ('2e00b61e8fe71', 's007803', 47, 'page_view', '2026-01-02 19:37:10', '/category/beauty', '2026-01-02 20:19:10'),
  ('ab06811b6ecae', 's007803', 47, 'page_view', '2026-01-02 19:38:44', '/product/sf-bea-0022', '2026-01-02 20:24:44'),
  ('41b30b9e84756', 's007784', 203, 'page_view', '2026-01-02 20:12:09', '/', '2026-01-02 20:55:09'),
  ('15581a69b083b', 's007787', 76, 'page_view', '2026-01-02 20:12:32', '/category/books', '2026-01-02 20:42:32'),
  ('57a2c1362f832', 's007787', 76, 'add_to_cart', '2026-01-02 20:13:13', '/cart', '2026-01-02 20:21:13'),
  ('a670f3abc39c1', 's007784', 203, 'page_view', '2026-01-02 20:15:55', '/product/sf-ele-0002', '2026-01-02 21:08:55'),
  ('1f2a1d106e427', 's007784', 203, 'add_to_cart', '2026-01-02 20:19:32', '/cart', '2026-01-02 21:00:32'),
  ('31bd573280c9a', 's007736', 442, 'page_view', '2026-01-02 20:45:06', '/', '2026-01-02 21:38:06'),
  ('37bd76b17dd51', 's007736', 442, 'add_to_cart', '2026-01-02 20:48:35', '/cart', '2026-01-02 21:25:35'),
  ('cbc0c9f3c26c6', 's007795', null, 'page_view', '2026-01-02 20:51:43', '/', '2026-01-02 21:15:43'),
  ('d5d439e4d560d', 's007754', 394, 'page_view', '2026-01-02 20:54:03', '/', '2026-01-02 21:12:03'),
  ('b1ab6b60478bd', 's007795', null, 'page_view', '2026-01-02 20:55:18', '/product/sf-boo-0033', '2026-01-02 21:25:18'),
  ('d22827afd503a', 's007754', 394, 'page_view', '2026-01-02 20:55:28', '/product/sf-fas-0015', '2026-01-02 21:44:28'),
  ('8d9578c90d988', 's007754', 394, 'page_view', '2026-01-02 20:58:31', '/product/sf-ele-0002', '2026-01-02 21:33:31'),
  ('f8d08dbf94b19', 's007795', null, 'page_view', '2026-01-02 20:58:50', '/category/home', '2026-01-02 21:41:50'),
  ('a80cc3521ab5b', 's007738', null, 'page_view', '2026-01-02 20:59:58', '/category/electronics', '2026-01-02 21:42:58'),
  ('4d0fe0b1cb808', 's007738', null, 'page_view', '2026-01-02 21:02:08', '/category/fashion', '2026-01-02 21:57:08'),
  ('bd9ab317b93a5', 's007754', 394, 'page_view', '2026-01-02 21:02:12', '/product/sf-ele-0035', '2026-01-02 21:39:12'),
  ('78ce85a367398', 's007754', 394, 'page_view', '2026-01-02 21:03:02', '/category/home', '2026-01-02 21:35:02'),
  ('9d06476f65296', 's007738', null, 'page_view', '2026-01-02 21:05:08', '/category/fashion', '2026-01-02 21:51:08'),
  ('b09198ca24ea4', 's007754', 394, 'add_to_cart', '2026-01-02 21:05:53', '/cart', '2026-01-02 21:59:53'),
  ('98c198ccc3a66', 's007754', 394, 'checkout_start', '2026-01-02 21:06:26', '/checkout', '2026-01-02 21:41:26'),
  ('059eccf4ba805', 's007777', null, 'page_view', '2026-01-02 21:22:11', '/product/sf-fas-0015', '2026-01-02 21:31:11'),
  ('ec630d3df95ea', 's007777', null, 'page_view', '2026-01-02 21:23:16', '/category/home', '2026-01-02 21:44:16'),
  ('36248396e2500', 's007733', 189, 'page_view', '2026-01-02 21:24:11', '/category/books', '2026-01-02 21:49:11'),
  ('4ae75103e5a2f', 's007733', 189, 'page_view', '2026-01-02 21:25:41', '/category/fashion', '2026-01-02 21:52:41'),
  ('94991a39041d8', 's007733', 189, 'page_view', '2026-01-02 21:26:15', '/category/electronics', '2026-01-02 22:11:15'),
  ('503b5bc38c743', 's007733', 189, 'page_view', '2026-01-02 21:27:40', '/category/beauty', '2026-01-02 21:49:40'),
  ('9898a84aa128a', 's007733', 189, 'page_view', '2026-01-02 21:31:29', '/product/sf-fas-0017', '2026-01-02 22:08:29'),
  ('db0086df5e825', 's007766', null, 'page_view', '2026-01-02 21:40:37', '/', '2026-01-02 22:29:37'),
  ('73ff3c1829d5b', 's007766', null, 'page_view', '2026-01-02 21:41:14', '/category/electronics', '2026-01-02 22:28:14'),
  ('b8275d2827f7e', 's007766', null, 'page_view', '2026-01-02 21:44:38', '/product/sf-hom-0009', '2026-01-02 22:30:38'),
  ('c3186de4dbf98', 's007766', null, 'page_view', '2026-01-02 21:46:36', '/category/electronics', '2026-01-02 21:58:36'),
  ('7865ced582a1c', 's007766', null, 'page_view', '2026-01-02 21:47:38', '/category/home', '2026-01-02 22:32:38'),
  ('a86a7ef187eff', 's007758', 212, 'page_view', '2026-01-02 21:50:12', '/product/sf-bea-0025', '2026-01-02 22:41:12'),
  ('fe71007fc1ffb', 's007810', null, 'page_view', '2026-01-02 21:50:18', '/', '2026-01-02 22:15:18'),
  ('71b86dd3c083e', 's007758', 212, 'page_view', '2026-01-02 21:53:14', '/category/books', '2026-01-02 22:42:14'),
  ('82fc5317874b7', 's007764', 159, 'page_view', '2026-01-02 21:54:23', '/', '2026-01-02 22:43:23'),
  ('5eb8f260b4668', 's007758', 212, 'page_view', '2026-01-02 21:55:56', '/category/beauty', '2026-01-02 22:27:56'),
  ('b87cf9c8dd7cc', 's007764', 159, 'add_to_cart', '2026-01-02 21:57:05', '/cart', '2026-01-02 22:15:05'),
  ('9d4187e5550ba', 's007758', 212, 'page_view', '2026-01-02 21:57:24', '/category/books', '2026-01-02 22:22:24'),
  ('53083b623b41b', 's007786', null, 'page_view', '2026-01-02 22:05:06', '/product/sf-hom-0011', '2026-01-02 22:48:06'),
  ('95f95768a975a', 's007786', null, 'page_view', '2026-01-02 22:07:39', '/category/books', '2026-01-02 22:45:39'),
  ('24066053dee70', 's007786', null, 'page_view', '2026-01-02 22:09:26', '/category/fashion', '2026-01-02 23:03:26'),
  ('3cc2c0b065287', 's007786', null, 'page_view', '2026-01-02 22:10:27', '/product/sf-ele-0006', '2026-01-02 22:37:27'),
  ('98efed7c33400', 's007786', null, 'add_to_cart', '2026-01-02 22:13:13', '/cart', '2026-01-02 22:53:13'),
  ('d4206b64dbe36', 's007812', 443, 'page_view', '2026-01-02 22:15:49', '/', '2026-01-02 23:03:49'),
  ('ff052a9917020', 's007812', 443, 'page_view', '2026-01-02 22:17:39', '/category/beauty', '2026-01-02 22:51:39'),
  ('88e98ba78f7f7', 's007812', 443, 'page_view', '2026-01-02 22:19:17', '/category/beauty', '2026-01-02 23:01:17'),
  ('5c4b5573024fb', 's007812', 443, 'page_view', '2026-01-02 22:21:28', '/category/beauty', '2026-01-02 22:31:28'),
  ('89315803e2c88', 's007812', 443, 'page_view', '2026-01-02 22:21:41', '/category/electronics', '2026-01-02 22:30:41'),
  ('74349715d15d9', 's007751', 82, 'page_view', '2026-01-02 22:49:41', '/product/sf-hom-0011', '2026-01-02 23:38:41'),
  ('e6dff31b21cc7', 's007751', 82, 'page_view', '2026-01-02 22:50:57', '/product/sf-bea-0027', '2026-01-02 23:00:57'),
  ('156a95772f2d4', 's007751', 82, 'page_view', '2026-01-02 22:51:28', '/product/sf-bea-0026', '2026-01-02 23:23:28'),
  ('6daac9979697d', 's007760', 388, 'page_view', '2026-01-02 22:56:12', '/category/books', '2026-01-02 23:13:12'),
  ('2c0df064dbada', 's007760', 388, 'page_view', '2026-01-02 22:58:28', '/category/books', '2026-01-02 23:09:28'),
  ('69c80ade5c164', 's007760', 388, 'page_view', '2026-01-02 23:01:09', '/product/sf-boo-0030', '2026-01-02 23:46:09'),
  ('95e6ed2188533', 's007760', 388, 'page_view', '2026-01-02 23:01:40', '/category/fashion', '2026-01-02 23:10:40');

select 'day3 applied' as status;
