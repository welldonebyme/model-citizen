-- =====================================================================
--  fresh_load.sql -- pretend the loader just ran
--  From the shopflow-data folder:   duckdb shopflow.duckdb < updates/fresh_load.sql
--  Sets _loaded_at = now (UTC) on ONE existing row of each table that has a freshness check.
--  Business columns and row counts do not change. Run it again whenever you want green freshness.
-- =====================================================================

update shopflow_app.orders set _loaded_at = current_timestamp at time zone 'UTC' where order_id = 3000;
update payments_provider.payments set _loaded_at = current_timestamp at time zone 'UTC' where payment_id = 3168;
update web_analytics.events set _loaded_at = current_timestamp at time zone 'UTC' where event_id = '92e3dd92bd529';
update shipping.shipments set _loaded_at = current_timestamp at time zone 'UTC' where shipment_id = 2646;

select 'orders' as table_name, max(_loaded_at) as max_loaded_at from shopflow_app.orders
union all select 'payments', max(_loaded_at) from payments_provider.payments
union all select 'events', max(_loaded_at) from web_analytics.events
union all select 'shipments', max(_loaded_at) from shipping.shipments;
